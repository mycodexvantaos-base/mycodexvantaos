# MyCodexVantaOS — 全方位命名規範策略

## 一、基礎命名原則 (Root Principles)
*   **字元集**: 僅允許小寫字母 a-z、數字 0-9、連字號 - (kebab-case)
*   **禁止符號**: 嚴禁底線 _、點號 .、空格、斜線 /
*   **環境標記**: 禁止在資源名稱中包含環境標記 (如 dev, staging)，可用於 Namespace

## 二、服務標識 (Service ID)
格式: `mycodexvantaos-<domain>-<capability>`
範例: `mycodexvantaos-core-gateway`, `mycodexvantaos-platform-portal`

## 三、Provider 實例命名
格式: `<capability>-<provider-name>`
範例: `database-sqlite`, `llm-ollama`, `vector-store-pgvector`
