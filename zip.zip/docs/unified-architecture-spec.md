# MyCodexVantaOS — 統一架構規範（摘要與索引）

## 一、核心原則
1. **平台獨立性（platform-independence）**：第三方服務是擴充出口，非成立地基。
2. **Provider 抽象（provider-abstraction）**：外部能力統一透過 provider 層暴露。
3. **模式驅動運行時（mode-driven-runtime）**：最終執行模式：native、connected、hybrid。
4. **單一真實來源（single-source-of-truth）**：manifest 與 schema 是架構語義唯一真理。

## 二、架構層級
*   `Service Layer`: 微服務業務邊界 (`mycodexvantaos-<domain>-<capability>`)
*   `Module Layer`: 組織拓撲清單 (`module-manifest.yaml`)
*   `Provider Layer`: 依賴抽象層 (`<capability>-<provider-name>`)
*   `Governance Layer`: 策略、命名管理與架構驗證
