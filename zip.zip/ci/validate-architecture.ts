import fs from 'fs';
import path from 'path';

console.log("🚀 Starting MyCodexVantaOS Architecture Validation...\n");

const servicesDir = path.join(process.cwd(), 'services');
const serviceRegex = /^mycodexvantaos-[a-z0-9]+(?:-[a-z0-9]+)+$/;
let hasErrors = false;

// 1. Service ID Strict Validation (Hard Gate)
if (fs.existsSync(servicesDir)) {
  const services = fs.readdirSync(servicesDir);
  for (const service of services) {
    if (!serviceRegex.test(service)) {
      console.error(`❌ CRITICAL: Service directory '${service}' violates naming policy.`);
      console.error(`   Expected pattern: ${serviceRegex}`);
      hasErrors = true;
    } else {
      console.log(`✅ Valid service identity: ${service}`);
    }
  }
}

// 2. Anti-Pattern / Legacy Name Detection
const legacyNames = ['core-main', 'module-suite', 'codexvanta-os', 'fleet-sandbox'];
const scanDirectory = (dir: string) => {
  const excludedDirs = ['node_modules', '.git', 'dist'];
  const files = fs.readdirSync(dir);
  for (const file of files) {
    if (excludedDirs.includes(file)) continue;
    const fullPath = path.join(dir, file);
    if (fs.statSync(fullPath).isDirectory()) {
      scanDirectory(fullPath);
    } else if (file.endsWith('.ts') || file.endsWith('.json') || file.endsWith('.yaml')) {
      const content = fs.readFileSync(fullPath, 'utf8');
      for (const legacy of legacyNames) {
        if (content.includes(legacy)) {
          console.warn(`⚠️ WARNING: Legacy naming '${legacy}' detected in ${fullPath}`);
        }
      }
    }
  }
};

console.log("\n🔍 Scanning for legacy naming anti-patterns...");
scanDirectory(process.cwd());

if (hasErrors) {
  console.error("\n❌ Architecture Drift Detected! Please check validation logs.");
  process.exit(1);
} else {
  console.log("\n✅ All architecture and naming governance policies passed.");
}
