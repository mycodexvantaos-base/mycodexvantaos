/**
 * ci/rules/vector-collection.rule.ts
 * §9.2, §13 — Soft enforcement
 */
import { validate } from "../utils/regex-table.js";
import type { ValidationContext, RuleResult } from "../validate-architecture.js";

export function run(ctx: ValidationContext): RuleResult[] {
  return ctx.vectorCollectionIds.map((id) => ({
    ruleId: "vector-collection",
    enforcement: "soft" as const,
    passed: validate("vector-collection", id),
    target: id,
    message: validate("vector-collection", id)
      ? `vector-collection id "${id}" is valid`
      : `Invalid vector-collection id: "${id}". Expected <service-id>--<purpose>--<model-alias> (§9.2)`,
  }));
}
