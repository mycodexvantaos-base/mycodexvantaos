/**
 * Governance Universe ETL Pipeline - Main Entry Point
 * Universal pipeline system for processing any document and topic
 * Aligned with GL00-20 Governance Layers
 */

import { ConfigManager } from './config';
import { ETLPipeline } from './pipeline';
import { DataSource, DataSourceType } from './types';
import { logger } from './observability/logger';
import { metricsCollector } from './observability/metrics';
import * as http from 'http';

async function main() {
  try {
    logger.info('🌌 Governance Universe ETL Pipeline Starting', {
      environment: process.env.PIPELINE_ENVIRONMENT || 'development',
      nodeVersion: process.version,
      timestamp: new Date().toISOString()
    });

    const configManager = ConfigManager.getInstance();
    const configValidation = configManager.validate();

    if (!configValidation.valid) {
      throw new Error(`Configuration validation failed: ${configValidation.errors.join(', ')}`);
    }

    logger.info('Configuration validated successfully');

    const topics = process.env.PIPELINE_TOPICS?.split(',') || ['governance', 'analytics'];
    const sources = createExampleSources(topics);

    const pipelineConfig = configManager.createPipelineConfig(topics, sources);

    const pipeline = new ETLPipeline(pipelineConfig);

    if (process.env.MONITORING_ENABLED === 'true') {
      await startMonitoringServer();
      await metricsCollector.startPeriodicCollection(5000);
    }

    const execution = await pipeline.execute();

    logger.info('🎉 Pipeline execution completed successfully', {
      executionId: execution.id,
      status: execution.status,
      duration: execution.metrics?.duration,
      recordsProcessed: execution.metrics?.recordsLoaded,
      governanceCompliance: execution.governanceReport?.complianceScore
    });

    if (process.env.NODE_ENV !== 'production') {
      process.exit(0);
    }

  } catch (error) {
    logger.error('❌ Pipeline execution failed', {
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : undefined
    });
    process.exit(1);
  }
}

function createExampleSources(topics: string[]): DataSource[] {
  return [
    {
      id: 'database-source-1',
      type: DataSourceType.DATABASE,
      config: {
        connectionString: process.env.DATABASE_URL || 'postgresql://localhost:5432/governance_db',
        tableName: 'user_analytics',
        incrementalColumn: 'updated_at',
        batchSize: 1000
      },
      governanceLayer: 'GL02_DATA_ACCESS',
      enabled: true,
      schedule: '0 */6 * * *'
    },
    {
      id: 'api-source-1',
      type: DataSourceType.API,
      config: {
        baseUrl: 'https://api.example.com',
        endpoints: ['/analytics/users', '/analytics/sessions'],
        timeout: 30000,
        retryAttempts: 3,
        rateLimit: 100
      },
      governanceLayer: 'GL08_INTEGRATION',
      enabled: true
    },
    {
      id: 'file-source-1',
      type: DataSourceType.FILE,
      config: {
        path: './input',
        format: 'json',
        encoding: 'utf8'
      },
      governanceLayer: 'GL02_DATA_ACCESS',
      enabled: true
    }
  ];
}

async function startMonitoringServer(): Promise<void> {
  const port = process.env.METRICS_PORT || 9090;

  const server = http.createServer((req, res) => {
    if (req.url === '/metrics') {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end(metricsCollector.getMetrics());
    } else if (req.url === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'healthy', timestamp: new Date().toISOString() }));
    } else {
      res.writeHead(404);
      res.end('Not Found');
    }
  });

  server.listen(port, () => {
    logger.info(`📊 Monitoring server started`, {
      port,
      metricsEndpoint: `http://localhost:${port}/metrics`,
      healthEndpoint: `http://localhost:${port}/health`
    });
  });
}

if (require.main === module) {
  main().catch(error => {
    console.error('Unhandled error:', error);
    process.exit(1);
  });
}

export { ETLPipeline, ConfigManager };
export * from './types';
export * from './extractors';
export * from './transformers';
export * from './loaders';
export * from './governance';