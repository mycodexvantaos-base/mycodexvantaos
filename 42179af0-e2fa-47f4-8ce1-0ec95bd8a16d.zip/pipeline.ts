/**
 * Main ETL Pipeline
 * Orchestrates Extract, Transform, and Load operations
 * Aligns with all GL00-20 Governance Layers
 */

import { v4 as uuidv4 } from 'uuid';
import { PipelineConfig, PipelineExecution, DataRecord, IncrementalState, ProcessingMode } from './types';
import { ExtractorFactory } from './extractors';
import { TransformationPipeline } from './transformers/pipeline';
import { LoaderFactory } from './loaders';
import { GovernanceReporter } from './governance/governance-reporter';
import { ConfigManager } from './config';
import { logger } from './observability/logger';
import { metricsCollector } from './observability/metrics';

export class ETLPipeline {
  private config: PipelineConfig;
  private execution: PipelineExecution;
  private transformationPipeline: TransformationPipeline;
  private configManager: ConfigManager;

  constructor(config: PipelineConfig) {
    this.config = config;
    this.configManager = ConfigManager.getInstance();
    
    this.execution = {
      id: uuidv4(),
      pipelineName: config.name,
      status: 'running',
      startTime: new Date(),
      config: config,
      errors: []
    };

    this.transformationPipeline = new TransformationPipeline(config.transformations);
  }

  public async execute(): Promise<PipelineExecution> {
    const startTime = Date.now();

    try {
      logger.info('Starting ETL pipeline execution', {
        executionId: this.execution.id,
        pipelineName: this.config.name,
        mode: this.config.mode,
        governanceLayers: this.config.governanceLayers.length
      });

      metricsCollector.incrementPipelineExecution(
        this.config.name,
        'started'
      );

      const incrementalState = await this.loadIncrementalState();
      
      const allRecords = await this.extractAll(incrementalState);
      const { success: transformedRecords, failed: failedTransformations } = await this.transformAll(allRecords);
      const loadedCount = await this.loadAll(transformedRecords);

      await this.saveIncrementalState(this.execution.startTime);

      this.execution.status = 'completed';
      this.execution.endTime = new Date();

      this.execution.metrics = {
        pipelineId: this.execution.id,
        timestamp: new Date(),
        recordsExtracted: allRecords.length,
        recordsTransformed: transformedRecords.length,
        recordsLoaded: loadedCount,
        recordsFailed: failedTransformations.length,
        duration: (Date.now() - startTime) / 1000,
        memoryUsage: process.memoryUsage().heapUsed / 1024 / 1024,
        cpuUsage: process.cpuUsage().user / 1000000,
        governanceLayerStatus: this.evaluateGovernanceLayers()
      };

      await this.generateGovernanceReport();
      await this.checkAlerts();

      metricsCollector.incrementPipelineExecution(
        this.config.name,
        'completed'
      );

      logger.info('ETL pipeline execution completed successfully', {
        executionId: this.execution.id,
        duration: `${this.execution.metrics.duration}s`,
        recordsProcessed: this.execution.metrics.recordsLoaded,
        complianceRate: `${((transformedRecords.length / allRecords.length) * 100).toFixed(2)}%`
      });

      return this.execution;

    } catch (error) {
      this.execution.status = 'failed';
      this.execution.endTime = new Date();

      logger.error('ETL pipeline execution failed', {
        executionId: this.execution.id,
        error: error instanceof Error ? error.message : String(error),
        duration: `${(Date.now() - startTime) / 1000}s`
      });

      metricsCollector.incrementPipelineExecution(
        this.config.name,
        'failed'
      );

      await this.generateGovernanceReport();
      await this.checkAlerts();

      throw error;
    }
  }

  private async extractAll(incrementalState?: IncrementalState): Promise<DataRecord[]> {
    logger.info('Starting extraction phase', {
      executionId: this.execution.id,
      sourcesCount: this.config.sources.length,
      mode: this.config.mode
    });

    const extractors = await ExtractorFactory.createExtractors(this.config.sources);
    const allRecords: DataRecord[] = [];

    try {
      for (const extractor of extractors) {
        let records: DataRecord[];

        if (this.config.mode === ProcessingMode.INCREMENTAL && incrementalState) {
          extractor.setIncrementalState(incrementalState);
          records = await extractor.extractIncremental(incrementalState);
        } else {
          records = await extractor.extract();
        }

        allRecords.push(...records);

        metricsCollector.incrementRecordsProcessed(
          this.config.name,
          'extract',
          this.config.sources.find(s => s.id === (extractor as any).source?.id)?.type || 'unknown',
          'success',
          records.length
        );

        logger.info('Extraction completed for source', {
          executionId: this.execution.id,
          sourceId: (extractor as any).source?.id,
          recordsExtracted: records.length
        });
      }

      logger.info('Extraction phase completed', {
        executionId: this.execution.id,
        totalRecords: allRecords.length
      });

      return allRecords;

    } finally {
      for (const extractor of extractors) {
        await extractor.close();
      }
    }
  }

  private async transformAll(records: DataRecord[]): Promise<{
    success: DataRecord[];
    failed: Array<{ record: DataRecord; error: string }>;
  }> {
    logger.info('Starting transformation phase', {
      executionId: this.execution.id,
      recordsCount: records.length,
      transformations: this.config.transformations.length
    });

    const result = await this.transformationPipeline.transformBatch(records);

    metricsCollector.incrementRecordsProcessed(
      this.config.name,
      'transform',
      'all',
      'success',
      result.success.length
    );

    metricsCollector.incrementRecordsProcessed(
      this.config.name,
      'transform',
      'all',
      'failed',
      result.failed.length
    );

    for (const failed of result.failed) {
      this.execution.errors.push({
        recordId: failed.record.id,
        field: 'all',
        message: failed.error,
        severity: 'error',
        governanceLayer: GovernanceLayer.GL11_TESTING,
        timestamp: new Date()
      });
    }

    logger.info('Transformation phase completed', {
      executionId: this.execution.id,
      successCount: result.success.length,
      failedCount: result.failed.length,
      successRate: `${((result.success.length / records.length) * 100).toFixed(2)}%`
    });

    return result;
  }

  private async loadAll(records: DataRecord[]): Promise<number> {
    logger.info('Starting load phase', {
      executionId: this.execution.id,
      recordsCount: records.length,
      destinationsCount: this.config.destinations.length
    });

    const loaders = await LoaderFactory.createLoaders(this.config.destinations);
    let totalLoaded = 0;

    try {
      for (const loader of loaders) {
        const loaded = await loader.load(records);
        totalLoaded = Math.max(totalLoaded, loaded);

        metricsCollector.incrementRecordsProcessed(
          this.config.name,
          'load',
          this.config.destinations.find(d => d.id === (loader as any).destination?.id)?.type || 'unknown',
          'success',
          loaded
        );

        logger.info('Load completed for destination', {
          executionId: this.execution.id,
          destinationId: (loader as any).destination?.id,
          recordsLoaded: loaded
        });
      }

      logger.info('Load phase completed', {
        executionId: this.execution.id,
        totalRecordsLoaded: totalLoaded
      });

      return totalLoaded;

    } finally {
      for (const loader of loaders) {
        await loader.close();
      }
    }
  }

  private async loadIncrementalState(): Promise<IncrementalState | undefined> {
    if (this.config.mode !== ProcessingMode.INCREMENTAL) {
      return undefined;
    }

    try {
      const statePath = './state/incremental-state.json';
      const fs = require('fs');
      
      if (fs.existsSync(statePath)) {
        const stateData = fs.readFileSync(statePath, 'utf-8');
        const state = JSON.parse(stateData);
        
        logger.info('Incremental state loaded', {
          executionId: this.execution.id,
          lastProcessedTimestamp: state.lastProcessedTimestamp
        });
        
        return state;
      }
    } catch (error) {
      logger.warn('Failed to load incremental state', {
        executionId: this.execution.id,
        error: error instanceof Error ? error.message : String(error)
      });
    }

    return {
      lastProcessedTimestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
      lastProcessedId: '',
      watermark: '',
      checkpoint: ''
    };
  }

  private async saveIncrementalState(timestamp: Date): Promise<void> {
    if (this.config.mode !== ProcessingMode.INCREMENTAL) {
      return;
    }

    try {
      const state: IncrementalState = {
        lastProcessedTimestamp: timestamp,
        lastProcessedId: this.execution.id,
        watermark: timestamp.toISOString(),
        checkpoint: this.execution.id
      };

      const fs = require('fs');
      const stateDir = './state';
      
      if (!fs.existsSync(stateDir)) {
        fs.mkdirSync(stateDir, { recursive: true });
      }

      const statePath = path.join(stateDir, 'incremental-state.json');
      fs.writeFileSync(statePath, JSON.stringify(state, null, 2));

      logger.info('Incremental state saved', {
        executionId: this.execution.id,
        timestamp: state.lastProcessedTimestamp
      });
    } catch (error) {
      logger.error('Failed to save incremental state', {
        executionId: this.execution.id,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }

  private evaluateGovernanceLayers(): Record<string, boolean> {
    const status: Record<string, boolean> = {};

    for (const layer of this.config.governanceLayers) {
      const layerErrors = this.execution.errors.filter(e => e.governanceLayer === layer);
      status[layer] = layerErrors.length === 0;
    }

    return status;
  }

  private async generateGovernanceReport(): Promise<void> {
    const reporter = new GovernanceReporter(this.execution);
    const report = reporter.generateReport();
    const reportPath = reporter.saveReport(report);

    this.execution.governanceReport = report;

    logger.info('Governance report generated', {
      executionId: this.execution.id,
      reportPath,
      complianceScore: report.complianceScore
    });
  }

  private async checkAlerts(): Promise<void> {
    const alertThreshold = this.config.monitoring.alerting.errorThreshold;
    const errorCount = this.execution.errors.length;

    if (errorCount >= alertThreshold) {
      logger.error('Error threshold exceeded', {
        executionId: this.execution.id,
        errorCount,
        threshold: alertThreshold
      });

      await this.sendAlert({
        type: 'error_threshold',
        executionId: this.execution.id,
        errorCount,
        threshold: alertThreshold,
        timestamp: new Date()
      });
    }

    if (this.execution.metrics?.complianceRate !== undefined && 
        this.execution.metrics.complianceRate < 80) {
      await this.sendAlert({
        type: 'low_compliance',
        executionId: this.execution.id,
        complianceRate: this.execution.metrics.complianceRate,
        timestamp: new Date()
      });
    }
  }

  private async sendAlert(alert: any): Promise<void> {
    const { email, webhook } = this.config.monitoring.alerting;

    logger.info('Sending alert', {
      executionId: this.execution.id,
      alertType: alert.type,
      email,
      webhook
    });

    if (webhook) {
      try {
        const axios = require('axios');
        await axios.post(webhook, {
          alert,
          execution: this.execution
        });
      } catch (error) {
        logger.error('Failed to send webhook alert', {
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }
  }

  public getExecution(): PipelineExecution {
    return this.execution;
  }

  public getConfig(): PipelineConfig {
    return this.config;
  }
}