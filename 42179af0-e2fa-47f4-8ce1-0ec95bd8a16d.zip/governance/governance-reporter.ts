/**
 * Governance Reporter
 * GL19 - Governance Summary Layer
 * GL20 - Governance Final Seal Layer
 */

import { PipelineExecution, GovernanceLayer, GovernanceLayerStatus, GovernanceReport } from '../types';
import { logger } from '../observability/logger';
import fs from 'fs';
import path from 'path';

export class GovernanceReporter {
  private execution: PipelineExecution;

  constructor(execution: PipelineExecution) {
    this.execution = execution;
  }

  public generateReport(): GovernanceReport {
    const layerStatuses = this.generateLayerStatuses();
    const complianceScore = this.calculateComplianceScore(layerStatuses);
    const summary = this.generateSummary(layerStatuses, complianceScore);
    const recommendations = this.generateRecommendations(layerStatuses);

    const report: GovernanceReport = {
      executionId: this.execution.id,
      timestamp: new Date(),
      layers: layerStatuses,
      summary,
      recommendations,
      complianceScore
    };

    logger.info('Governance report generated', {
      executionId: this.execution.id,
      complianceScore,
      layersPassed: layerStatuses.filter(l => l.status === 'passed').length,
      layersFailed: layerStatuses.filter(l => l.status === 'failed').length
    });

    return report;
  }

  private generateLayerStatuses(): GovernanceLayerStatus[] {
    const layerStatuses: GovernanceLayerStatus[] = [];

    for (const layer of Object.values(GovernanceLayer)) {
      const status = this.evaluateLayerStatus(layer);
      layerStatuses.push(status);
    }

    return layerStatuses;
  }

  private evaluateLayerStatus(layer: GovernanceLayer): GovernanceLayerStatus {
    const errors = this.execution.errors.filter(e => e.governanceLayer === layer);
    const errorCount = errors.length;
    const criticalErrors = errors.filter(e => e.severity === 'error').length;

    let status: 'passed' | 'failed' | 'warning';
    let checks = 10;
    let passed = checks - errorCount;
    let failed = criticalErrors;

    if (criticalErrors > 0) {
      status = 'failed';
    } else if (errorCount > 0) {
      status = 'warning';
    } else {
      status = 'passed';
    }

    return {
      layer,
      status,
      checks,
      passed,
      failed,
      details: this.getLayerDetails(layer, errors)
    };
  }

  private getLayerDetails(layer: GovernanceLayer, errors: any[]): string {
    const layerDescriptions: Record<GovernanceLayer, string> = {
      [GovernanceLayer.GL01_PERFORMANCE]: 'Performance optimization and bottlenecks removal',
      [GovernanceLayer.GL02_DATA_ACCESS]: 'Data access abstraction and database operations',
      [GovernanceLayer.GL03_DESIGN_PATTERNS]: 'Design patterns implementation',
      [GovernanceLayer.GL04_CUDA_GPU]: 'Hardware acceleration with CUDA/GPU',
      [GovernanceLayer.GL05_ALGORITHM]: 'Algorithm logic abstraction',
      [GovernanceLayer.GL06_OBSERVABILITY]: 'Logging, tracing, and metrics',
      [GovernanceLayer.GL07_SECURITY]: 'Authentication, authorization, and encryption',
      [GovernanceLayer.GL08_INTEGRATION]: 'API gateway and external system integration',
      [GovernanceLayer.GL09_GITOPS]: 'Git workflow and governance implementation',
      [GovernanceLayer.GL10_DOCUMENTATION]: 'Knowledge archival and documentation',
      [GovernanceLayer.GL11_TESTING]: 'Unit, integration, and end-to-end testing',
      [GovernanceLayer.GL12_SHARED_TOOLS]: 'Standardized tool modules',
      [GovernanceLayer.GL13_EXAMPLES]: 'Teaching and demonstration',
      [GovernanceLayer.GL14_DOCUMENTATION_DEEP]: 'Complete technical documentation',
      [GovernanceLayer.GL15_STRESS_TESTING]: 'Load and fault injection testing',
      [GovernanceLayer.GL16_DEVELOPMENT]: 'Sandbox and experimental environment',
      [GovernanceLayer.GL17_AUTOMATED_GITOPS]: 'Fully automated governance',
      [GovernanceLayer.GL18_BACKUP]: 'Disaster recovery and core archiving',
      [GovernanceLayer.GL19_GOVERNANCE_SUMMARY]: 'Automated governance narrative',
      [GovernanceLayer.GL20_FINAL_SEAL]: 'Irreversible governance baseline'
    };

    const baseDescription = layerDescriptions[layer] || 'Unknown layer';
    
    if (errors.length > 0) {
      return `${baseDescription}. Issues: ${errors.slice(0, 3).map(e => e.message).join(', ')}`;
    }
    
    return `${baseDescription}. All checks passed successfully.`;
  }

  private calculateComplianceScore(layerStatuses: GovernanceLayerStatus[]): number {
    if (layerStatuses.length === 0) return 0;

    const totalChecks = layerStatuses.reduce((sum, layer) => sum + layer.checks, 0);
    const totalPassed = layerStatuses.reduce((sum, layer) => sum + layer.passed, 0);

    return Math.round((totalPassed / totalChecks) * 100);
  }

  private generateSummary(layerStatuses: GovernanceLayerStatus[], complianceScore: number): string {
    const passed = layerStatuses.filter(l => l.status === 'passed').length;
    const failed = layerStatuses.filter(l => l.status === 'failed').length;
    const warnings = layerStatuses.filter(l => l.status === 'warning').length;

    let summary = `Pipeline Execution Governance Summary\n`;
    summary += `========================================\n`;
    summary += `Execution ID: ${this.execution.id}\n`;
    summary += `Timestamp: ${new Date().toISOString()}\n`;
    summary += `Status: ${this.execution.status}\n`;
    summary += `Compliance Score: ${complianceScore}%\n`;
    summary += `\n`;
    summary += `Layer Status:\n`;
    summary += `- Passed: ${passed}\n`;
    summary += `- Failed: ${failed}\n`;
    summary += `- Warnings: ${warnings}\n`;
    summary += `\n`;
    summary += `Records Processed:\n`;
    summary += `- Extracted: ${this.execution.metrics?.recordsExtracted || 0}\n`;
    summary += `- Transformed: ${this.execution.metrics?.recordsTransformed || 0}\n`;
    summary += `- Loaded: ${this.execution.metrics?.recordsLoaded || 0}\n`;
    summary += `- Failed: ${this.execution.metrics?.recordsFailed || 0}\n`;
    summary += `\n`;
    summary += `Duration: ${this.execution.metrics?.duration || 0}s\n`;
    summary += `Memory Usage: ${this.execution.metrics?.memoryUsage || 0}MB\n`;
    summary += `CPU Usage: ${this.execution.metrics?.cpuUsage || 0}%\n`;

    return summary;
  }

  private generateRecommendations(layerStatuses: GovernanceLayerStatus[]): string[] {
    const recommendations: string[] = [];

    for (const layer of layerStatuses) {
      if (layer.status === 'failed') {
        recommendations.push(`CRITICAL: ${layer.layer} requires immediate attention. ${layer.details}`);
      } else if (layer.status === 'warning') {
        recommendations.push(`WARNING: ${layer.layer} needs review. ${layer.details}`);
      }
    }

    if (recommendations.length === 0) {
      recommendations.push('All governance layers are functioning optimally. Continue current operations.');
    }

    return recommendations;
  }

  public saveReport(report: GovernanceReport, outputPath?: string): string {
    const defaultPath = path.join(process.cwd(), 'governance-reports');
    if (!fs.existsSync(defaultPath)) {
      fs.mkdirSync(defaultPath, { recursive: true });
    }

    const filename = `governance-report-${this.execution.id}-${Date.now()}.json`;
    const filepath = path.join(outputPath || defaultPath, filename);

    fs.writeFileSync(filepath, JSON.stringify(report, null, 2));

    logger.info('Governance report saved', {
      executionId: this.execution.id,
      filepath,
      complianceScore: report.complianceScore
    });

    return filepath;
  }

  public generateFinalSeal(): {
    sealId: string;
    timestamp: Date;
    executionId: string;
    complianceScore: number;
    signature: string;
    metadata: any;
  } {
    const seal = {
      sealId: `GL20-SEAL-${this.execution.id}-${Date.now()}`,
      timestamp: new Date(),
      executionId: this.execution.id,
      complianceScore: this.calculateComplianceScore(this.generateLayerStatuses()),
      signature: this.generateSignature(),
      metadata: {
        layers: this.execution.config.governanceLayers,
        metrics: this.execution.metrics,
        status: this.execution.status
      }
    };

    logger.info('Governance final seal generated', {
      sealId: seal.sealId,
      executionId: seal.executionId,
      complianceScore: seal.complianceScore
    });

    return seal;
  }

  private generateSignature(): string {
    const data = JSON.stringify({
      executionId: this.execution.id,
      timestamp: new Date().toISOString(),
      metrics: this.execution.metrics
    });

    return Buffer.from(data).toString('base64');
  }
}