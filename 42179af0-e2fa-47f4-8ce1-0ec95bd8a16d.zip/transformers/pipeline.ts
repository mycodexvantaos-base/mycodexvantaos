/**
 * Transformation Pipeline
 * GL01 - Performance Optimization Layer
 * GL05 - Algorithm Layer
 */

import { DataRecord, Transformation } from '../types';
import { DataValidator } from './validator';
import { DataCleaner } from './data-cleaner';
import { logger } from '../observability/logger';
import { metricsCollector } from '../observability/metrics';

export class TransformationPipeline {
  private transformations: Transformation[];
  private validators: Map<string, DataValidator>;
  private cleaners: Map<string, DataCleaner>;

  constructor(transformations: Transformation[]) {
    this.transformations = transformations
      .filter(t => t.enabled)
      .sort((a, b) => a.order - b.order);
    
    this.validators = new Map();
    this.cleaners = new Map();

    this.initializeComponents();
  }

  private initializeComponents(): void {
    for (const transformation of this.transformations) {
      switch (transformation.type) {
        case 'validation':
          this.validators.set(transformation.id, new DataValidator(transformation));
          break;
        case 'cleaning':
          this.cleaners.set(transformation.id, new DataCleaner(transformation));
          break;
        default:
          logger.warn(`Unsupported transformation type: ${transformation.type}`, {
            transformationId: transformation.id
          });
      }
    }

    logger.info('Transformation pipeline initialized', {
      totalTransformations: this.transformations.length,
      validators: this.validators.size,
      cleaners: this.cleaners.size
    });
  }

  public async transform(record: DataRecord): Promise<DataRecord> {
    const startTime = Date.now();
    let transformedRecord = record;

    for (const transformation of this.transformations) {
      const stepStartTime = Date.now();

      try {
        logger.debug(`Applying transformation: ${transformation.name}`, {
          transformationId: transformation.id,
          recordId: record.id,
          governanceLayer: transformation.governanceLayer
        });

        switch (transformation.type) {
          case 'validation':
            const validator = this.validators.get(transformation.id);
            if (validator) {
              const { valid, errors } = await validator.validate(transformedRecord);
              
              if (!valid && errors.some(e => e.severity === 'error')) {
                metricsCollector.incrementError(
                  'pipeline',
                  'transform',
                  'ValidationError',
                  transformation.governanceLayer
                );
                logger.error('Validation failed', {
                  transformationId: transformation.id,
                  recordId: record.id,
                  errors: errors.map(e => e.message)
                });
                throw new Error(`Validation failed: ${errors.map(e => e.message).join(', ')}`);
              }
              
              transformedRecord.metadata.validated = true;
            }
            break;

          case 'cleaning':
            const cleaner = this.cleaners.get(transformation.id);
            if (cleaner) {
              transformedRecord = await cleaner.clean(transformedRecord);
            }
            break;

          case 'normalization':
            transformedRecord = await this.normalizeData(transformedRecord, transformation);
            break;

          case 'enrichment':
            transformedRecord = await this.enrichData(transformedRecord, transformation);
            break;

          case 'aggregation':
            transformedRecord = await this.aggregateData(transformedRecord, transformation);
            break;
        }

        const stepDuration = (Date.now() - stepStartTime) / 1000;

        metricsCollector.recordLayerExecutionTime(
          'transformation',
          transformation.governanceLayer,
          transformation.name,
          stepDuration
        );

        logger.debug(`Transformation completed: ${transformation.name}`, {
          transformationId: transformation.id,
          recordId: record.id,
          duration: `${stepDuration}s`
        });

      } catch (error) {
        const stepDuration = (Date.now() - stepStartTime) / 1000;
        
        metricsCollector.incrementError(
          'pipeline',
          'transform',
          error instanceof Error ? error.name : 'UnknownError',
          transformation.governanceLayer
        );

        logger.error(`Transformation failed: ${transformation.name}`, {
          transformationId: transformation.id,
          recordId: record.id,
          error: error instanceof Error ? error.message : String(error),
          duration: `${stepDuration}s`
        });

        throw error;
      }
    }

    const totalDuration = (Date.now() - startTime) / 1000;

    metricsCollector.recordPipelineDuration(
      'transformation',
      'pipeline',
      totalDuration
    );

    logger.debug('Record transformation pipeline completed', {
      recordId: record.id,
      totalDuration: `${totalDuration}s`,
      transformationsApplied: this.transformations.length
    });

    return transformedRecord;
  }

  public async transformBatch(records: DataRecord[]): Promise<{
    success: DataRecord[];
    failed: Array<{ record: DataRecord; error: string }>;
  }> {
    const success: DataRecord[] = [];
    const failed: Array<{ record: DataRecord; error: string }> = [];

    for (const record of records) {
      try {
        const transformed = await this.transform(record);
        success.push(transformed);
      } catch (error) {
        failed.push({
          record,
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }

    logger.info('Batch transformation completed', {
      totalRecords: records.length,
      successCount: success.length,
      failedCount: failed.length,
      successRate: `${((success.length / records.length) * 100).toFixed(2)}%`
    });

    return { success, failed };
  }

  private async normalizeData(record: DataRecord, transformation: Transformation): Promise<DataRecord> {
    const normalizedRecord = { ...record };
    const rules = transformation.config.rules || [];

    for (const rule of rules) {
      if (rule.field) {
        const value = this.getNestedValue(record.data, rule.field);
        
        if (value !== undefined && value !== null) {
          normalizedRecord.data = this.setNestedValue(
            normalizedRecord.data,
            rule.field,
            this.normalizeValue(value, rule.type)
          );
        }
      }
    }

    return normalizedRecord;
  }

  private async enrichData(record: DataRecord, transformation: Transformation): Promise<DataRecord> {
    const enrichedRecord = { ...record };
    const enrichments = transformation.config.enrichments || [];

    for (const enrichment of enrichments) {
      if (enrichment.field && enrichment.value !== undefined) {
        enrichedRecord.data = this.setNestedValue(
          enrichedRecord.data,
          enrichment.field,
          enrichment.value
        );
      } else if (enrichment.field && enrichment.function) {
        const value = enrichment.function(record.data);
        enrichedRecord.data = this.setNestedValue(
          enrichedRecord.data,
          enrichment.field,
          value
        );
      }
    }

    return enrichedRecord;
  }

  private async aggregateData(record: DataRecord, transformation: Transformation): Promise<DataRecord> {
    return record;
  }

  private normalizeValue(value: any, type: string): any {
    switch (type) {
      case 'uppercase':
        return typeof value === 'string' ? value.toUpperCase() : value;
      case 'lowercase':
        return typeof value === 'string' ? value.toLowerCase() : value;
      case 'trim':
        return typeof value === 'string' ? value.trim() : value;
      case 'number':
        return typeof value === 'string' ? parseFloat(value) : value;
      case 'date':
        return new Date(value).toISOString();
      default:
        return value;
    }
  }

  private getNestedValue(obj: any, path: string): any {
    const keys = path.split('.');
    let value = obj;

    for (const key of keys) {
      if (value && typeof value === 'object') {
        value = value[key];
      } else {
        return undefined;
      }
    }

    return value;
  }

  private setNestedValue(obj: any, path: string, value: any): any {
    const keys = path.split('.');
    const lastKey = keys.pop();
    
    let current = obj;
    for (const key of keys) {
      if (!current[key]) {
        current[key] = {};
      }
      current = current[key];
    }
    
    if (lastKey) {
      current[lastKey] = value;
    }
    
    return obj;
  }

  public getTransformationStats(): {
    total: number;
    byType: Record<string, number>;
    byLayer: Record<string, number>;
  } {
    const byType: Record<string, number> = {};
    const byLayer: Record<string, number> = {};

    for (const transformation of this.transformations) {
      byType[transformation.type] = (byType[transformation.type] || 0) + 1;
      byLayer[transformation.governanceLayer] = (byLayer[transformation.governanceLayer] || 0) + 1;
    }

    return {
      total: this.transformations.length,
      byType,
      byLayer
    };
  }
}