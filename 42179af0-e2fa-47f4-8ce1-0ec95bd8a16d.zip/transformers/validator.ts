/**
 * Data Validator
 * GL11 - Testing Layer
 * GL15 - Stress Testing Layer
 */

import Ajv from 'ajv';
import { DataRecord, ValidationError, Transformation, GovernanceLayer } from '../types';
import { logger } from '../observability/logger';
import { metricsCollector } from '../observability/metrics';

export class DataValidator {
  private ajv: Ajv;
  private transformation: Transformation;

  constructor(transformation: Transformation) {
    this.transformation = transformation;
    this.ajv = new Ajv({ allErrors: true });
  }

  public async validate(record: DataRecord): Promise<{ valid: boolean; errors: ValidationError[] }> {
    const startTime = Date.now();
    const errors: ValidationError[] = [];

    try {
      const rules = this.transformation.config.rules || [];

      for (const rule of rules) {
        const validationErrors = this.validateRule(record, rule);
        errors.push(...validationErrors);
      }

      const duration = (Date.now() - startTime) / 1000;

      metricsCollector.recordLayerExecutionTime(
        'validation',
        this.transformation.governanceLayer,
        'validate',
        duration
      );

      const isValid = errors.filter(e => e.severity === 'error').length === 0;

      if (!isValid) {
        metricsCollector.incrementError(
          'validation',
          'transform',
          'ValidationError',
          this.transformation.governanceLayer
        );
      }

      logger.debug('Record validation completed', {
        recordId: record.id,
        valid: isValid,
        errorCount: errors.length,
        governanceLayer: this.transformation.governanceLayer
      });

      return { valid: isValid, errors };

    } catch (error) {
      const duration = (Date.now() - startTime) / 1000;
      
      metricsCollector.incrementError(
        'validation',
        'transform',
        error instanceof Error ? error.name : 'UnknownError',
        this.transformation.governanceLayer
      );

      logger.error('Validation failed', {
        recordId: record.id,
        error: error instanceof Error ? error.message : String(error),
        governanceLayer: this.transformation.governanceLayer
      });

      errors.push({
        recordId: record.id,
        field: 'all',
        message: error instanceof Error ? error.message : 'Unknown validation error',
        severity: 'error',
        governanceLayer: this.transformation.governanceLayer,
        timestamp: new Date()
      });

      return { valid: false, errors };
    }
  }

  private validateRule(record: DataRecord, rule: any): ValidationError[] {
    const errors: ValidationError[] = [];

    try {
      const value = this.getNestedValue(record.data, rule.field);

      if (rule.required && (value === undefined || value === null || value === '')) {
        errors.push({
          recordId: record.id,
          field: rule.field,
          message: `Field '${rule.field}' is required`,
          severity: 'error',
          governanceLayer: this.transformation.governanceLayer,
          timestamp: new Date()
        });
      }

      if (value !== undefined && value !== null) {
        if (rule.type) {
          if (!this.validateType(value, rule.type)) {
            errors.push({
              recordId: record.id,
              field: rule.field,
              message: `Field '${rule.field}' must be of type '${rule.type}'`,
              severity: 'error',
              governanceLayer: this.transformation.governanceLayer,
              timestamp: new Date()
            });
          }
        }

        if (rule.pattern && typeof value === 'string') {
          const regex = new RegExp(rule.pattern);
          if (!regex.test(value)) {
            errors.push({
              recordId: record.id,
              field: rule.field,
              message: `Field '${rule.field}' does not match pattern '${rule.pattern}'`,
              severity: 'warning',
              governanceLayer: this.transformation.governanceLayer,
              timestamp: new Date()
            });
          }
        }

        if (rule.min !== undefined && value < rule.min) {
          errors.push({
            recordId: record.id,
            field: rule.field,
            message: `Field '${rule.field}' must be at least ${rule.min}`,
            severity: 'warning',
            governanceLayer: this.transformation.governanceLayer,
            timestamp: new Date()
          });
        }

        if (rule.max !== undefined && value > rule.max) {
          errors.push({
            recordId: record.id,
            field: rule.field,
            message: `Field '${rule.field}' must be at most ${rule.max}`,
            severity: 'warning',
            governanceLayer: this.transformation.governanceLayer,
            timestamp: new Date()
          });
        }

        if (rule.enum && !rule.enum.includes(value)) {
          errors.push({
            recordId: record.id,
            field: rule.field,
            message: `Field '${rule.field}' must be one of: ${rule.enum.join(', ')}`,
            severity: 'error',
            governanceLayer: this.transformation.governanceLayer,
            timestamp: new Date()
          });
        }
      }

      if (rule.custom && typeof rule.custom === 'function') {
        try {
          const customResult = rule.custom(value, record);
          if (!customResult.valid) {
            errors.push({
              recordId: record.id,
              field: rule.field,
              message: customResult.message || 'Custom validation failed',
              severity: 'error',
              governanceLayer: this.transformation.governanceLayer,
              timestamp: new Date()
            });
          }
        } catch (error) {
          errors.push({
            recordId: record.id,
            field: rule.field,
            message: `Custom validation error: ${error instanceof Error ? error.message : String(error)}`,
            severity: 'error',
            governanceLayer: this.transformation.governanceLayer,
            timestamp: new Date()
          });
        }
      }

    } catch (error) {
      errors.push({
        recordId: record.id,
        field: rule.field,
        message: `Validation rule error: ${error instanceof Error ? error.message : String(error)}`,
        severity: 'error',
        governanceLayer: this.transformation.governanceLayer,
        timestamp: new Date()
      });
    }

    return errors;
  }

  private getNestedValue(obj: any, path: string): any {
    const keys = path.split('.');
    let value = obj;

    for (const key of keys) {
      if (value && typeof value === 'object') {
        value = value[key];
      } else {
        return undefined;
      }
    }

    return value;
  }

  private validateType(value: any, type: string): boolean {
    switch (type) {
      case 'string':
        return typeof value === 'string';
      case 'number':
        return typeof value === 'number' && !isNaN(value);
      case 'boolean':
        return typeof value === 'boolean';
      case 'date':
        return !isNaN(Date.parse(value));
      case 'array':
        return Array.isArray(value);
      case 'object':
        return typeof value === 'object' && !Array.isArray(value) && value !== null;
      default:
        return true;
    }
  }

  public async validateBatch(records: DataRecord[]): Promise<{ valid: boolean; errors: ValidationError[] }> {
    const allErrors: ValidationError[] = [];
    let hasCriticalErrors = false;

    for (const record of records) {
      const { valid, errors } = await this.validate(record);
      allErrors.push(...errors);

      if (!valid) {
        hasCriticalErrors = true;
      }
    }

    return {
      valid: !hasCriticalErrors,
      errors: allErrors
    };
  }
}