/**
 * Data Cleaner
 * GL01 - Performance Optimization Layer
 * GL07 - Security Layer
 */

import { DataRecord, Transformation } from '../types';
import { logger } from '../observability/logger';
import { metricsCollector } from '../observability/metrics';

export class DataCleaner {
  private transformation: Transformation;

  constructor(transformation: Transformation) {
    this.transformation = transformation;
  }

  public async clean(record: DataRecord): Promise<DataRecord> {
    const startTime = Date.now();

    try {
      let cleanedData = { ...record.data };
      const config = this.transformation.config;

      if (config.removeNulls) {
        cleanedData = this.removeNulls(cleanedData);
      }

      if (config.trimStrings) {
        cleanedData = this.trimStrings(cleanedData);
      }

      if (config.normalizeWhitespace) {
        cleanedData = this.normalizeWhitespace(cleanedData);
      }

      if (config.removeDuplicates) {
        cleanedData = this.removeDuplicates(cleanedData);
      }

      if (config.maskSensitiveFields) {
        cleanedData = this.maskSensitiveFields(cleanedData, config.sensitiveFields || []);
      }

      if (config.removePII) {
        cleanedData = this.removePII(cleanedData);
      }

      const cleanedRecord: DataRecord = {
        ...record,
        data: cleanedData,
        metadata: {
          ...record.metadata,
          transformed: true
        }
      };

      const duration = (Date.now() - startTime) / 1000;

      metricsCollector.recordLayerExecutionTime(
        'cleaning',
        this.transformation.governanceLayer,
        'clean',
        duration
      );

      logger.debug('Record cleaned successfully', {
        recordId: record.id,
        governanceLayer: this.transformation.governanceLayer,
        duration: `${duration}s`
      });

      return cleanedRecord;

    } catch (error) {
      const duration = (Date.now() - startTime) / 1000;
      
      metricsCollector.incrementError(
        'cleaning',
        'transform',
        error instanceof Error ? error.name : 'UnknownError',
        this.transformation.governanceLayer
      );

      logger.error('Data cleaning failed', {
        recordId: record.id,
        error: error instanceof Error ? error.message : String(error),
        governanceLayer: this.transformation.governanceLayer
      });

      throw error;
    }
  }

  private removeNulls(obj: any): any {
    if (Array.isArray(obj)) {
      return obj.filter(item => item !== null && item !== undefined);
    } else if (typeof obj === 'object' && obj !== null) {
      const cleaned: any = {};
      for (const [key, value] of Object.entries(obj)) {
        if (value !== null && value !== undefined) {
          cleaned[key] = this.removeNulls(value);
        }
      }
      return cleaned;
    }
    return obj;
  }

  private trimStrings(obj: any): any {
    if (typeof obj === 'string') {
      return obj.trim();
    } else if (Array.isArray(obj)) {
      return obj.map(item => this.trimStrings(item));
    } else if (typeof obj === 'object' && obj !== null) {
      const trimmed: any = {};
      for (const [key, value] of Object.entries(obj)) {
        trimmed[key] = this.trimStrings(value);
      }
      return trimmed;
    }
    return obj;
  }

  private normalizeWhitespace(obj: any): any {
    if (typeof obj === 'string') {
      return obj.replace(/\s+/g, ' ').trim();
    } else if (Array.isArray(obj)) {
      return obj.map(item => this.normalizeWhitespace(item));
    } else if (typeof obj === 'object' && obj !== null) {
      const normalized: any = {};
      for (const [key, value] of Object.entries(obj)) {
        normalized[key] = this.normalizeWhitespace(value);
      }
      return normalized;
    }
    return obj;
  }

  private removeDuplicates(obj: any): any {
    if (Array.isArray(obj)) {
      return [...new Set(obj)];
    }
    return obj;
  }

  private maskSensitiveFields(obj: any, sensitiveFields: string[]): any {
    if (!sensitiveFields || sensitiveFields.length === 0) {
      return obj;
    }

    const masked = { ...obj };

    for (const field of sensitiveFields) {
      if (masked[field]) {
        masked[field] = this.maskValue(masked[field]);
      }
    }

    return masked;
  }

  private removePII(obj: any): any {
    const piiPatterns = {
      email: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
      phone: /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g,
      ssn: /\b\d{3}[-.]?\d{2}[-.]?\d{4}\b/g,
      creditCard: /\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/g
    };

    const cleaned = JSON.parse(JSON.stringify(obj));

    const maskString = (str: string, pattern: RegExp): string => {
      return str.replace(pattern, '***');
    };

    const processValue = (value: any): any => {
      if (typeof value === 'string') {
        let masked = value;
        for (const [type, pattern] of Object.entries(piiPatterns)) {
          masked = maskString(masked, pattern as RegExp);
        }
        return masked;
      } else if (Array.isArray(value)) {
        return value.map(item => processValue(item));
      } else if (typeof value === 'object' && value !== null) {
        const cleaned: any = {};
        for (const [key, val] of Object.entries(value)) {
          cleaned[key] = processValue(val);
        }
        return cleaned;
      }
      return value;
    };

    return processValue(cleaned);
  }

  private maskValue(value: any): any {
    if (typeof value === 'string') {
      if (value.length <= 4) {
        return '****';
      }
      return value.substring(0, 2) + '****' + value.substring(value.length - 2);
    } else if (typeof value === 'number') {
      return '****';
    }
    return '****';
  }

  public async cleanBatch(records: DataRecord[]): Promise<DataRecord[]> {
    const cleanedRecords: DataRecord[] = [];

    for (const record of records) {
      try {
        const cleaned = await this.clean(record);
        cleanedRecords.push(cleaned);
      } catch (error) {
        logger.error('Failed to clean record', {
          recordId: record.id,
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }

    return cleanedRecords;
  }
}