/**
 * Base Loader Interface
 * GL02 - Data Access Layer
 */

import { DataDestination, DataRecord } from '../types';
import { logger } from '../observability/logger';
import { metricsCollector } from '../observability/metrics';

export abstract class BaseLoader {
  protected destination: DataDestination;

  constructor(destination: DataDestination) {
    this.destination = destination;
  }

  public abstract load(records: DataRecord[]): Promise<number>;
  public abstract close(): Promise<void>;

  protected async executeWithMetrics<T>(
    operation: string,
    fn: () => Promise<T>
  ): Promise<T> {
    const startTime = Date.now();
    const governanceLayer = this.destination.governanceLayer;

    try {
      logger.info(`Starting load operation: ${operation}`, {
        destinationId: this.destination.id,
        type: this.destination.type,
        governanceLayer
      });

      const result = await fn();
      const duration = (Date.now() - startTime) / 1000;

      metricsCollector.recordLayerExecutionTime(
        this.destination.id,
        governanceLayer,
        operation,
        duration
      );

      logger.info(`Completed load operation: ${operation}`, {
        destinationId: this.destination.id,
        duration: `${duration}s`,
        recordsProcessed: typeof result === 'number' ? result : 1
      });

      return result;
    } catch (error) {
      const duration = (Date.now() - startTime) / 1000;
      
      metricsCollector.incrementError(
        this.destination.id,
        'load',
        error instanceof Error ? error.name : 'UnknownError',
        governanceLayer
      );

      logger.error(`Load operation failed: ${operation}`, {
        destinationId: this.destination.id,
        error: error instanceof Error ? error.message : String(error),
        governanceLayer
      });

      throw error;
    }
  }

  protected getBatchSize(): number {
    return this.destination.config.batchSize || 1000;
  }

  protected async processBatches<T>(
    records: DataRecord[],
    processor: (batch: DataRecord[]) => Promise<T>
  ): Promise<number> {
    const batchSize = this.getBatchSize();
    let totalProcessed = 0;

    for (let i = 0; i < records.length; i += batchSize) {
      const batch = records.slice(i, i + batchSize);
      const processed = await processor(batch);
      totalProcessed += processed;

      logger.debug(`Batch processed`, {
        destinationId: this.destination.id,
        batchSize: batch.length,
        batchNumber: Math.floor(i / batchSize) + 1,
        totalBatches: Math.ceil(records.length / batchSize)
      });
    }

    return totalProcessed;
  }
}