/**
 * Loader Factory
 * GL02 - Data Access Layer
 */

import { DataDestination } from '../types';
import { BaseLoader } from './base-loader';
import { DatabaseLoader } from './database-loader';
import { logger } from '../observability/logger';

export class LoaderFactory {
  public static createLoader(destination: DataDestination): BaseLoader {
    logger.info('Creating loader', {
      destinationId: destination.id,
      type: destination.type,
      governanceLayer: destination.governanceLayer
    });

    switch (destination.type) {
      case 'database':
      case 'datawarehouse':
        return new DatabaseLoader(destination);
      
      default:
        throw new Error(`Unsupported destination type: ${destination.type}`);
    }
  }

  public static async createLoaders(destinations: DataDestination[]): Promise<BaseLoader[]> {
    const loaders: BaseLoader[] = [];

    for (const destination of destinations) {
      if (destination.enabled) {
        try {
          const loader = this.createLoader(destination);
          loaders.push(loader);
        } catch (error) {
          logger.error('Failed to create loader', {
            destinationId: destination.id,
            error: error instanceof Error ? error.message : String(error)
          });
          throw error;
        }
      }
    }

    return loaders;
  }
}

export { BaseLoader, DatabaseLoader };