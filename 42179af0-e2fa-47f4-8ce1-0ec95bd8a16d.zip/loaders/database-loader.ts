/**
 * Database Loader
 * GL02 - Data Access Layer
 */

import { Pool, PoolClient } from 'pg';
import { MongoClient, Db, Collection } from 'mongodb';
import { DataDestination, DataRecord } from '../types';
import { BaseLoader } from './base-loader';
import { logger } from '../observability/logger';

export class DatabaseLoader extends BaseLoader {
  private pgPool?: Pool;
  private mongoClient?: MongoClient;
  private mongoDb?: Db;
  private dbType: 'postgresql' | 'mongodb';

  constructor(destination: DataDestination) {
    super(destination);
    
    const connectionString = destination.config.connectionString;
    if (connectionString.startsWith('mongodb')) {
      this.dbType = 'mongodb';
    } else if (connectionString.startsWith('postgresql') || 
               connectionString.startsWith('postgres')) {
      this.dbType = 'postgresql';
    } else {
      throw new Error('Unsupported database type');
    }
  }

  public async load(records: DataRecord[]): Promise<number> {
    if (this.dbType === 'postgresql') {
      return this.loadToPostgreSQL(records);
    } else {
      return this.loadToMongoDB(records);
    }
  }

  private async loadToPostgreSQL(records: DataRecord[]): Promise<number> {
    return this.executeWithMetrics('load_postgresql', async () => {
      await this.connectPostgreSQL();
      
      const tableName = this.destination.config.tableName || 'records';
      const strategy = this.destination.strategy;
      
      await this.ensureTableExists(tableName);

      return this.processBatches(records, async (batch) => {
        let processed = 0;

        for (const record of batch) {
          try {
            if (strategy === 'append') {
              await this.insertRecordPostgreSQL(tableName, record);
            } else if (strategy === 'upsert') {
              await this.upsertRecordPostgreSQL(tableName, record);
            } else if (strategy === 'replace') {
              await this.replaceRecordPostgreSQL(tableName, record);
            }
            processed++;
          } catch (error) {
            logger.error('Failed to load record to PostgreSQL', {
              recordId: record.id,
              tableName,
              error: error instanceof Error ? error.message : String(error)
            });
          }
        }

        return processed;
      });
    });
  }

  private async loadToMongoDB(records: DataRecord[]): Promise<number> {
    return this.executeWithMetrics('load_mongodb', async () => {
      await this.connectMongoDB();
      
      const collectionName = this.destination.config.tableName || 'records';
      const strategy = this.destination.strategy;
      const collection = this.mongoDb!.collection(collectionName);

      return this.processBatches(records, async (batch) => {
        let processed = 0;

        for (const record of batch) {
          try {
            if (strategy === 'append') {
              await collection.insertOne({
                _id: record.id,
                ...record.data,
                metadata: record.metadata
              });
            } else if (strategy === 'upsert') {
              await collection.replaceOne(
                { _id: record.id },
                {
                  _id: record.id,
                  ...record.data,
                  metadata: record.metadata
                },
                { upsert: true }
              );
            } else if (strategy === 'replace') {
              await collection.deleteMany({});
              await collection.insertOne({
                _id: record.id,
                ...record.data,
                metadata: record.metadata
              });
            }
            processed++;
          } catch (error) {
            logger.error('Failed to load record to MongoDB', {
              recordId: record.id,
              collectionName,
              error: error instanceof Error ? error.message : String(error)
            });
          }
        }

        return processed;
      });
    });
  }

  private async connectPostgreSQL(): Promise<void> {
    if (!this.pgPool) {
      const connectionString = this.destination.config.connectionString;
      this.pgPool = new Pool({
        connectionString,
        max: 10
      });

      await this.pgPool.connect();
      logger.info('Connected to PostgreSQL loader', { destinationId: this.destination.id });
    }
  }

  private async connectMongoDB(): Promise<void> {
    if (!this.mongoClient) {
      const connectionString = this.destination.config.connectionString;
      this.mongoClient = new MongoClient(connectionString);
      
      await this.mongoClient.connect();
      
      const dbName = connectionString.split('/').pop()?.split('?')[0] || 'warehouse_db';
      this.mongoDb = this.mongoClient.db(dbName);
      
      logger.info('Connected to MongoDB loader', { destinationId: this.destination.id, dbName });
    }
  }

  private async ensureTableExists(tableName: string): Promise<void> {
    const client = await this.pgPool!.connect();
    
    try {
      await client.query(`
        CREATE TABLE IF NOT EXISTS ${tableName} (
          id VARCHAR(255) PRIMARY KEY,
          data JSONB NOT NULL,
          metadata JSONB NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
      
      await client.query(`
        CREATE INDEX IF NOT EXISTS idx_${tableName}_created_at 
        ON ${tableName}(created_at)
      `);
      
      await client.query(`
        CREATE INDEX IF NOT EXISTS idx_${tableName}_metadata 
        ON ${tableName} USING GIN(metadata)
      `);
      
    } finally {
      client.release();
    }
  }

  private async insertRecordPostgreSQL(tableName: string, record: DataRecord): Promise<void> {
    const query = `
      INSERT INTO ${tableName} (id, data, metadata)
      VALUES ($1, $2, $3)
    `;
    
    await this.pgPool!.query(query, [
      record.id,
      JSON.stringify(record.data),
      JSON.stringify(record.metadata)
    ]);
  }

  private async upsertRecordPostgreSQL(tableName: string, record: DataRecord): Promise<void> {
    const query = `
      INSERT INTO ${tableName} (id, data, metadata)
      VALUES ($1, $2, $3)
      ON CONFLICT (id) 
      DO UPDATE SET 
        data = EXCLUDED.data,
        metadata = EXCLUDED.metadata,
        updated_at = CURRENT_TIMESTAMP
    `;
    
    await this.pgPool!.query(query, [
      record.id,
      JSON.stringify(record.data),
      JSON.stringify(record.metadata)
    ]);
  }

  private async replaceRecordPostgreSQL(tableName: string, record: DataRecord): Promise<void> {
    await this.pgPool!.query(`DELETE FROM ${tableName}`);
    await this.insertRecordPostgreSQL(tableName, record);
  }

  public async close(): Promise<void> {
    try {
      if (this.pgPool) {
        await this.pgPool.end();
        logger.info('PostgreSQL loader connection closed', { destinationId: this.destination.id });
      }
      
      if (this.mongoClient) {
        await this.mongoClient.close();
        logger.info('MongoDB loader connection closed', { destinationId: this.destination.id });
      }
    } catch (error) {
      logger.error('Error closing loader connections', {
        destinationId: this.destination.id,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
}