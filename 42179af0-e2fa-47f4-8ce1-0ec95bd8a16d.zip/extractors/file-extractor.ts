/**
 * File Extractor
 * GL02 - Data Access Layer
 * Supports JSON, CSV, XLSX, PDF, and TXT files
 */

import fs from 'fs';
import path from 'path';
import csv from 'csv-parser';
import xlsx from 'xlsx';
import pdfParse from 'pdf-parse';
import { DataSource, DataRecord, FileConfig, IncrementalState } from '../types';
import { BaseExtractor } from './base-extractor';
import { logger } from '../observability/logger';

export class FileExtractor extends BaseExtractor {
  private config: FileConfig;

  constructor(source: DataSource) {
    super(source);
    this.config = source.config as FileConfig;
  }

  public async extract(): Promise<DataRecord[]> {
    return this.executeWithMetrics('extract_file', async () => {
      const filePath = this.resolvePath(this.config.path);
      
      if (!fs.existsSync(filePath)) {
        throw new Error(`File not found: ${filePath}`);
      }

      const stats = fs.statSync(filePath);
      let records: DataRecord[] = [];

      if (stats.isDirectory()) {
        records = await this.extractDirectory(filePath);
      } else {
        records = await this.extractSingleFile(filePath);
      }

      logger.info('File extraction completed', {
        sourceId: this.source.id,
        filePath,
        totalRecords: records.length,
        format: this.config.format
      });

      return records;
    });
  }

  public async extractIncremental(state: IncrementalState): Promise<DataRecord[]> {
    return this.executeWithMetrics('extract_incremental_file', async () => {
      const filePath = this.resolvePath(this.config.path);
      
      if (!fs.existsSync(filePath)) {
        throw new Error(`File not found: ${filePath}`);
      }

      const stats = fs.statSync(filePath);
      let records: DataRecord[] = [];

      if (stats.isDirectory()) {
        records = await this.extractDirectoryIncremental(filePath, state);
      } else {
        const fileStats = fs.statSync(filePath);
        if (fileStats.mtime > state.lastProcessedTimestamp) {
          records = await this.extractSingleFile(filePath);
        }
      }

      logger.info('Incremental file extraction completed', {
        sourceId: this.source.id,
        filePath,
        totalRecords: records.length,
        watermark: state.watermark
      });

      return records;
    });
  }

  private async extractDirectory(dirPath: string): Promise<DataRecord[]> {
    const records: DataRecord[] = [];
    const files = fs.readdirSync(dirPath);

    for (const file of files) {
      const filePath = path.join(dirPath, file);
      const stats = fs.statSync(filePath);

      if (stats.isDirectory()) {
        const dirRecords = await this.extractDirectory(filePath);
        records.push(...dirRecords);
      } else if (this.isSupportedFile(file)) {
        const fileRecords = await this.extractSingleFile(filePath);
        records.push(...fileRecords);
      }
    }

    return records;
  }

  private async extractDirectoryIncremental(
    dirPath: string,
    state: IncrementalState
  ): Promise<DataRecord[]> {
    const records: DataRecord[] = [];
    const files = fs.readdirSync(dirPath);

    for (const file of files) {
      const filePath = path.join(dirPath, file);
      const stats = fs.statSync(filePath);

      if (stats.isDirectory()) {
        const dirRecords = await this.extractDirectoryIncremental(filePath, state);
        records.push(...dirRecords);
      } else if (this.isSupportedFile(file) && stats.mtime > state.lastProcessedTimestamp) {
        const fileRecords = await this.extractSingleFile(filePath);
        records.push(...fileRecords);
      }
    }

    return records;
  }

  private async extractSingleFile(filePath: string): Promise<DataRecord[]> {
    const extension = path.extname(filePath).toLowerCase();
    const records: DataRecord[] = [];

    switch (extension) {
      case '.json':
        return await this.extractJSON(filePath);
      case '.csv':
        return await this.extractCSV(filePath);
      case '.xlsx':
      case '.xls':
        return await this.extractExcel(filePath);
      case '.pdf':
        return await this.extractPDF(filePath);
      case '.txt':
        return await this.extractText(filePath);
      default:
        throw new Error(`Unsupported file format: ${extension}`);
    }
  }

  private async extractJSON(filePath: string): Promise<DataRecord[]> {
    const content = fs.readFileSync(filePath, this.config.encoding);
    const data = JSON.parse(content.toString());

    if (Array.isArray(data)) {
      return data.map(item => this.createDataRecord(item, filePath));
    } else {
      return [this.createDataRecord(data, filePath)];
    }
  }

  private async extractCSV(filePath: string): Promise<DataRecord[]> {
    return new Promise((resolve, reject) => {
      const records: DataRecord[] = [];

      fs.createReadStream(filePath)
        .pipe(csv({
          separator: this.config.delimiter || ','
        }))
        .on('data', (row) => {
          records.push(this.createDataRecord(row, filePath));
        })
        .on('end', () => {
          resolve(records);
        })
        .on('error', (error) => {
          reject(error);
        });
    });
  }

  private async extractExcel(filePath: string): Promise<DataRecord[]> {
    const workbook = xlsx.readFile(filePath);
    const records: DataRecord[] = [];

    for (const sheetName of workbook.SheetNames) {
      const worksheet = workbook.Sheets[sheetName];
      const data = xlsx.utils.sheet_to_json(worksheet);

      data.forEach(row => {
        records.push(this.createDataRecord(row, `${filePath}:${sheetName}`));
      });
    }

    return records;
  }

  private async extractPDF(filePath: string): Promise<DataRecord[]> {
    const dataBuffer = fs.readFileSync(filePath);
    const data = await pdfParse(dataBuffer);

    return [{
      id: this.generateRecordId({ path: filePath }),
      data: {
        text: data.text,
        pages: data.numpages,
        info: data.info
      },
      metadata: {
        source: filePath,
        timestamp: new Date(),
        governanceLayer: this.source.governanceLayer,
        validated: false,
        transformed: false
      }
    }];
  }

  private async extractText(filePath: string): Promise<DataRecord[]> {
    const content = fs.readFileSync(filePath, this.config.encoding);
    const lines = content.toString().split('\n');

    return lines.map((line, index) => this.createDataRecord({
      line: index + 1,
      text: line.trim()
    }, filePath));
  }

  private isSupportedFile(filename: string): boolean {
    const supportedExtensions = ['.json', '.csv', '.xlsx', '.xls', '.pdf', '.txt'];
    const extension = path.extname(filename).toLowerCase();
    return supportedExtensions.includes(extension);
  }

  private resolvePath(filePath: string): string {
    if (path.isAbsolute(filePath)) {
      return filePath;
    }
    return path.resolve(process.cwd(), filePath);
  }

  public async close(): Promise<void> {
    logger.info('File extractor closed', { sourceId: this.source.id });
  }
}