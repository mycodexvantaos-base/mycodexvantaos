/**
 * Extractor Factory
 * GL02 - Data Access Layer
 * GL08 - Integration Layer
 */

import { DataSource, DataSourceType } from '../types';
import { BaseExtractor } from './base-extractor';
import { DatabaseExtractor } from './database-extractor';
import { APIExtractor } from './api-extractor';
import { FileExtractor } from './file-extractor';
import { logger } from '../observability/logger';

export class ExtractorFactory {
  public static createExtractor(source: DataSource): BaseExtractor {
    logger.info('Creating extractor', {
      sourceId: source.id,
      sourceType: source.type,
      governanceLayer: source.governanceLayer
    });

    switch (source.type) {
      case DataSourceType.DATABASE:
        return new DatabaseExtractor(source);
      
      case DataSourceType.API:
        return new APIExtractor(source);
      
      case DataSourceType.FILE:
        return new FileExtractor(source);
      
      case DataSourceType.LOGS:
        return new FileExtractor(source);
      
      default:
        throw new Error(`Unsupported source type: ${source.type}`);
    }
  }

  public static async createExtractors(sources: DataSource[]): Promise<BaseExtractor[]> {
    const extractors: BaseExtractor[] = [];

    for (const source of sources) {
      if (source.enabled) {
        try {
          const extractor = this.createExtractor(source);
          extractors.push(extractor);
        } catch (error) {
          logger.error('Failed to create extractor', {
            sourceId: source.id,
            error: error instanceof Error ? error.message : String(error)
          });
          throw error;
        }
      }
    }

    return extractors;
  }
}

export { BaseExtractor, DatabaseExtractor, APIExtractor, FileExtractor };