/**
 * API Extractor
 * GL08 - Integration Layer
 */

import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { DataSource, DataRecord, APIConfig, IncrementalState } from '../types';
import { BaseExtractor } from './base-extractor';
import { logger } from '../observability/logger';

export class APIExtractor extends BaseExtractor {
  private axiosInstance: AxiosInstance;
  private config: APIConfig;

  constructor(source: DataSource) {
    super(source);
    this.config = source.config as APIConfig;
    this.axiosInstance = this.createAxiosInstance();
  }

  private createAxiosInstance(): AxiosInstance {
    const instance = axios.create({
      baseURL: this.config.baseUrl,
      timeout: this.config.timeout,
      headers: {
        'Content-Type': 'application/json',
        ...this.config.headers
      }
    });

    if (this.config.auth) {
      switch (this.config.auth.type) {
        case 'bearer':
          instance.defaults.headers.common['Authorization'] = `Bearer ${this.config.auth.token}`;
          break;
        case 'basic':
          instance.defaults.auth = {
            username: this.config.auth.username!,
            password: this.config.auth.password!
          };
          break;
        case 'apikey':
          instance.defaults.headers.common['X-API-Key'] = this.config.auth.apiKey;
          break;
      }
    }

    instance.interceptors.response.use(
      (response) => {
        logger.debug('API request successful', {
          url: response.config.url,
          status: response.status,
          sourceId: this.source.id
        });
        return response;
      },
      (error) => {
        logger.error('API request failed', {
          url: error.config?.url,
          status: error.response?.status,
          error: error.message,
          sourceId: this.source.id
        });
        return Promise.reject(error);
      }
    );

    return instance;
  }

  public async extract(): Promise<DataRecord[]> {
    return this.executeWithMetrics('extract_api', async () => {
      const allRecords: DataRecord[] = [];
      
      for (const endpoint of this.config.endpoints) {
        const records = await this.extractFromEndpoint(endpoint);
        allRecords.push(...records);
      }

      logger.info('API extraction completed', {
        sourceId: this.source.id,
        totalRecords: allRecords.length,
        endpoints: this.config.endpoints.length
      });

      return allRecords;
    });
  }

  public async extractIncremental(state: IncrementalState): Promise<DataRecord[]> {
    return this.executeWithMetrics('extract_incremental_api', async () => {
      const allRecords: DataRecord[] = [];
      
      for (const endpoint of this.config.endpoints) {
        const records = await this.extractFromEndpointIncremental(endpoint, state);
        allRecords.push(...records);
      }

      logger.info('Incremental API extraction completed', {
        sourceId: this.source.id,
        totalRecords: allRecords.length,
        watermark: state.watermark
      });

      return allRecords;
    });
  }

  private async extractFromEndpoint(endpoint: string): Promise<DataRecord[]> {
    const records: DataRecord[] = [];
    let url = endpoint;
    let page = 1;
    let hasMore = true;

    while (hasMore) {
      try {
        const response = await this.fetchWithRetry(url);
        const data = this.parseResponseData(response);

        if (Array.isArray(data)) {
          data.forEach(item => {
            records.push(this.createDataRecord(item, `${this.source.id}:${endpoint}`));
          });

          if (this.hasNextPage(response, url, page)) {
            page++;
            url = this.buildPaginatedUrl(endpoint, page);
          } else {
            hasMore = false;
          }
        } else if (data) {
          records.push(this.createDataRecord(data, `${this.source.id}:${endpoint}`));
          hasMore = false;
        } else {
          hasMore = false;
        }

        await this.rateLimitDelay();

      } catch (error) {
        logger.error(`Failed to extract from endpoint: ${endpoint}`, {
          error: error instanceof Error ? error.message : String(error),
          page,
          sourceId: this.source.id
        });
        throw error;
      }
    }

    return records;
  }

  private async extractFromEndpointIncremental(
    endpoint: string,
    state: IncrementalState
  ): Promise<DataRecord[]> {
    const records: DataRecord[] = [];
    let url = this.buildIncrementalUrl(endpoint, state);
    let page = 1;
    let hasMore = true;

    while (hasMore) {
      try {
        const response = await this.fetchWithRetry(url);
        const data = this.parseResponseData(response);

        if (Array.isArray(data)) {
          const filteredData = this.filterByTimestamp(data, state.lastProcessedTimestamp);
          
          filteredData.forEach(item => {
            records.push(this.createDataRecord(item, `${this.source.id}:${endpoint}`));
          });

          if (filteredData.length === 0 || !this.hasNextPage(response, url, page)) {
            hasMore = false;
          } else {
            page++;
            url = this.buildPaginatedUrl(this.buildIncrementalUrl(endpoint, state), page);
          }
        } else if (data) {
          if (this.isRecordNew(data, state.lastProcessedTimestamp)) {
            records.push(this.createDataRecord(data, `${this.source.id}:${endpoint}`));
          }
          hasMore = false;
        } else {
          hasMore = false;
        }

        await this.rateLimitDelay();

      } catch (error) {
        logger.error(`Failed incremental extraction from endpoint: ${endpoint}`, {
          error: error instanceof Error ? error.message : String(error),
          page,
          sourceId: this.source.id
        });
        throw error;
      }
    }

    return records;
  }

  private async fetchWithRetry(url: string): Promise<AxiosResponse> {
    let lastError: Error | null = null;
    
    for (let attempt = 1; attempt <= this.config.retryAttempts; attempt++) {
      try {
        const response = await this.axiosInstance.get(url);
        return response;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        
        if (attempt < this.config.retryAttempts) {
          const delay = Math.pow(2, attempt) * 1000;
          logger.warn(`Retry attempt ${attempt}/${this.config.retryAttempts}`, {
            url,
            delay,
            error: lastError.message
          });
          await this.sleep(delay);
        }
      }
    }

    throw lastError;
  }

  private parseResponseData(response: AxiosResponse): any {
    if (response.data.data) {
      return response.data.data;
    }
    if (response.data.results) {
      return response.data.results;
    }
    if (response.data.items) {
      return response.data.items;
    }
    if (Array.isArray(response.data)) {
      return response.data;
    }
    return response.data;
  }

  private hasNextPage(response: AxiosResponse, url: string, page: number): boolean {
    if (response.data.pagination?.hasNextPage) {
      return true;
    }
    if (response.data.meta?.hasNextPage) {
      return true;
    }
    if (response.data.links?.next) {
      return true;
    }
    
    const data = this.parseResponseData(response);
    if (Array.isArray(data) && data.length > 0) {
      return true;
    }
    
    return false;
  }

  private buildPaginatedUrl(baseUrl: string, page: number): string {
    const url = new URL(baseUrl, this.config.baseUrl);
    url.searchParams.set('page', page.toString());
    return url.pathname + url.search;
  }

  private buildIncrementalUrl(endpoint: string, state: IncrementalState): string {
    const url = new URL(endpoint, this.config.baseUrl);
    url.searchParams.set('since', state.lastProcessedTimestamp.toISOString());
    url.searchParams.set('after', state.lastProcessedTimestamp.toISOString());
    return url.pathname + url.search;
  }

  private filterByTimestamp(data: any[], timestamp: Date): any[] {
    return data.filter(item => this.isRecordNew(item, timestamp));
  }

  private isRecordNew(item: any, timestamp: Date): boolean {
    const itemTimestamp = item.updated_at || item.updatedAt || 
                         item.created_at || item.createdAt || 
                         item.timestamp || item.date;
    
    if (!itemTimestamp) return true;
    
    return new Date(itemTimestamp) > timestamp;
  }

  private async rateLimitDelay(): Promise<void> {
    if (this.config.rateLimit > 0) {
      const delay = 1000 / this.config.rateLimit;
      await this.sleep(delay);
    }
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  public async close(): Promise<void> {
    this.axiosInstance = null as any;
    logger.info('API extractor closed', { sourceId: this.source.id });
  }
}