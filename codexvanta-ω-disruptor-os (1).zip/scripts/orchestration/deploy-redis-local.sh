#!/bin/bash
# deploy-redis-local.sh

set -euo pipefail

echo "🚀 Deploying Redis instance (Docker)..."

# 建立 Redis 容器
docker run -d \
  --name codexvanta-redis \
  --port 6379:6379 \
  --mount type=volume,source=redis-data,target=/data \
  --env REDIS_PASSWORD=$(openssl rand -base64 32) \
  redis:7-alpine \
  redis-server --requirepass "$REDIS_PASSWORD"

# 等待 Redis 啟動
sleep 3

# 測試連接
REDIS_HOST=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' codexvanta-redis)
REDIS_PORT=6379
REDIS_PASSWORD=$(docker inspect codexvanta-redis | grep -i 'requirepass' | sed 's/.*requirepass //')

echo "✅ Redis deployed at $REDIS_HOST:$REDIS_PORT"
echo "REDIS_PASSWORD: $REDIS_PASSWORD"

# 保存到環境檔案
cat > .env.redis.local <<EOF
ORCH_STATE_HOST=$REDIS_HOST
ORCH_STATE_PORT=$REDIS_PORT
ORCH_STATE_PASSWORD=$REDIS_PASSWORD
EOF

echo "✅ Configuration saved to .env.redis.local"
