#!/bin/bash
# pre-deployment-checklist.sh

set -euo pipefail

CHECKLIST_FILE="deployment-checklist.md"

cat > "$CHECKLIST_FILE" <<'EOF'
# CodexvantaOS 多重倉庫編排 - 生產部署檢查清單

## 環境配置
- [ ] Redis 實例已部署（開發/生產環境）
- [ ] Redis 連接已驗證
- [ ] 所有 GitHub 秘密已配置
- [ ] 秘密值已驗證正確性
- [ ] GitHub CLI 存取已確認

## 工作流程驗證
- [ ] orchestrator.yml 已推送到倉庫
- [ ] repository-runner.yml 已推送到倉庫
- [ ] validate-naming.yml 已推送到倉庫
- [ ] 所有工作流程語法已驗證
- [ ] 工作流程觸發權限已配置

## 腳本驗證
- [ ] 所有 Python 腳本已測試
- [ ] 依賴驗證腳本已執行
- [ ] 執行順序解析已驗證
- [ ] 回滾計劃生成已測試
- [ ] 報告生成已驗證

## 儲存庫配置
- [ ] 所有 25 個儲存庫已創建
- [ ] 儲存庫結構已驗證
- [ ] GitHub 權限已配置
- [ ] 分支保護規則已設置
- [ ] CODEOWNERS 已配置

## 安全檢查
- [ ] 秘密管理已驗證
- [ ] 存取控制已配置
- [ ] 審計日誌已啟用
- [ ] OPA 策略已部署
- [ ] 加密連接已啟用

## 監控與告警
- [ ] Redis 監控已配置
- [ ] 工作流程日誌已配置
- [ ] Prometheus 指標已配置
- [ ] 告警規則已設置
- [ ] 儀表板已建立

## 文檔與培訓
- [ ] 操作文檔已完成
- [ ] 故障排除指南已編寫
- [ ] 團隊培訓已進行
- [ ] 運維手冊已編寫
- [ ] 變更記錄已準備

## 最終批准
- [ ] Platform Team Lead 簽署
- [ ] Security Team Lead 簽署
- [ ] DevOps Lead 簽署

---

部署者簽名：________________  日期：__________
EOF

echo "✅ Checklist created: $CHECKLIST_FILE"
cat "$CHECKLIST_FILE"
