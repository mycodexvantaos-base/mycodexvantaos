#!/bin/bash
# verify-workflow-environment.sh

set -euo pipefail

GITHUB_OWNER=${GITHUB_OWNER:-"codexvanta"}
GITHUB_REPO_WORKFLOWS="codexvanta-os-workflows"

echo "🔍 Verifying workflow environment..."

# 檢查 1：GitHub CLI 存取
echo "  [1/6] Checking GitHub CLI access..."
gh repo view "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" > /dev/null && echo "    ✅ GitHub CLI access OK" || { echo "    ❌ GitHub CLI access failed"; exit 1; }

# 檢查 2：工作流程檔案存在
echo "  [2/6] Checking workflow files..."
WORKFLOWS=(
  "orchestrator.yml"
  "repository-runner.yml"
  "validate-naming.yml"
)

for wf in "${WORKFLOWS[@]}"; do
  gh api repos/"$GITHUB_OWNER"/"$GITHUB_REPO_WORKFLOWS"/contents/.github/workflows/"$wf" > /dev/null && \
    echo "    ✅ $wf exists" || \
    echo "    ⚠️  $wf not found"
done

# 檢查 3：秘密配置
echo "  [3/6] Checking secrets..."
SECRETS=(
  "ORCH_GITHUB_TOKEN"
  "ORCH_STATE_HOST"
  "ORCH_STATE_PORT"
  "ORCH_STATE_PASSWORD"
)

for secret in "${SECRETS[@]}"; do
  gh secret list --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" | grep -q "$secret" && \
    echo "    ✅ $secret configured" || \
    echo "    ❌ $secret missing"
done

# 檢查 4：儲存庫權限
echo "  [4/6] Checking repository permissions..."
PERMISSION=$(gh api repos/"$GITHUB_OWNER"/"$GITHUB_REPO_WORKFLOWS" --jq '.permissions.admin')
if [ "$PERMISSION" = "true" ]; then
  echo "    ✅ Admin permissions OK"
else
  echo "    ⚠️  No admin permissions (read-only access)"
fi

# 檢查 5：Redis 連接（如果已配置秘密）
echo "  [5/6] Checking Redis connectivity..."
if command -v redis-cli &> /dev/null; then
  source .env.redis.local 2>/dev/null || true
  if [ -n "$ORCH_STATE_HOST" ]; then
    redis-cli -h "$ORCH_STATE_HOST" -p "$ORCH_STATE_PORT" -a "$ORCH_STATE_PASSWORD" ping > /dev/null && \
      echo "    ✅ Redis connection OK" || \
      echo "    ❌ Redis connection failed"
  else
    echo "    ⚠️  Redis configuration not found locally"
  fi
else
  echo "    ⚠️  redis-cli not installed (skipping connection test)"
fi

# 檢查 6：Python 依賴
echo "  [6/6] Checking Python dependencies..."
python3 -c "import redis, yaml, json" 2>/dev/null && \
  echo "    ✅ Python dependencies installed" || \
  echo "    ❌ Missing Python dependencies (run: pip install redis pyyaml)"

echo ""
echo "✅ Environment verification complete"
