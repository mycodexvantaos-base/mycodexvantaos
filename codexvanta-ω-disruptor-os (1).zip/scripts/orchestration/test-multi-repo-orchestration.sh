#!/bin/bash
# test-multi-repo-orchestration.sh

set -euo pipefail

GITHUB_OWNER=${GITHUB_OWNER:-"codexvanta"}
GITHUB_REPO_WORKFLOWS="codexvanta-os-workflows"

echo "🧪 Testing multi-repository orchestration..."

# 定義測試儲存庫
TEST_REPOS=(
  "codexvanta-os-core-kernel"
  "codexvanta-os-core-main"
  "codexvanta-os-app-ui"
)

# 觸發編排器，指定特定儲存庫
echo "  Triggering orchestrator for test repositories..."
REPOS_JSON=$(printf '%s\n' "${TEST_REPOS[@]}" | jq -R . | jq -s .)

WORKFLOW_RUN=$(gh workflow run orchestrator.yml \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
  -f action=deploy \
  -f repositories="$(echo "$REPOS_JSON" | jq -r 'join(",")')" \
  -f dry_run=true \
  --json id \
  --jq '.id')

echo "  Workflow run ID: $WORKFLOW_RUN"

# 等待完成
echo "  Waiting for workflow to complete..."
for i in {1..60}; do
  STATUS=$(gh run view "$WORKFLOW_RUN" \
    --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
    --json status \
    --jq '.status')
  
  if [ "$STATUS" = "completed" ]; then
    echo "  ✅ Workflow completed"
    break
  fi
  
  echo "    Progress: $i/60 (Status: $STATUS)..."
  sleep 10
done

# 驗證執行順序
echo "  Validating execution order..."
python3 <<EOF
import json
import subprocess

# 獲取編排狀態
result = subprocess.run(
  ["gh", "run", "view", "$WORKFLOW_RUN", "--json", "jobs"],
  capture_output=True,
  text=True
)

jobs = json.loads(result.stdout)["jobs"]

# 驗證依賴順序
for job in jobs:
  print(f"Job: {job['name']} -> {job['status']}")

print("✅ Execution order validation complete")
EOF
