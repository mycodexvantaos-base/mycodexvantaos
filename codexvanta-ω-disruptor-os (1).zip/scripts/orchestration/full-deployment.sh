#!/bin/bash
# full-deployment.sh - 完整的自動化部署流程

set -euo pipefail

# 顏色定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 配置
GITHUB_OWNER=${GITHUB_OWNER:-"codexvanta"}
DEPLOYMENT_ENV=${DEPLOYMENT_ENV:-"staging"}  # staging or production
LOG_FILE="deployment-$(date +%Y%m%d-%H%M%S).log"

# 日誌函數
log_info() {
  echo -e "${GREEN}[INFO]${NC} $1" | tee -a "$LOG_FILE"
}

log_warn() {
  echo -e "${YELLOW}[WARN]${NC} $1" | tee -a "$LOG_FILE"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
}

# 步驟計數器
STEP=1
TOTAL_STEPS=8

print_step() {
  echo ""
  log_info "[$STEP/$TOTAL_STEPS] $1"
  STEP=$((STEP + 1))
}

# ============================================================================
# 步驟 1：環境檢查
# ============================================================================
print_step "Environment Check"

log_info "Checking prerequisites..."
command -v docker &> /dev/null || log_error "Docker not found"
command -v gh &> /dev/null || log_error "GitHub CLI not found"
command -v python3 &> /dev/null || log_error "Python3 not found"
command -v redis-cli &> /dev/null || log_warn "redis-cli not found (connection tests will be skipped)"

log_info "Environment check complete"

# ============================================================================
# 步驟 2：Redis 部署
# ============================================================================
print_step "Redis Deployment"

if [ "$DEPLOYMENT_ENV" = "staging" ]; then
  log_info "Deploying Redis locally (staging)..."
  bash deploy-redis-local.sh
elif [ "$DEPLOYMENT_ENV" = "production" ]; then
  log_info "Deploying Redis to cloud (production)..."
  CLOUD_PROVIDER="${CLOUD_PROVIDER:-aws}" bash deploy-redis-cloud.sh
fi

# ============================================================================
# 步驟 3：GitHub 秘密配置
# ============================================================================
print_step "GitHub Secrets Configuration"

log_info "Configuring GitHub secrets..."
bash configure-github-secrets.sh

# ============================================================================
# 步驟 4：工作流程環境驗證
# ============================================================================
print_step "Workflow Environment Verification"

log_info "Verifying workflow environment..."
bash verify-workflow-environment.sh

# ============================================================================
# 步驟 5：單個儲存庫同步測試
# ============================================================================
print_step "Single Repository Sync Test"

log_info "Testing single repository sync..."
bash test-single-repo-sync.sh

# ============================================================================
# 步驟 6：跨儲存庫編排測試
# ============================================================================
print_step "Multi-Repository Orchestration Test"

log_info "Testing multi-repository orchestration..."
bash test-multi-repo-orchestration.sh

# ============================================================================
# 步驟 7：錯誤處理與回滾測試
# ============================================================================
print_step "Error Handling and Rollback Tests"

log_info "Testing error handling and rollback..."
bash test-error-handling-and-rollback.sh

# ============================================================================
# 步驟 8：生產部署（如果 env=production）
# ============================================================================
if [ "$DEPLOYMENT_ENV" = "production" ]; then
  print_step "Production Deployment"
  
  log_warn "About to deploy to PRODUCTION!"
  read -p "Are you sure? (yes/no) " -n 3 -r
  echo
  if [[ $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
    bash deploy-to-production.sh
  else
    log_warn "Production deployment cancelled"
  fi
else
  print_step "Staging Deployment Complete"
  log_info "Staging deployment finished. To deploy to production:"
  log_info "  DEPLOYMENT_ENV=production bash full-deployment.sh"
fi

# ============================================================================
# 完成
# ============================================================================
echo ""
log_info "Deployment process completed."
