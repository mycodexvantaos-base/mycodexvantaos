#!/bin/bash
# test-single-repo-sync.sh

set -euo pipefail

GITHUB_OWNER=${GITHUB_OWNER:-"codexvanta"}
GITHUB_REPO_WORKFLOWS="codexvanta-os-workflows"

echo "🧪 Testing single repository sync..."

# 觸發 orchestrator 工作流程（試演模式）
echo "  Triggering orchestrator in dry-run mode..."
WORKFLOW_RUN=$(gh workflow run orchestrator.yml \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
  -f action=sync \
  -f dry_run=true \
  --json id \
  --jq '.id')

echo "  Workflow run ID: $WORKFLOW_RUN"

# 等待工作流程完成
echo "  Waiting for workflow to complete..."
for i in {1..60}; do
  STATUS=$(gh run view "$WORKFLOW_RUN" \
    --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
    --json status \
    --jq '.status')
  
  if [ "$STATUS" = "completed" ]; then
    echo "  ✅ Workflow completed"
    break
  fi
  
  echo "    Progress: $i/60 (Status: $STATUS)..."
  sleep 10
done

# 檢查結果
echo "  Checking workflow results..."
CONCLUSION=$(gh run view "$WORKFLOW_RUN" \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
  --json conclusion \
  --jq '.conclusion')

if [ "$CONCLUSION" = "success" ]; then
  echo "✅ Single repository sync test PASSED"
else
  echo "❌ Single repository sync test FAILED (conclusion: $CONCLUSION)"
  echo ""
  echo "Workflow logs:"
  gh run view "$WORKFLOW_RUN" \
    --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
    --log
  exit 1
fi
