#!/bin/bash
# deploy-to-production.sh

set -euo pipefail

echo "🚀 Deploying CodexvantaOS Multi-Repo Orchestration to Production..."

# 步驟 1：最終驗證
echo "Step 1/5: Final verification..."
bash pre-deployment-checklist.sh

# 步驟 2：備份當前配置
echo "Step 2/5: Backing up current configuration..."
BACKUP_DIR="backups/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"
cp registry/repos.yaml "$BACKUP_DIR/"
cp registry/dependencies.yaml "$BACKUP_DIR/"
cp registry/queue-config.yaml "$BACKUP_DIR/"
echo "✅ Backup created in $BACKUP_DIR"

# 步驟 3：部署工作流程
echo "Step 3/5: Deploying workflows..."
git add .github/workflows/
git commit -m "chore: deploy orchestration workflows to production"
git push origin main

echo "Waiting for workflow deployment..."
sleep 30

# 步驟 4：驗證部署
echo "Step 4/5: Verifying deployment..."
bash verify-workflow-environment.sh

# 步驟 5：啟用編排
echo "Step 5/5: Enabling orchestration..."
gh workflow enable orchestrator.yml \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS"

echo ""
echo "✅ Production deployment complete!"
echo ""
echo "Next steps:"
echo "1. Monitor workflows at: https://github.com/$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS/actions"
echo "2. Check metrics at: [monitoring dashboard URL]"
echo "3. Review logs at: [log aggregation URL]"
