#!/bin/bash
# configure-github-secrets.sh

set -euo pipefail

GITHUB_OWNER=${GITHUB_OWNER:-"codexvanta"}
GITHUB_REPO_WORKFLOWS="codexvanta-os-workflows"
GITHUB_REPO_CONTROL="codexvanta-os-control-center"

echo "🔐 Configuring GitHub secrets..."

# 從 .env.redis.local 讀取秘密（或從外部來源）
source .env.redis.local

# 驗證秘密變數
if [ -z "$ORCH_STATE_HOST" ] || [ -z "$ORCH_STATE_PORT" ] || [ -z "$ORCH_STATE_PASSWORD" ]; then
  echo "❌ Missing Redis configuration. Please set ORCH_STATE_* variables."
  exit 1
fi

# GitHub CLI 登入（如未登入）
gh auth status || gh auth login

# 為 workflows 倉庫配置秘密
echo "Setting secrets for $GITHUB_REPO_WORKFLOWS..."

gh secret set ORCH_GITHUB_TOKEN \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
  --body "$(gh auth token)"

gh secret set ORCH_STATE_HOST \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
  --body "$ORCH_STATE_HOST"

gh secret set ORCH_STATE_PORT \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
  --body "$ORCH_STATE_PORT"

gh secret set ORCH_STATE_PASSWORD \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS" \
  --body "$ORCH_STATE_PASSWORD"

# 為 control-center 倉庫配置秘密
echo "Setting secrets for $GITHUB_REPO_CONTROL..."

gh secret set ORCH_GITHUB_TOKEN \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_CONTROL" \
  --body "$(gh auth token)"

gh secret set ORCH_STATE_HOST \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_CONTROL" \
  --body "$ORCH_STATE_HOST"

gh secret set ORCH_STATE_PORT \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_CONTROL" \
  --body "$ORCH_STATE_PORT"

gh secret set ORCH_STATE_PASSWORD \
  --repo "$GITHUB_OWNER/$GITHUB_REPO_CONTROL" \
  --body "$ORCH_STATE_PASSWORD"

echo "✅ GitHub secrets configured successfully"

# 列出所有秘密（不顯示內容）
echo ""
echo "📋 Configured secrets:"
gh secret list --repo "$GITHUB_OWNER/$GITHUB_REPO_WORKFLOWS"
