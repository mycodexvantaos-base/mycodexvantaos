#!/bin/bash
# test-error-handling-and-rollback.sh

set -euo pipefail

echo "🧪 Testing error handling and rollback..."

# 測試 1：模擬儲存庫失敗
echo "  [Test 1] Repository-level failure isolation..."
python3 scripts/orchestration/validate-dependencies.py \
  --deps-file registry/dependencies.yaml \
  --repos-file registry/repos.yaml \
  && echo "    ✅ Validation passed" || echo "    ❌ Validation failed"

# 測試 2：循環依賴檢測
echo "  [Test 2] Circular dependency detection..."
python3 <<EOF
import yaml

# 讀取依賴
with open('registry/dependencies.yaml', 'r') as f:
  deps = yaml.safe_load(f)

# 簡單的循環檢測
def has_cycle(deps):
  visited = set()
  rec_stack = set()
  
  def dfs(node):
    visited.add(node)
    rec_stack.add(node)
    
    if node in deps.get('dependencies', {}):
      for dep in deps['dependencies'][node]:
        if dep not in visited:
          if dfs(dep):
            return True
        elif dep in rec_stack:
          return True
    
    rec_stack.remove(node)
    return False
  
  for node in deps.get('dependencies', {}):
    if node not in visited:
      if dfs(node):
        print("❌ Circular dependency detected")
        return True
  
  print("✅ No circular dependencies found")
  return False

has_cycle(deps)
EOF

# 測試 3：回滾計劃生成
echo "  [Test 3] Rollback plan generation..."
python3 scripts/orchestration/rollback-manager.py \
  --orchestration-id "test-run-123" \
  --strategy auto \
  && echo "    ✅ Rollback plan generated" || echo "    ❌ Rollback plan failed"

echo "✅ Error handling and rollback tests complete"
