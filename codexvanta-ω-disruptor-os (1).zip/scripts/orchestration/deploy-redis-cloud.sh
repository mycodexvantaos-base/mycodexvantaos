#!/bin/bash
# deploy-redis-cloud.sh

set -euo pipefail

# 使用環境變數選擇平台
CLOUD_PROVIDER=${CLOUD_PROVIDER:-"aws"}

case "$CLOUD_PROVIDER" in
  aws)
    echo "🚀 Deploying Redis on AWS ElastiCache..."
    aws elasticache create-cache-cluster \
      --cache-cluster-id codexvanta-redis \
      --cache-node-type cache.t3.micro \
      --engine redis \
      --engine-version 7.0 \
      --num-cache-nodes 1 \
      --port 6379 \
      --parameter-group-name default.redis7 \
      --region us-east-1
    
    # 等待建立完成
    sleep 60
    
    # 獲取端點
    ENDPOINT=$(aws elasticache describe-cache-clusters \
      --cache-cluster-id codexvanta-redis \
      --query 'CacheClusters[0].CacheNodes[0].Endpoint.Address' \
      --output text)
    
    echo "✅ Redis available at $ENDPOINT:6379"
    ;;
    
  gcp)
    echo "🚀 Deploying Redis on Google Cloud Memorystore..."
    gcloud redis instances create codexvanta-redis \
      --size=1 \
      --region=us-central1 \
      --redis-version=7.0
    
    # 等待建立完成
    sleep 60
    
    # 獲取 IP
    REDIS_HOST=$(gcloud redis instances describe codexvanta-redis \
      --region=us-central1 \
      --format='value(host)')
    
    echo "✅ Redis available at $REDIS_HOST:6379"
    ;;
    
  azure)
    echo "🚀 Deploying Redis on Azure Cache for Redis..."
    az redis create \
      --resource-group codexvanta-rg \
      --name codexvanta-redis \
      --sku Basic \
      --vm-size c0
    
    # 獲取連接字符串
    REDIS_CONNECTION=$(az redis list-keys \
      --resource-group codexvanta-rg \
      --name codexvanta-redis \
      --query primaryKey \
      --output tsv)
    
    echo "✅ Redis connection key: $REDIS_CONNECTION"
    ;;
esac

# 驗證連接
echo "🔍 Verifying Redis connection..."
redis-cli -h "$ORCH_STATE_HOST" -p "$ORCH_STATE_PORT" -a "$ORCH_STATE_PASSWORD" ping

echo "✅ Redis deployment complete"
