import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';

const app = express();
const PORT = 3000;
app.use(express.json());

// Phase 4: In-memory Vector Database
interface VectorRecord {
  id: string;
  text: string;
  embedding: number[];
  timestamp: string;
}
const vectorDB: VectorRecord[] = [];

// Helper: Cosine Similarity
function cosineSimilarity(a: number[], b: number[]) {
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

app.post('/api/vector-search', (req, res) => {
  try {
    const { text, embedding } = req.body;
    
    if (!embedding || !Array.isArray(embedding)) {
      return res.status(400).json({ error: 'Invalid embedding' });
    }

    let similarityNote = "";
    let maxSimilarity = -1;
    let mostSimilarText = "";
    
    for (const record of vectorDB) {
      const sim = cosineSimilarity(embedding, record.embedding);
      if (sim > maxSimilarity) {
        maxSimilarity = sim;
        mostSimilarText = record.text;
      }
    }

    if (maxSimilarity > 0.85) {
      similarityNote = `[VECTOR_DB_MATCH: ${(maxSimilarity * 100).toFixed(1)}% similarity to past anomaly]`;
    }

    // Store new vector
    vectorDB.push({
      id: Math.random().toString(36).substring(7),
      text,
      embedding,
      timestamp: new Date().toISOString()
    });

    res.json({ similarityNote });
  } catch (error: any) {
    console.error('Vector DB Error:', error);
    res.status(500).json({ error: error.message || 'Vector search failed' });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
