/**
 * Ω-Disruptor Protocol Definitions & CodexvantaOS Module Types
 */

export enum ModuleStatus {
  ONLINE = 'ONLINE',
  OFFLINE = 'OFFLINE',
  DEGRADED = 'DEGRADED',
  SYNCING = 'SYNCING',
  DISRUPTED = 'DISRUPTED'
}

export interface OSModule {
  id: string;
  name: string;
  version: string;
  status: ModuleStatus;
  load: number; // 0-100
  description: string;
}

export interface TruthAnalysisResult {
  id: string;
  timestamp: string;
  semanticDepth: number;
  adversarialScore: number;
  cognitiveStress: number;
  revelation: string;
  status: 'VALIDATED' | 'PENDING' | 'REJECTED';
}

export interface SystemRegistry {
  kernel: OSModule;
  aiEngine: OSModule;
  truthAnalysisCamp: OSModule;
  modules: OSModule[];
}
