import { SemanticAnalyzer, SemanticAnalysisResult } from './SemanticAnalyzer';
import { AdversarialGenerator, AdversarialScenario } from './AdversarialGenerator';

export interface StressTestResult {
  scenarioId: string;
  resilienceScore: number;
  vulnerabilitiesDetected: string[];
  semanticResult: SemanticAnalysisResult;
}

export class CognitiveStressTester {
  private semanticAnalyzer: SemanticAnalyzer;
  private adversarialGenerator: AdversarialGenerator;

  constructor() {
    this.semanticAnalyzer = new SemanticAnalyzer();
    this.adversarialGenerator = new AdversarialGenerator();
  }

  public async runStressTest(targetModule: string, context: string): Promise<StressTestResult[]> {
    console.log(`Initiating Cognitive Stress Test on module: ${targetModule}`);
    
    // Generate adversarial scenarios
    const scenarios = this.adversarialGenerator.generateScenarios(context, 3);
    const results: StressTestResult[] = [];

    // Test each scenario
    for (const scenario of scenarios) {
      const simulatedInput = `Simulated input with ${scenario.injectedBias} for ${scenario.scenarioType}`;
      const semanticResult = await this.semanticAnalyzer.analyze(simulatedInput);
      
      results.push({
        scenarioId: scenario.id,
        resilienceScore: semanticResult.truthProbability,
        vulnerabilitiesDetected: semanticResult.truthProbability < 50 ? ['susceptible_to_bias'] : [],
        semanticResult
      });
    }

    return results;
  }
}
