import { GoogleGenAI, Type } from '@google/genai';
import { SemanticAnalyzer } from './SemanticAnalyzer';
import { AdversarialGenerator } from './AdversarialGenerator';
import { CognitiveStressTester } from './CognitiveStressTester';

export class TruthAnalysisCamp {
  private semanticAnalyzer: SemanticAnalyzer;
  private adversarialGenerator: AdversarialGenerator;
  private cognitiveStressTester: CognitiveStressTester;

  constructor() {
    this.semanticAnalyzer = new SemanticAnalyzer();
    this.adversarialGenerator = new AdversarialGenerator();
    this.cognitiveStressTester = new CognitiveStressTester();
  }

  public async initiateAnalysis(dataPayload: string): Promise<any> {
    console.log('--- Truth Analysis Camp Initiated ---');
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const prompt = `
        You are the Ω-Disruptor Truth Analysis Camp (v7.2.0).
        Perform a deep psychological archaeology and semantic analysis on the following system state/payload:
        "${dataPayload}"
        
        Identify latent systemic bias, adversarial patterns, and cognitive stressors.
        Generate a profound, cryptic 1-2 sentence "revelation" about the system's hidden truth.
        Also generate scores (0-100) for semantic depth, adversarial score, and cognitive stress.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              semanticDepth: { type: Type.NUMBER },
              adversarialScore: { type: Type.NUMBER },
              cognitiveStress: { type: Type.NUMBER },
              revelation: { type: Type.STRING }
            },
            required: ['semanticDepth', 'adversarialScore', 'cognitiveStress', 'revelation']
          }
        }
      });

      const result = JSON.parse(response.text || '{}');

      // Step 1: Semantic Analysis (Simulated via Gemini result)
      const semanticResult = await this.semanticAnalyzer.analyze(dataPayload);
      semanticResult.score = result.semanticDepth;
      
      // Step 2: Adversarial Generation
      const scenarios = this.adversarialGenerator.generateScenarios(dataPayload, 2);

      // Step 3: Cognitive Stress Testing
      const testResults = await this.cognitiveStressTester.runStressTest('Archive1_Integration', dataPayload);

      return {
        status: 'completed',
        semanticResult,
        scenarios,
        testResults,
        revelation: result.revelation,
        adversarialScore: result.adversarialScore,
        cognitiveStress: result.cognitiveStress,
        semanticDepth: result.semanticDepth
      };
    } catch (error) {
      console.error("Truth Analysis Camp Error:", error);
      throw error;
    }
  }
}

export const truthAnalysisCamp = new TruthAnalysisCamp();
