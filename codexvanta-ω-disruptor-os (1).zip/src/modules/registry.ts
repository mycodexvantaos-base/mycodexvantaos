import { OSModule, ModuleStatus, SystemRegistry } from '../types/os';

export const INITIAL_REGISTRY: SystemRegistry = {
  kernel: {
    id: 'cv-core-001',
    name: 'Codexvanta Core Kernel',
    version: '2.4.0',
    status: ModuleStatus.ONLINE,
    load: 12,
    description: 'Primary orchestration layer for distributed services.'
  },
  aiEngine: {
    id: 'cv-ai-002',
    name: 'AI Decision Engine',
    version: '1.8.5',
    status: ModuleStatus.ONLINE,
    load: 45,
    description: 'Neural processing unit for autonomous governance.'
  },
  truthAnalysisCamp: {
    id: 'omega-tac-026',
    name: 'Truth Analysis Camp',
    version: '7.2.0',
    status: ModuleStatus.SYNCING,
    load: 88,
    description: 'Psychological archaeology and truth revelation module.'
  },
  modules: [
    { id: 'cv-auth-003', name: 'Auth Service', version: '1.2.0', status: ModuleStatus.ONLINE, load: 5, description: 'Identity and access management.' },
    { id: 'cv-event-004', name: 'Event Bus', version: '3.1.0', status: ModuleStatus.ONLINE, load: 22, description: 'High-throughput message distribution.' },
    { id: 'cv-data-005', name: 'Data Pipeline', version: '2.0.1', status: ModuleStatus.DEGRADED, load: 95, description: 'Real-time stream processing.' },
    { id: 'omega-sem-003', name: 'Semantic Analyzer', version: '2.1.0', status: ModuleStatus.ONLINE, load: 30, description: 'Deep linguistic structure analysis.' },
    { id: 'omega-adv-004', name: 'Adversarial Generator', version: '3.1.0', status: ModuleStatus.ONLINE, load: 15, description: 'Stress testing via synthetic conflict.' }
  ]
};
