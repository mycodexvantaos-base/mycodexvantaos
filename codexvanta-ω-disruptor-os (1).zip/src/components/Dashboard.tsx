import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Type } from '@google/genai';
import { 
  Activity, 
  Shield, 
  Zap, 
  Database, 
  Cpu, 
  Search, 
  AlertTriangle, 
  Terminal,
  Layers,
  Eye
} from 'lucide-react';
import { INITIAL_REGISTRY } from '../modules/registry';
import { ModuleStatus, OSModule, TruthAnalysisResult } from '../types/os';

const StatusBadge = ({ status }: { status: ModuleStatus }) => {
  const colors = {
    [ModuleStatus.ONLINE]: 'bg-green-500/20 text-green-400 border-green-500/50',
    [ModuleStatus.OFFLINE]: 'bg-red-500/20 text-red-400 border-red-500/50',
    [ModuleStatus.DEGRADED]: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
    [ModuleStatus.SYNCING]: 'bg-blue-500/20 text-blue-400 border-blue-500/50',
    [ModuleStatus.DISRUPTED]: 'bg-purple-500/20 text-purple-400 border-purple-500/50',
  };

  return (
    <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono border ${colors[status]}`}>
      {status}
    </span>
  );
};

export default function Dashboard() {
  const [registry, setRegistry] = useState(INITIAL_REGISTRY);
  const [activeTab, setActiveTab] = useState<'overview' | 'truth' | 'terminal' | 'monitoring'>('overview');
  const [analysisHistory, setAnalysisHistory] = useState<TruthAnalysisResult[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const runTruthAnalysis = async () => {
    setIsAnalyzing(true);
    try {
      const { truthAnalysisCamp } = await import('../modules/truth-analysis');
      
      const payload = "CodexvantaOS System State: " + JSON.stringify(registry);
      const result = await truthAnalysisCamp.initiateAnalysis(payload);

      const newResult: TruthAnalysisResult = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date().toISOString(),
        semanticDepth: result.semanticDepth,
        adversarialScore: result.adversarialScore,
        cognitiveStress: result.cognitiveStress,
        revelation: result.revelation,
        status: 'VALIDATED'
      };
      
      setAnalysisHistory(prev => [newResult, ...prev]);
    } catch (error: any) {
      console.error('Failed to run truth analysis:', error);
      // Fallback in case of error
      const errorResult: TruthAnalysisResult = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date().toISOString(),
        semanticDepth: 0,
        adversarialScore: 100,
        cognitiveStress: 100,
        revelation: `CRITICAL ERROR: ${error.message}`,
        status: 'DISRUPTED' as any
      };
      setAnalysisHistory(prev => [errorResult, ...prev]);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#E4E3E0] font-sans selection:bg-orange-500/30">
      {/* Header */}
      <header className="border-b border-[#1A1A1C] p-4 flex justify-between items-center bg-[#0A0A0B]/80 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-orange-600 rounded flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-widest uppercase">Codexvanta Ω-OS</h1>
            <p className="text-[10px] text-gray-500 font-mono">SYSTEM_VERSION: 7.2.0-STABLE</p>
          </div>
        </div>
        <nav className="flex gap-6">
          {['overview', 'truth', 'monitoring', 'terminal'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`text-[11px] uppercase tracking-widest font-bold transition-colors ${
                activeTab === tab ? 'text-orange-500' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              {tab}
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-4 text-[10px] font-mono text-gray-500">
          <div className="flex items-center gap-1">
            <Activity className="w-3 h-3 text-green-500" />
            <span>CORE: STABLE</span>
          </div>
          <div className="flex items-center gap-1">
            <Zap className="w-3 h-3 text-yellow-500" />
            <span>LATENCY: 14ms</span>
          </div>
        </div>
      </header>

      <main className="p-6 max-w-7xl mx-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 md:grid-cols-3 gap-6"
            >
              {/* Core Modules */}
              <div className="md:col-span-2 space-y-6">
                <section>
                  <h2 className="text-[11px] uppercase tracking-widest text-gray-500 mb-4 flex items-center gap-2">
                    <Layers className="w-3 h-3" /> System Core Registry
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {[registry.kernel, registry.aiEngine, registry.truthAnalysisCamp].map((mod) => (
                      <div key={mod.id} className="bg-[#151619] border border-[#1A1A1C] p-4 rounded-lg hover:border-orange-500/50 transition-colors group">
                        <div className="flex justify-between items-start mb-3">
                          <h3 className="text-sm font-bold">{mod.name}</h3>
                          <StatusBadge status={mod.status} />
                        </div>
                        <p className="text-xs text-gray-400 mb-4 line-clamp-2">{mod.description}</p>
                        <div className="space-y-2">
                          <div className="flex justify-between text-[10px] font-mono text-gray-500">
                            <span>LOAD_CAPACITY</span>
                            <span>{mod.load}%</span>
                          </div>
                          <div className="h-1 bg-gray-800 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${mod.load}%` }}
                              className={`h-full ${mod.load > 80 ? 'bg-red-500' : 'bg-orange-500'}`}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                <section>
                  <h2 className="text-[11px] uppercase tracking-widest text-gray-500 mb-4 flex items-center gap-2">
                    <Database className="w-3 h-3" /> Peripheral Modules
                  </h2>
                  <div className="bg-[#151619] border border-[#1A1A1C] rounded-lg overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#1A1A1C] text-gray-500 uppercase text-[10px] tracking-wider">
                        <tr>
                          <th className="p-3 font-medium">Module ID</th>
                          <th className="p-3 font-medium">Name</th>
                          <th className="p-3 font-medium">Status</th>
                          <th className="p-3 font-medium">Load</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#1A1A1C]">
                        {registry.modules.map((mod) => (
                          <tr key={mod.id} className="hover:bg-white/5 transition-colors">
                            <td className="p-3 font-mono text-gray-500">{mod.id}</td>
                            <td className="p-3 font-bold">{mod.name}</td>
                            <td className="p-3"><StatusBadge status={mod.status} /></td>
                            <td className="p-3 font-mono">{mod.load}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </section>
              </div>

              {/* Sidebar Stats */}
              <div className="space-y-6">
                <div className="bg-[#151619] border border-[#1A1A1C] p-6 rounded-lg">
                  <h2 className="text-[11px] uppercase tracking-widest text-gray-500 mb-6">System Health</h2>
                  <div className="flex justify-center mb-6">
                    <div className="relative w-32 h-32">
                      <svg className="w-full h-full transform -rotate-90">
                        <circle cx="64" cy="64" r="60" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-gray-800" />
                        <circle cx="64" cy="64" r="60" stroke="currentColor" strokeWidth="8" fill="transparent" strokeDasharray={377} strokeDashoffset={377 * (1 - 0.92)} className="text-orange-500" />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-2xl font-bold">92%</span>
                        <span className="text-[8px] uppercase text-gray-500">Integrity</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-400">Active Nodes</span>
                      <span className="text-xs font-mono">1,204</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-400">Threat Level</span>
                      <span className="text-xs font-mono text-green-500 uppercase">Minimal</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-400">Uptime</span>
                      <span className="text-xs font-mono">99.998%</span>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-600/10 border border-orange-600/30 p-6 rounded-lg">
                  <div className="flex items-center gap-3 mb-4">
                    <AlertTriangle className="w-5 h-5 text-orange-500" />
                    <h2 className="text-xs font-bold uppercase">System Alert</h2>
                  </div>
                  <p className="text-xs text-orange-200/70 leading-relaxed">
                    Data Pipeline (cv-data-005) reporting high load (95%). Auto-scaling initiated in region AS-N1.
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'truth' && (
            <motion.div
              key="truth"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              <div className="text-center space-y-4 py-12">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-orange-600/20 border border-orange-600/40 mb-4">
                  <Eye className="w-10 h-10 text-orange-500" />
                </div>
                <h2 className="text-3xl font-bold tracking-tighter italic font-serif">Truth Analysis Camp</h2>
                <p className="text-gray-500 max-w-md mx-auto text-sm">
                  Psychological archaeology and truth revelation module v7.2.0. 
                  Analyzing systemic layers for cognitive stressors and adversarial patterns.
                </p>
                <button
                  onClick={runTruthAnalysis}
                  disabled={isAnalyzing}
                  className={`mt-6 px-8 py-3 bg-orange-600 hover:bg-orange-500 text-white text-xs font-bold uppercase tracking-widest rounded transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {isAnalyzing ? 'Analyzing System Layers...' : 'Initiate Deep Analysis'}
                </button>
              </div>

              <div className="space-y-4">
                <h3 className="text-[11px] uppercase tracking-widest text-gray-500 flex items-center gap-2">
                  <Terminal className="w-3 h-3" /> Analysis History
                </h3>
                <div className="space-y-4">
                  {analysisHistory.length === 0 ? (
                    <div className="bg-[#151619] border border-dashed border-[#1A1A1C] p-12 text-center rounded-lg">
                      <p className="text-xs text-gray-600 font-mono">NO_RECORDS_FOUND. INITIATE_SCAN_TO_POPULATE.</p>
                    </div>
                  ) : (
                    analysisHistory.map((res) => (
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        key={res.id}
                        className="bg-[#151619] border border-[#1A1A1C] p-6 rounded-lg"
                      >
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex items-center gap-4">
                            <div className="px-2 py-1 bg-green-500/10 text-green-500 border border-green-500/30 rounded text-[9px] font-mono">
                              {res.status}
                            </div>
                            <span className="text-[10px] font-mono text-gray-500">{res.timestamp}</span>
                          </div>
                          <span className="text-[10px] font-mono text-gray-500">ID: {res.id}</span>
                        </div>
                        <p className="text-sm italic font-serif text-gray-300 leading-relaxed mb-6">
                          "{res.revelation}"
                        </p>
                        <div className="grid grid-cols-3 gap-4">
                          <div className="space-y-1">
                            <span className="text-[9px] uppercase text-gray-500 block">Semantic Depth</span>
                            <div className="h-1 bg-gray-800 rounded-full">
                              <div className="h-full bg-blue-500" style={{ width: `${res.semanticDepth}%` }} />
                            </div>
                          </div>
                          <div className="space-y-1">
                            <span className="text-[9px] uppercase text-gray-500 block">Adversarial Score</span>
                            <div className="h-1 bg-gray-800 rounded-full">
                              <div className="h-full bg-red-500" style={{ width: `${res.adversarialScore}%` }} />
                            </div>
                          </div>
                          <div className="space-y-1">
                            <span className="text-[9px] uppercase text-gray-500 block">Cognitive Stress</span>
                            <div className="h-1 bg-gray-800 rounded-full">
                              <div className="h-full bg-yellow-500" style={{ width: `${res.cognitiveStress}%` }} />
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'monitoring' && (
            <motion.div
              key="monitoring"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="flex items-center gap-3 mb-6">
                <Activity className="w-6 h-6 text-orange-500" />
                <h2 className="text-xl font-bold tracking-widest uppercase">Orchestration Telemetry</h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Redis Latency */}
                <div className="bg-[#151619] border border-[#1A1A1C] p-6 rounded-lg">
                  <h3 className="text-[11px] uppercase tracking-widest text-gray-500 mb-4">Redis State Latency</h3>
                  <div className="flex items-end gap-2 mb-2">
                    <span className="text-3xl font-mono text-green-400">0.8</span>
                    <span className="text-xs text-gray-500 mb-1">ms (p99)</span>
                  </div>
                  <div className="h-16 flex items-end gap-1">
                    {[40, 35, 45, 30, 50, 40, 60, 35, 45, 30, 25, 40].map((h, i) => (
                      <div key={i} className="flex-1 bg-green-500/20 rounded-t" style={{ height: `${h}%` }}>
                        <div className="w-full bg-green-500 rounded-t" style={{ height: '2px' }} />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Queue Backlog */}
                <div className="bg-[#151619] border border-[#1A1A1C] p-6 rounded-lg">
                  <h3 className="text-[11px] uppercase tracking-widest text-gray-500 mb-4">Queue Depth</h3>
                  <div className="flex items-end gap-2 mb-2">
                    <span className="text-3xl font-mono text-yellow-400">12</span>
                    <span className="text-xs text-gray-500 mb-1">jobs</span>
                  </div>
                  <div className="h-16 flex items-end gap-1">
                    {[10, 15, 20, 25, 30, 40, 35, 20, 15, 10, 5, 12].map((h, i) => (
                      <div key={i} className="flex-1 bg-yellow-500/20 rounded-t" style={{ height: `${h}%` }}>
                        <div className="w-full bg-yellow-500 rounded-t" style={{ height: '2px' }} />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Orchestrator Failures */}
                <div className="bg-[#151619] border border-[#1A1A1C] p-6 rounded-lg">
                  <h3 className="text-[11px] uppercase tracking-widest text-gray-500 mb-4">Workflow Failures</h3>
                  <div className="flex items-end gap-2 mb-2">
                    <span className="text-3xl font-mono text-gray-400">0</span>
                    <span className="text-xs text-gray-500 mb-1">last 24h</span>
                  </div>
                  <div className="h-16 flex items-end gap-1">
                    {[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0].map((h, i) => (
                      <div key={i} className="flex-1 bg-red-500/10 rounded-t" style={{ height: '10%' }}>
                        <div className="w-full bg-red-500/30 rounded-t" style={{ height: '2px' }} />
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Active Syncs */}
              <div className="bg-[#151619] border border-[#1A1A1C] rounded-lg overflow-hidden">
                <div className="p-4 border-b border-[#1A1A1C]">
                  <h3 className="text-[11px] uppercase tracking-widest text-gray-500">Active Repository Syncs</h3>
                </div>
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#1A1A1C] text-gray-500 uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="p-3 font-medium">Repository</th>
                      <th className="p-3 font-medium">Action</th>
                      <th className="p-3 font-medium">Progress</th>
                      <th className="p-3 font-medium">Duration</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1A1A1C]">
                    <tr className="hover:bg-white/5 transition-colors">
                      <td className="p-3 font-mono text-gray-300">codexvanta-os-core-kernel</td>
                      <td className="p-3 text-blue-400">SYNC_DEPENDENCIES</td>
                      <td className="p-3">
                        <div className="w-full bg-gray-800 rounded-full h-1.5">
                          <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: '45%' }}></div>
                        </div>
                      </td>
                      <td className="p-3 font-mono text-gray-500">00:01:24</td>
                    </tr>
                    <tr className="hover:bg-white/5 transition-colors">
                      <td className="p-3 font-mono text-gray-300">codexvanta-os-app-ui</td>
                      <td className="p-3 text-purple-400">VALIDATE_NAMING</td>
                      <td className="p-3">
                        <div className="w-full bg-gray-800 rounded-full h-1.5">
                          <div className="bg-purple-500 h-1.5 rounded-full" style={{ width: '89%' }}></div>
                        </div>
                      </td>
                      <td className="p-3 font-mono text-gray-500">00:00:12</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'terminal' && (
            <motion.div
              key="terminal"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="bg-black border border-[#1A1A1C] rounded-lg p-4 font-mono text-xs text-green-500 h-[600px] overflow-y-auto shadow-2xl"
            >
              <div className="space-y-1">
                <p className="text-gray-500">[SYSTEM_BOOT_SEQUENCE_INITIATED]</p>
                <p className="text-gray-500">[LOADING_CORE_KERNEL_V2.4.0...] DONE</p>
                <p className="text-gray-500">[CONNECTING_TO_Ω_DISRUPTOR_MESH...] DONE</p>
                <p className="text-gray-500">[AUTHENTICATING_USER_ADMIN...] SUCCESS</p>
                <p className="mt-4">root@codexvanta-os:~$ systemctl status all</p>
                <p>● cv-core-kernel.service - Codexvanta Core Kernel</p>
                <p className="ml-4">Loaded: loaded (/lib/systemd/system/cv-core-kernel.service; enabled; vendor preset: enabled)</p>
                <p className="ml-4">Active: active (running) since Mon 2026-03-30 07:20:11 UTC; 12min ago</p>
                <p className="mt-2">root@codexvanta-os:~$ tail -f /var/log/omega/truth-analysis.log</p>
                <p className="text-yellow-500">[WARN] Layer L7 cognitive stress threshold exceeded (88%)</p>
                <p className="text-blue-500">[INFO] Semantic Analyzer v2.1.0 processing incoming stream...</p>
                <p className="text-purple-500">[DISRUPT] Adversarial Generator injecting synthetic conflict for validation...</p>
                <p className="animate-pulse">_</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
