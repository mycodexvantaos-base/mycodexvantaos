import { ScrollView, Text, View, TouchableOpacity, Alert, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useRouter } from "expo-router";
import { useState, useCallback } from "react";
import { useHaptics } from "@/hooks/use-haptics";
import { useZipContext } from "@/lib/zip-context";
import {
  copySynthesisResultToClipboard,
  exportSynthesisResultAsText,
  exportSynthesisResultAsJSON,
  exportSynthesisResultAsPDF,
} from "@/lib/export-utils";

/**
 * 衝突項目元件
 */
function ConflictItem({ issue, solution }: { issue: string; solution: string }) {
  return (
    <View className="bg-background rounded-lg p-4 mb-3 border-l-4 border-error">
      <Text className="text-sm font-semibold text-foreground mb-1">⚠️ {issue}</Text>
      <Text className="text-xs text-muted">💡 {solution}</Text>
    </View>
  );
}

/**
 * 貢獻項目元件
 */
function ContributionItem({ version, contribution }: { version: string; contribution: string }) {
  return (
    <View className="bg-background rounded-lg p-4 mb-3 border-l-4 border-success">
      <Text className="text-sm font-semibold text-foreground mb-1">📦 {version}</Text>
      <Text className="text-xs text-muted">{contribution}</Text>
    </View>
  );
}

/**
 * 行動項目元件
 */
function ActionItem({ index, action }: { index: number; action: string }) {
  return (
    <View className="flex-row gap-3 mb-3">
      <View className="bg-primary rounded-full w-6 h-6 items-center justify-center flex-shrink-0">
        <Text className="text-white text-xs font-bold">{index}</Text>
      </View>
      <Text className="flex-1 text-sm text-foreground leading-relaxed">{action}</Text>
    </View>
  );
}

/**
 * 匯出按鈕元件
 */
function ExportButton({
  label,
  icon,
  onPress,
  loading,
  variant = "primary",
}: {
  label: string;
  icon: string;
  onPress: () => void;
  loading?: boolean;
  variant?: "primary" | "secondary" | "tertiary";
}) {
  const bgColor = {
    primary: "bg-primary",
    secondary: "bg-surface border border-border",
    tertiary: "bg-background border border-border",
  }[variant];

  const textColor = {
    primary: "text-white",
    secondary: "text-foreground",
    tertiary: "text-foreground",
  }[variant];

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={loading}
      className={`${bgColor} rounded-lg py-2 px-4 items-center justify-center flex-row gap-2`}
      activeOpacity={0.7}
    >
      {loading ? (
        <ActivityIndicator size="small" color={variant === "primary" ? "white" : "#0a7ea4"} />
      ) : (
        <Text className="text-sm">{icon}</Text>
      )}
      <Text className={`text-sm font-semibold ${textColor}`}>{label}</Text>
    </TouchableOpacity>
  );
}

export default function SynthesisResultScreen() {
  const router = useRouter();
  const { synthResult } = useZipContext();
  const haptics = useHaptics();
  const [exportLoading, setExportLoading] = useState<string | null>(null);

  if (!synthResult) {
    return (
      <ScreenContainer className="flex-1 items-center justify-center">
        <Text className="text-lg font-semibold text-foreground mb-2">沒有合成結果</Text>
        <Text className="text-sm text-muted mb-6">請先完成 ZIP 合成</Text>
        <TouchableOpacity
          onPress={() => router.back()}
          className="bg-primary rounded-lg py-2 px-6"
        >
          <Text className="text-sm font-semibold text-white">返回</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const handleCopyToClipboard = useCallback(async () => {
    await haptics.buttonPress();
    setExportLoading("clipboard");
    try {
      const success = await copySynthesisResultToClipboard(synthResult);
      if (success) {
        await haptics.success();
        Alert.alert("成功", "結果已複製到剪貼板");
      } else {
        await haptics.warning();
        Alert.alert("錯誤", "複製失敗");
      }
    } catch (error) {
      await haptics.error();
      Alert.alert("錯誤", "複製過程中出現錯誤");
    } finally {
      setExportLoading(null);
    }
  }, [synthResult]);

  const handleExportAsText = useCallback(async () => {
    await haptics.buttonPress();
    setExportLoading("text");
    try {
      const success = await exportSynthesisResultAsText(synthResult);
      if (success) {
        await haptics.success();
        Alert.alert("成功", "已匯出為文字檔案");
      } else {
        Alert.alert("提示", "檔案已保存");
      }
    } catch (error) {
      Alert.alert("錯誤", "匯出失敗");
    } finally {
      setExportLoading(null);
    }
  }, [synthResult]);

  const handleExportAsJSON = useCallback(async () => {
    setExportLoading("json");
    try {
      const success = await exportSynthesisResultAsJSON(synthResult);
      if (success) {
        Alert.alert("成功", "已匯出為 JSON 檔案");
      } else {
        Alert.alert("提示", "檔案已保存");
      }
    } catch (error) {
      Alert.alert("錯誤", "匯出失敗");
    } finally {
      setExportLoading(null);
    }
  }, [synthResult]);

  const handleExportAsPDF = useCallback(async () => {
    setExportLoading("pdf");
    try {
      const success = await exportSynthesisResultAsPDF(synthResult);
      if (success) {
        Alert.alert("成功", "已匯出為 PDF");
      } else {
        Alert.alert("提示", "無法在此裝置上匯出 PDF");
      }
    } catch (error) {
      Alert.alert("錯誤", "匯出失敗");
    } finally {
      setExportLoading(null);
    }
  }, [synthResult]);

  return (
    <ScreenContainer className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="gap-6 pb-6">
          {/* 標題 */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">🔗 合成結果</Text>
            <Text className="text-sm text-muted">統一架構設計方案</Text>
          </View>

          {/* 合成策略 */}
          <View>
            <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
              合成策略
            </Text>
            <View className="bg-surface rounded-lg p-4 border border-border">
              <Text className="text-sm text-foreground leading-relaxed">{synthResult.strategy}</Text>
            </View>
          </View>

          {/* 架構設計 */}
          <View>
            <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
              架構設計
            </Text>
            <View className="bg-surface rounded-lg p-4 border border-border">
              <Text className="text-sm text-foreground leading-relaxed">
                {synthResult.architecture}
              </Text>
            </View>
          </View>

          {/* 衝突解決方案 */}
          {synthResult.conflicts.length > 0 && (
            <View>
              <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
                衝突解決方案
              </Text>
              {synthResult.conflicts.map((conflict, index) => (
                <ConflictItem key={index} issue={conflict.issue} solution={conflict.solution} />
              ))}
            </View>
          )}

          {/* 版本貢獻 */}
          {synthResult.contributions.length > 0 && (
            <View>
              <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
                版本貢獻
              </Text>
              {synthResult.contributions.map((contrib, index) => (
                <ContributionItem
                  key={index}
                  version={contrib.version}
                  contribution={contrib.contribution}
                />
              ))}
            </View>
          )}

          {/* 行動計劃 */}
          {synthResult.actionPlan.length > 0 && (
            <View>
              <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
                行動計劃
              </Text>
              {synthResult.actionPlan.map((action, index) => (
                <ActionItem key={index} index={index + 1} action={action} />
              ))}
            </View>
          )}

          {/* 匯出選項 */}
          <View>
            <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
              匯出選項
            </Text>
            <View className="gap-2">
              <ExportButton
                label="複製到剪貼板"
                icon="📋"
                onPress={handleCopyToClipboard}
                loading={exportLoading === "clipboard"}
                variant="primary"
              />
              <View className="flex-row gap-2">
                <ExportButton
                  label="文字"
                  icon="📄"
                  onPress={handleExportAsText}
                  loading={exportLoading === "text"}
                  variant="secondary"
                />
                <ExportButton
                  label="JSON"
                  icon="{ }"
                  onPress={handleExportAsJSON}
                  loading={exportLoading === "json"}
                  variant="secondary"
                />
                <ExportButton
                  label="PDF"
                  icon="📕"
                  onPress={handleExportAsPDF}
                  loading={exportLoading === "pdf"}
                  variant="secondary"
                />
              </View>
            </View>
          </View>

          {/* 返回按鈕 */}
          <TouchableOpacity
            onPress={() => router.back()}
            className="bg-background border border-border rounded-lg py-3 items-center"
          >
            <Text className="text-sm font-semibold text-foreground">返回</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
