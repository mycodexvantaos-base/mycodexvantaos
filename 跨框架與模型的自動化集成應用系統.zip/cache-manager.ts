import AsyncStorage from "@react-native-async-storage/async-storage";
import type { AnalysisResult } from "./zip-synthesis";

const CACHE_PREFIX = "zip_synthesis_";
const CACHE_EXPIRY_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

export interface CachedAnalysis {
  data: AnalysisResult;
  timestamp: number;
  expiresAt: number;
}

/**
 * 生成快取鍵
 */
export function getCacheKey(zipName: string, fileCount: number): string {
  const hash = `${zipName}_${fileCount}`.replace(/[^a-zA-Z0-9]/g, "_");
  return `${CACHE_PREFIX}${hash}`;
}

/**
 * 保存分析結果到快取
 */
export async function saveAnalysisCache(
  zipName: string,
  fileCount: number,
  analysis: AnalysisResult
): Promise<void> {
  try {
    const key = getCacheKey(zipName, fileCount);
    const cached: CachedAnalysis = {
      data: analysis,
      timestamp: Date.now(),
      expiresAt: Date.now() + CACHE_EXPIRY_MS,
    };
    await AsyncStorage.setItem(key, JSON.stringify(cached));
  } catch (error) {
    console.error("Error saving analysis cache:", error);
  }
}

/**
 * 從快取讀取分析結果
 */
export async function getAnalysisCache(
  zipName: string,
  fileCount: number
): Promise<AnalysisResult | null> {
  try {
    const key = getCacheKey(zipName, fileCount);
    const cached = await AsyncStorage.getItem(key);

    if (!cached) return null;

    const parsed: CachedAnalysis = JSON.parse(cached);

    // 檢查是否過期
    if (Date.now() > parsed.expiresAt) {
      await AsyncStorage.removeItem(key);
      return null;
    }

    return parsed.data;
  } catch (error) {
    console.error("Error reading analysis cache:", error);
    return null;
  }
}

/**
 * 清除特定的快取
 */
export async function clearAnalysisCache(zipName: string, fileCount: number): Promise<void> {
  try {
    const key = getCacheKey(zipName, fileCount);
    await AsyncStorage.removeItem(key);
  } catch (error) {
    console.error("Error clearing analysis cache:", error);
  }
}

/**
 * 清除所有快取
 */
export async function clearAllCache(): Promise<void> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const cacheKeys = keys.filter((k) => k.startsWith(CACHE_PREFIX));
    await AsyncStorage.multiRemove(cacheKeys);
  } catch (error) {
    console.error("Error clearing all cache:", error);
  }
}

/**
 * 獲取快取統計資訊
 */
export async function getCacheStats(): Promise<{ count: number; size: number }> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const cacheKeys = keys.filter((k) => k.startsWith(CACHE_PREFIX));

    let totalSize = 0;
    for (const key of cacheKeys) {
      const value = await AsyncStorage.getItem(key);
      if (value) {
        totalSize += value.length;
      }
    }

    return {
      count: cacheKeys.length,
      size: totalSize,
    };
  } catch (error) {
    console.error("Error getting cache stats:", error);
    return { count: 0, size: 0 };
  }
}
