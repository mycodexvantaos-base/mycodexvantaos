import { describe, it, expect, vi, beforeEach } from "vitest";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";
import {
  triggerHaptic,
  hapticButtonPress,
  hapticSuccess,
  hapticError,
  hapticWarning,
  hapticLongPress,
  hapticToggle,
  hapticSelection,
  HapticType,
} from "./haptics-utils";

// Mock expo-haptics
vi.mock("expo-haptics");

// Mock react-native Platform
vi.mock("react-native", () => ({
  Platform: {
    OS: "ios",
  },
}));

describe("Haptics Utils", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("triggerHaptic", () => {
    it("should call impactAsync for Light type", async () => {
      const mockImpactAsync = vi.spyOn(Haptics, "impactAsync");
      await triggerHaptic(HapticType.Light);
      expect(mockImpactAsync).toHaveBeenCalledWith(Haptics.ImpactFeedbackStyle.Light);
    });

    it("should call impactAsync for Medium type", async () => {
      const mockImpactAsync = vi.spyOn(Haptics, "impactAsync");
      await triggerHaptic(HapticType.Medium);
      expect(mockImpactAsync).toHaveBeenCalledWith(Haptics.ImpactFeedbackStyle.Medium);
    });

    it("should call impactAsync for Heavy type", async () => {
      const mockImpactAsync = vi.spyOn(Haptics, "impactAsync");
      await triggerHaptic(HapticType.Heavy);
      expect(mockImpactAsync).toHaveBeenCalledWith(Haptics.ImpactFeedbackStyle.Heavy);
    });

    it("should call notificationAsync for Success type", async () => {
      const mockNotificationAsync = vi.spyOn(Haptics, "notificationAsync");
      await triggerHaptic(HapticType.Success);
      expect(mockNotificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Success);
    });

    it("should call notificationAsync for Warning type", async () => {
      const mockNotificationAsync = vi.spyOn(Haptics, "notificationAsync");
      await triggerHaptic(HapticType.Warning);
      expect(mockNotificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Warning);
    });

    it("should call notificationAsync for Error type", async () => {
      const mockNotificationAsync = vi.spyOn(Haptics, "notificationAsync");
      await triggerHaptic(HapticType.Error);
      expect(mockNotificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Error);
    });

    it("should handle errors gracefully", async () => {
      const mockImpactAsync = vi.spyOn(Haptics, "impactAsync").mockRejectedValueOnce(new Error("Test error"));
      const consoleSpy = vi.spyOn(console, "warn").mockImplementation(() => {});
      
      await triggerHaptic(HapticType.Light);
      
      expect(consoleSpy).toHaveBeenCalledWith("Haptic feedback error:", expect.any(Error));
      consoleSpy.mockRestore();
    });
  });

  describe("Haptic convenience functions", () => {
    it("hapticButtonPress should trigger Light haptic", async () => {
      const mockImpactAsync = vi.spyOn(Haptics, "impactAsync");
      await hapticButtonPress();
      expect(mockImpactAsync).toHaveBeenCalledWith(Haptics.ImpactFeedbackStyle.Light);
    });

    it("hapticSuccess should trigger Success haptic", async () => {
      const mockNotificationAsync = vi.spyOn(Haptics, "notificationAsync");
      await hapticSuccess();
      expect(mockNotificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Success);
    });

    it("hapticError should trigger Error haptic", async () => {
      const mockNotificationAsync = vi.spyOn(Haptics, "notificationAsync");
      await hapticError();
      expect(mockNotificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Error);
    });

    it("hapticWarning should trigger Warning haptic", async () => {
      const mockNotificationAsync = vi.spyOn(Haptics, "notificationAsync");
      await hapticWarning();
      expect(mockNotificationAsync).toHaveBeenCalledWith(Haptics.NotificationFeedbackType.Warning);
    });

    it("hapticLongPress should trigger Medium haptic", async () => {
      const mockImpactAsync = vi.spyOn(Haptics, "impactAsync");
      await hapticLongPress();
      expect(mockImpactAsync).toHaveBeenCalledWith(Haptics.ImpactFeedbackStyle.Medium);
    });

    it("hapticToggle should trigger Light haptic", async () => {
      const mockImpactAsync = vi.spyOn(Haptics, "impactAsync");
      await hapticToggle();
      expect(mockImpactAsync).toHaveBeenCalledWith(Haptics.ImpactFeedbackStyle.Light);
    });

    it("hapticSelection should trigger selection haptic", async () => {
      const mockSelectionAsync = vi.spyOn(Haptics, "selectionAsync");
      await hapticSelection();
      expect(mockSelectionAsync).toHaveBeenCalled();
    });
  });

  describe("Web platform handling", () => {
    it("should skip haptics on web platform", async () => {
      // Temporarily override Platform.OS
      const originalOS = Platform.OS;
      Object.defineProperty(Platform, "OS", {
        value: "web",
        configurable: true,
      });

      const mockImpactAsync = vi.spyOn(Haptics, "impactAsync");
      await triggerHaptic(HapticType.Light);

      expect(mockImpactAsync).not.toHaveBeenCalled();

      // Restore original value
      Object.defineProperty(Platform, "OS", {
        value: originalOS,
        configurable: true,
      });
    });
  });
});
