import * as Clipboard from "expo-clipboard";
import * as Sharing from "expo-sharing";
import * as FileSystem from "expo-file-system/legacy";
import type { SynthesisResult } from "./zip-synthesis";

/**
 * 格式化合成結果為文字
 */
export function formatSynthesisResultAsText(result: SynthesisResult): string {
  const lines: string[] = [
    "=== ZIP Synthesis Platform 合成結果 ===",
    "",
    "【合成策略】",
    result.strategy,
    "",
    "【架構設計】",
    result.architecture,
    "",
    "【衝突解決方案】",
    ...result.conflicts.map((c) => `• ${c.issue}: ${c.solution}`),
    "",
    "【版本貢獻】",
    ...result.contributions.map((c) => `• ${c.version}: ${c.contribution}`),
    "",
    "【行動計劃】",
    ...result.actionPlan.map((p, i) => `${i + 1}. ${p}`),
    "",
    `生成時間: ${new Date().toLocaleString("zh-TW")}`,
  ];

  return lines.join("\n");
}

/**
 * 複製合成結果到剪貼板
 */
export async function copySynthesisResultToClipboard(result: SynthesisResult): Promise<boolean> {
  try {
    const text = formatSynthesisResultAsText(result);
    await Clipboard.setStringAsync(text);
    return true;
  } catch (error) {
    console.error("Error copying to clipboard:", error);
    return false;
  }
}

/**
 * 生成簡單的 HTML 格式結果（用於 PDF 轉換）
 */
export function generateSynthesisResultHTML(result: SynthesisResult): string {
  return `
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ZIP Synthesis Platform 合成結果</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 900px;
      margin: 0 auto;
      padding: 20px;
      background: #f5f5f5;
    }
    .container {
      background: white;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    h1 {
      color: #0a7ea4;
      border-bottom: 3px solid #0a7ea4;
      padding-bottom: 10px;
      margin-bottom: 30px;
    }
    h2 {
      color: #0a7ea4;
      margin-top: 30px;
      margin-bottom: 15px;
      font-size: 1.3em;
    }
    .section {
      margin-bottom: 25px;
      padding: 15px;
      background: #f9f9f9;
      border-left: 4px solid #0a7ea4;
      border-radius: 4px;
    }
    ul {
      margin: 10px 0;
      padding-left: 20px;
    }
    li {
      margin: 8px 0;
    }
    .conflict-item, .contribution-item, .action-item {
      margin: 10px 0;
      padding: 10px;
      background: white;
      border-radius: 4px;
      border-left: 3px solid #1D9E75;
    }
    .footer {
      margin-top: 40px;
      padding-top: 20px;
      border-top: 1px solid #ddd;
      color: #666;
      font-size: 0.9em;
      text-align: center;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>🔗 ZIP Synthesis Platform 合成結果</h1>
    
    <div class="section">
      <h2>合成策略</h2>
      <p>${result.strategy.replace(/\n/g, "<br>")}</p>
    </div>

    <div class="section">
      <h2>架構設計</h2>
      <p>${result.architecture.replace(/\n/g, "<br>")}</p>
    </div>

    <div class="section">
      <h2>衝突解決方案</h2>
      ${result.conflicts.map((c) => `<div class="conflict-item"><strong>${c.issue}:</strong> ${c.solution}</div>`).join("")}
    </div>

    <div class="section">
      <h2>版本貢獻</h2>
      ${result.contributions.map((c) => `<div class="contribution-item"><strong>${c.version}:</strong> ${c.contribution}</div>`).join("")}
    </div>

    <div class="section">
      <h2>行動計劃</h2>
      <ol>
        ${result.actionPlan.map((p) => `<li class="action-item">${p}</li>`).join("")}
      </ol>
    </div>

    <div class="footer">
      <p>生成時間: ${new Date().toLocaleString("zh-TW")}</p>
      <p>ZIP Synthesis Platform v1.0.0</p>
    </div>
  </div>
</body>
</html>
  `.trim();
}

/**
 * 匯出合成結果為 PDF（需要後端或第三方服務）
 * 這裡提供一個簡化版本，實際應用中可使用 react-native-html-to-pdf 或後端 API
 */
export async function exportSynthesisResultAsPDF(
  result: SynthesisResult,
  filename: string = "synthesis-result.pdf"
): Promise<boolean> {
  try {
    // 生成 HTML 內容
    const html = generateSynthesisResultHTML(result);

    // 保存為臨時檔案
    const tempPath = `${FileSystem.cacheDirectory}${filename}.html`;
    await FileSystem.writeAsStringAsync(tempPath, html);

    // 嘗試分享或保存檔案
    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(tempPath, {
        mimeType: "text/html",
        dialogTitle: "分享合成結果",
      });
      return true;
    } else {
      console.warn("Sharing not available on this platform");
      return false;
    }
  } catch (error) {
    console.error("Error exporting as PDF:", error);
    return false;
  }
}

/**
 * 匯出合成結果為文字檔案
 */
export async function exportSynthesisResultAsText(
  result: SynthesisResult,
  filename: string = "synthesis-result.txt"
): Promise<boolean> {
  try {
    const text = formatSynthesisResultAsText(result);
    const path = `${FileSystem.documentDirectory}${filename}`;
    await FileSystem.writeAsStringAsync(path, text);

    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(path, {
        mimeType: "text/plain",
        dialogTitle: "分享合成結果",
      });
      return true;
    }

    return true;
  } catch (error) {
    console.error("Error exporting as text:", error);
    return false;
  }
}

/**
 * 匯出為 JSON 格式（用於進一步處理）
 */
export async function exportSynthesisResultAsJSON(
  result: SynthesisResult,
  filename: string = "synthesis-result.json"
): Promise<boolean> {
  try {
    const json = JSON.stringify(result, null, 2);
    const path = `${FileSystem.documentDirectory}${filename}`;
    await FileSystem.writeAsStringAsync(path, json);

    if (await Sharing.isAvailableAsync()) {
      await Sharing.shareAsync(path, {
        mimeType: "application/json",
        dialogTitle: "分享合成結果",
      });
      return true;
    }

    return true;
  } catch (error) {
    console.error("Error exporting as JSON:", error);
    return false;
  }
}
