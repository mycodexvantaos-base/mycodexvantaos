
import { useState, useRef, useCallback } from "react";

const JSZIP_CDN = "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js";

function loadJSZip() {
  return new Promise((resolve, reject) => {
    if (window.JSZip) { resolve(window.JSZip); return; }
    const s = document.createElement("script");
    s.src = JSZIP_CDN;
    s.onload = () => resolve(window.JSZip);
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

function detectType(files) {
  const names = files.map(f => f.name.toLowerCase());
  const exts = names.map(n => n.split(".").pop());
  const tsCount = exts.filter(e => e === "ts" || e === "tsx").length;
  const pyCount = exts.filter(e => e === "py").length;
  const goCount = exts.filter(e => e === "go").length;
  const rsCount = exts.filter(e => e === "rs").length;
  if (names.includes("cargo.toml") || rsCount > 1) return "Rust";
  if (names.includes("go.mod") || goCount > 1) return "Go";
  if (names.includes("requirements.txt") || names.includes("pyproject.toml") || pyCount > 2) return "Python";
  if (tsCount > 2) return names.includes("tsconfig.json") ? "TypeScript/Node" : "TypeScript";
  if (names.includes("package.json")) return "JavaScript/Node";
  return "Mixed";
}

function buildTree(files, maxDepth = 3) {
  const tree = {};
  files.slice(0, 100).forEach(f => {
    const parts = f.name.split("/").filter(Boolean).slice(0, maxDepth);
    let node = tree;
    parts.forEach((p, i) => {
      if (!node[p]) node[p] = i === parts.length - 1 ? null : {};
      if (node[p] !== null && typeof node[p] === "object") node = node[p];
    });
  });
  return tree;
}

function TreeNode({ name, node, depth = 0 }) {
  const [open, setOpen] = useState(depth < 1);
  const isDir = node !== null && typeof node === "object";
  const pad = depth * 14;
  if (!isDir) {
    return (
      <div style={{ paddingLeft: pad + 16, fontSize: 11, color: "var(--color-text-secondary)", lineHeight: "1.9", fontFamily: "var(--font-mono)" }}>
        {name}
      </div>
    );
  }
  return (
    <div>
      <div onClick={() => setOpen(o => !o)} style={{ paddingLeft: pad, fontSize: 11, fontWeight: 500, color: "var(--color-text-primary)", lineHeight: "1.9", cursor: "pointer", fontFamily: "var(--font-mono)", userSelect: "none" }}>
        {open ? "▾" : "▸"} {name}/
      </div>
      {open && Object.entries(node).map(([k, v]) => <TreeNode key={k} name={k} node={v} depth={depth + 1} />)}
    </div>
  );
}

function TagPill({ label }) {
  const map = { "TypeScript": "#E6F1FB:#185FA5", "TypeScript/Node": "#E6F1FB:#185FA5", "JavaScript/Node": "#FAEEDA:#854F0B", "Python": "#EAF3DE:#3B6D11", "Go": "#E1F5EE:#0F6E56", "Rust": "#FAECE7:#993C1D" };
  const colors = map[label] || "#F1EFE8:#5F5E5A";
  const [bg, fg] = colors.split(":");
  return <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 100, background: bg, color: fg, fontFamily: "var(--font-sans)" }}>{label}</span>;
}

function StatusDot({ status }) {
  const colors = { pending: "#888780", analyzing: "#EF9F27", done: "#1D9E75", error: "#E24B4A" };
  return <div style={{ width: 6, height: 6, borderRadius: "50%", background: colors[status] || "#888", flexShrink: 0 }} />;
}

function Spinner() {
  return (
    <div style={{ display: "inline-block", width: 10, height: 10, border: "1.5px solid var(--color-border-secondary)", borderTopColor: "var(--color-text-primary)", borderRadius: "50%", animation: "spin 0.6s linear infinite" }}>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function StatCard({ label, value, sub }) {
  return (
    <div style={{ background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", padding: "12px" }}>
      <div style={{ fontSize: 10, color: "var(--color-text-secondary)", textTransform: "uppercase", letterSpacing: "0.08em", fontFamily: "var(--font-sans)" }}>{label}</div>
      <div style={{ fontSize: 22, fontWeight: 500, color: "var(--color-text-primary)", marginTop: 4 }}>{value}</div>
      <div style={{ fontSize: 11, color: "var(--color-text-secondary)", fontFamily: "var(--font-sans)", marginTop: 2 }}>{sub}</div>
    </div>
  );
}

function SectionTitle({ children }) {
  return (
    <div style={{ fontSize: 10, textTransform: "uppercase", letterSpacing: "0.1em", color: "var(--color-text-secondary)", fontFamily: "var(--font-sans)", fontWeight: 500, marginBottom: 6, borderBottom: "0.5px solid var(--color-border-tertiary)", paddingBottom: 4 }}>
      {children}
    </div>
  );
}

function AiText({ children }) {
  return <div style={{ fontSize: 12, color: "var(--color-text-primary)", lineHeight: 1.75, fontFamily: "var(--font-sans)", whiteSpace: "pre-wrap" }}>{children}</div>;
}

export default function App() {
  const [zips, setZips] = useState([]);
  const [selected, setSelected] = useState(null);
  const [dragOver, setDragOver] = useState(false);
  const [synthOutput, setSynthOutput] = useState("");
  const [synthStatus, setSynthStatus] = useState("");
  const [synthProgress, setSynthProgress] = useState(0);
  const [synthVisible, setSynthVisible] = useState(false);
  const fileInputRef = useRef();

  const processFiles = useCallback(async (files) => {
    const JSZip = await loadJSZip();
    const newZips = [];
    for (const file of files) {
      if (!file.name.endsWith(".zip")) continue;
      const exists = zips.find(z => z.name === file.name);
      if (exists) continue;
      try {
        const zip = await JSZip.loadAsync(file);
        const fileList = [];
        zip.forEach((relativePath, entry) => { if (!entry.dir) fileList.push({ name: relativePath }); });
        const type = detectType(fileList);
        newZips.push({ id: Date.now() + Math.random(), name: file.name, files: fileList, type, status: "pending", analysis: null, raw: zip, error: null });
      } catch (e) {
        newZips.push({ id: Date.now() + Math.random(), name: file.name, files: [], type: "error", status: "error", analysis: null, raw: null, error: e.message });
      }
    }
    setZips(prev => {
      const updated = [...prev, ...newZips];
      if (updated.length > 0 && selected === null) setSelected(0);
      return updated;
    });
  }, [zips, selected]);

  const analyzeOne = useCallback(async (idx) => {
    const z = zips[idx];
    if (!z || z.status === "analyzing" || z.status === "done") return;
    setZips(prev => prev.map((item, i) => i === idx ? { ...item, status: "analyzing" } : item));
    const fileList = z.files.slice(0, 80).map(f => f.name).join("\n");
    let sampleCode = "";
    if (z.raw) {
      const codeExts = [".ts", ".tsx", ".py", ".go", ".rs", ".js", ".vue"];
      for (const [path, entry] of Object.entries(z.raw.files)) {
        if (!entry.dir && codeExts.some(e => path.endsWith(e)) && !path.includes("node_modules") && !path.includes(".min.")) {
          try {
            const text = await entry.async("string");
            if (text.length > 50) { sampleCode = `\n\n=== 代碼片段 (${path}) ===\n${text.slice(0, 600)}`; break; }
          } catch (e) {}
        }
      }
    }
    const prompt = `你是程式碼架構分析師。分析此 ZIP 壓縮檔內容。\n\nZIP: ${z.name}\n檔案數: ${z.files.length}\n類型: ${z.type}\n\n檔案列表:\n${fileList}${sampleCode}\n\n請直接輸出 JSON，不要任何 markdown:\n{\n  "tags": ["技術標籤"],\n  "overview": "2-3行專案概覽",\n  "architecture": "架構評估：層次、設計模式、可維護性",\n  "value": "此版本值得提取的核心邏輯"\n}`;
    try {
      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, messages: [{ role: "user", content: prompt }] })
      });
      const data = await resp.json();
      const text = data.content?.[0]?.text || "{}";
      const parsed = JSON.parse(text.replace(/```json|```/g, "").trim());
      setZips(prev => prev.map((item, i) => i === idx ? { ...item, status: "done", analysis: parsed } : item));
    } catch (e) {
      setZips(prev => prev.map((item, i) => i === idx ? { ...item, status: "error", error: e.message } : item));
    }
  }, [zips]);

  const analyzeAll = useCallback(async () => {
    for (let i = 0; i < zips.length; i++) {
      if (zips[i].status === "pending") await analyzeOne(i);
    }
  }, [zips, analyzeOne]);

  const synthesize = useCallback(async () => {
    const done = zips.filter(z => z.status === "done");
    if (done.length < 2) return;
    setSynthVisible(true);
    setSynthStatus("分析中...");
    setSynthProgress(20);
    setSynthOutput("");
    const summaries = done.map((z, i) => `[${i+1}] ${z.name} (${z.type})\n概覽: ${z.analysis?.overview || ""}\n架構: ${z.analysis?.architecture || ""}\n核心價值: ${z.analysis?.value || ""}\n技術棧: ${(z.analysis?.tags || []).join(", ")}`).join("\n\n");
    const allPaths = done.flatMap(z => z.files.map(f => f.name.split("/").pop()));
    const counts = {};
    allPaths.forEach(p => { counts[p] = (counts[p] || 0) + 1; });
    const conflicts = Object.entries(counts).filter(([, v]) => v >= 2).slice(0, 8).map(([k, v]) => `${k} (${v}個版本)`).join(", ");
    setSynthProgress(50);
    const prompt = `你是頂級軟體架構師，整合多個版本為最終高級版本。\n\n共 ${done.length} 個版本摘要:\n${summaries}\n\n主要衝突: ${conflicts || "無明顯衝突"}\n\n請生成架構合成報告（繁體中文）:\n\n【合成策略概覽】\n（整合方向，2-4行）\n\n【核心衝突與解法】\n（條列3-5個衝突及解決策略）\n\n【最終架構建議】\n（統一目標架構，含目錄結構）\n\n【各版本貢獻提取表】\n（每版本貢獻什麼）\n\n【立即行動計劃（3步驟）】\n（具體可執行）`;
    try {
      setSynthProgress(75);
      const resp = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, messages: [{ role: "user", content: prompt }] })
      });
      const data = await resp.json();
      setSynthOutput(data.content?.[0]?.text || "生成失敗");
      setSynthProgress(100);
      setSynthStatus(`基於 ${done.length} 個版本合成完成`);
    } catch (e) {
      setSynthOutput("合成失敗: " + e.message);
      setSynthProgress(0);
    }
  }, [zips]);

  const doneCount = zips.filter(z => z.status === "done").length;
  const typeCount = [...new Set(zips.map(z => z.type).filter(Boolean))].length;
  const allPaths = zips.filter(z => z.status === "done").flatMap(z => z.files.map(f => f.name.split("/").pop()));
  const pathCounts = {};
  allPaths.forEach(p => { pathCounts[p] = (pathCounts[p] || 0) + 1; });
  const conflictCount = Object.values(pathCounts).filter(v => v >= 2).length;

  const selectedZip = selected !== null ? zips[selected] : null;

  return (
    <div style={{ padding: "1rem 0", fontFamily: "var(--font-mono)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "1.5rem", paddingBottom: "1rem", borderBottom: "0.5px solid var(--color-border-tertiary)" }}>
        <div>
          <div style={{ fontSize: 15, fontWeight: 500, color: "var(--color-text-primary)", letterSpacing: "0.03em" }}>ZIP SYNTHESIS PLATFORM</div>
          <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginTop: 2, fontFamily: "var(--font-sans)" }}>上傳 → 解析 → 對齊 → 合成更高級版本</div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button disabled={zips.length === 0} onClick={analyzeAll} style={{ padding: "7px 14px", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-secondary)", background: "transparent", color: "var(--color-text-primary)", fontSize: 12, cursor: zips.length === 0 ? "not-allowed" : "pointer", fontFamily: "var(--font-sans)", opacity: zips.length === 0 ? 0.4 : 1 }}>全部分析</button>
          <button disabled={doneCount < 2} onClick={synthesize} style={{ padding: "7px 14px", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-text-primary)", background: "var(--color-text-primary)", color: "var(--color-background-primary)", fontSize: 12, cursor: doneCount < 2 ? "not-allowed" : "pointer", fontFamily: "var(--font-sans)", opacity: doneCount < 2 ? 0.4 : 1 }}>▶ 生成合成版本</button>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: "1.5rem" }}>
        <StatCard label="已上傳" value={zips.length} sub="zip 檔案" />
        <StatCard label="已分析" value={doneCount} sub="完成" />
        <StatCard label="衝突偵測" value={doneCount >= 2 ? conflictCount : "—"} sub="檔案衝突" />
        <StatCard label="技術棧" value={typeCount || "—"} sub="種類型" />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 12 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-lg)", overflow: "hidden" }}>
            <div style={{ padding: "10px 14px", borderBottom: "0.5px solid var(--color-border-tertiary)" }}>
              <span style={{ fontSize: 11, fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.1em", color: "var(--color-text-secondary)", fontFamily: "var(--font-sans)" }}>上傳區</span>
            </div>
            <div style={{ padding: 12 }}>
              <div
                onClick={() => fileInputRef.current?.click()}
                onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={e => { e.preventDefault(); setDragOver(false); processFiles([...e.dataTransfer.files]); }}
                style={{ border: "0.5px dashed var(--color-border-secondary)", borderRadius: "var(--border-radius-md)", padding: "20px 12px", textAlign: "center", cursor: "pointer", background: dragOver ? "var(--color-background-secondary)" : "transparent" }}
              >
                <div style={{ fontSize: 20, marginBottom: 6 }}>⬡</div>
                <div style={{ fontSize: 12, color: "var(--color-text-secondary)", fontFamily: "var(--font-sans)" }}>拖曳 .zip 到此處<br />或點擊選擇多個檔案</div>
              </div>
              <input ref={fileInputRef} type="file" multiple accept=".zip" style={{ display: "none" }} onChange={e => processFiles([...e.target.files])} />
            </div>
          </div>

          <div style={{ background: "var(--color-background-primary)", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-lg)", overflow: "hidden", flex: 1 }}>
            <div style={{ padding: "10px 14px", borderBottom: "0.5px solid var(--color-border-tertiary)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 11, fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.1em", color: "var(--color-text-secondary)", fontFamily: "var(--font-sans)" }}>專案清單</span>
              <span style={{ fontSize: 10, color: "var(--color-text-secondary)", fontFamily: "var(--font-sans)" }}>{zips.length} 個</span>
            </div>
            <div style={{ padding: 12 }}>
              {zips.length === 0 ? (
                <div style={{ fontSize: 12, color: "var(--color-text-secondary)", textAlign: "center", padding: "20px 0", fontFamily: "var(--font-sans)" }}>尚未上傳任何檔案</div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 4, maxHeight: 340, overflowY: "auto" }}>
                  {zips.map((z, i) => (
                    <div key={z.id} onClick={() => setSelected(i)} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 10px", borderRadius: "var(--border-radius-md)", cursor: "pointer", border: selected === i ? "0.5px solid var(--color-border-secondary)" : "0.5px solid transparent", background: selected === i ? "var(--color-background-secondary)" : "transparent" }}>
                      <StatusDot status={z.status} />
                      <span style={{ fontSize: 12, color: "var(--color-text-primary)", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{z.name}</span>
                      <span style={{ fontSize: 10, color: "var(--color-text-secondary)", fontFamily: "var(--font-sans)", flexShrink: 0 }}>{z.type}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        <div style={{ display: "flex", flexDirectio
(Content truncated due to size limit. Use line ranges to read remaining content)