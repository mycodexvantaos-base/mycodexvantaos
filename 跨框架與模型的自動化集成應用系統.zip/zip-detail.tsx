import { ScrollView, Text, View, TouchableOpacity, FlatList, Alert, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useZipContext } from "@/lib/zip-context";
import { useRouter } from "expo-router";
import { useState, useCallback } from "react";
import { useHaptics } from "@/hooks/use-haptics";
import { buildFileTree } from "@/lib/zip-synthesis";
import { callClaudeAPI, buildAnalysisPrompt, parseAnalysisResult } from "@/lib/api-client";
import { saveAnalysisCache, getAnalysisCache } from "@/lib/cache-manager";
import * as Clipboard from "expo-clipboard";

/**
 * 樹狀結構節點元件
 */
function TreeNode({ name, node, depth = 0 }: { name: string; node: any; depth?: number }) {
  const [open, setOpen] = useState(depth < 1);
  const isDir = node !== null && typeof node === "object";
  const pad = depth * 14;

  if (!isDir) {
    return (
      <Text
        className="text-xs text-muted font-mono"
        style={{ paddingLeft: pad + 16, lineHeight: 28 }}
        numberOfLines={1}
      >
        {name}
      </Text>
    );
  }

  return (
    <View>
      <TouchableOpacity
        onPress={() => setOpen(o => !o)}
        style={{ paddingLeft: pad }}
        activeOpacity={0.7}
      >
        <Text className="text-xs font-semibold text-foreground font-mono" style={{ lineHeight: 28 }}>
          {open ? "▾" : "▸"} {name}/
        </Text>
      </TouchableOpacity>
      {open && (
        <View>
          {Object.entries(node).map(([k, v]) => (
            <TreeNode key={k} name={k} node={v} depth={depth + 1} />
          ))}
        </View>
      )}
    </View>
  );
}

/**
 * 技術棧標籤元件
 */
function TagPill({ label }: { label: string }) {
  const map: Record<string, string> = {
    "TypeScript": "#E6F1FB",
    "TypeScript/Node": "#E6F1FB",
    "JavaScript/Node": "#FAEEDA",
    "Python": "#EAF3DE",
    "Go": "#E1F5EE",
    "Rust": "#FAECE7",
  };

  const textColorMap: Record<string, string> = {
    "TypeScript": "#185FA5",
    "TypeScript/Node": "#185FA5",
    "JavaScript/Node": "#854F0B",
    "Python": "#3B6D11",
    "Go": "#0F6E56",
    "Rust": "#993C1D",
  };

  const bg = map[label] || "#F1EFE8";
  const fg = textColorMap[label] || "#5F5E5A";

  return (
    <View className="px-2 py-1 rounded-full" style={{ backgroundColor: bg }}>
      <Text className="text-xs font-medium" style={{ color: fg }}>
        {label}
      </Text>
    </View>
  );
}

export default function ZipDetailScreen() {
  const router = useRouter();
  const { zips, selectedIndex, updateZipStatus, updateZipAnalysis, updateZipError, apiKey } = useZipContext();
  const haptics = useHaptics();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  if (selectedIndex === null || !zips[selectedIndex]) {
    return (
      <ScreenContainer className="flex-1 items-center justify-center">
        <Text className="text-lg font-semibold text-foreground">未選擇 ZIP 檔案</Text>
        <TouchableOpacity
          onPress={() => router.back()}
          className="mt-4 bg-primary rounded-lg px-6 py-2"
        >
          <Text className="text-white font-semibold">返回</Text>
        </TouchableOpacity>
      </ScreenContainer>
    );
  }

  const zip = zips[selectedIndex];
  const fileTree = buildFileTree(zip.files);

  const handleAnalyze = useCallback(async () => {
    if (!zip || selectedIndex === null) return;
    await haptics.buttonPress();
    if (!apiKey) {
      await haptics.warning();
      Alert.alert("錯誤", "請先在設定中設定 API 金鑰");
      router.push("/settings");
      return;
    }
    setIsAnalyzing(true);
    try {
      const cached = await getAnalysisCache(zip.name, zip.files.length);
      if (cached) {
        updateZipAnalysis(selectedIndex, cached);
        Alert.alert("成功", "已從快取載入結果");
        setIsAnalyzing(false);
        return;
      }
      updateZipStatus(selectedIndex, "analyzing");
      const fileList = zip.files.slice(0, 50).map((f) => f.name).join("\n");
      const prompt = buildAnalysisPrompt(zip.name, zip.files.length, zip.type, fileList, "");
      const response = await callClaudeAPI(apiKey, prompt);
      const analysis = parseAnalysisResult(response);
      await saveAnalysisCache(zip.name, zip.files.length, analysis);
      updateZipAnalysis(selectedIndex, analysis);
      await haptics.success();
      Alert.alert("成功", "分析完成");
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : "分析失敗";
      updateZipError(selectedIndex, errorMsg);
      await haptics.error();
      Alert.alert("錯誤", errorMsg);
    } finally {
      setIsAnalyzing(false);
    }
  }, [zip, selectedIndex, apiKey, updateZipStatus, updateZipAnalysis, updateZipError, router]);

  const handleCopyAnalysis = useCallback(async () => {
    if (!zip?.analysis) return;
    try {
      await haptics.buttonPress();
      const text = `【${zip.name}】\n標籤: ${zip.analysis.tags.join(", ")}\n\n${zip.analysis.overview}\n\n${zip.analysis.architecture}`;
      await Clipboard.setStringAsync(text);
      await haptics.success();
      Alert.alert("成功", "已複製到剪貼板");
    } catch (error) {
      Alert.alert("錯誤", "複製失敗");
    }
  }, [zip]);

  return (
    <ScreenContainer className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="gap-6 pb-6">
          {/* 標題 */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">{zip.name}</Text>
            <Text className="text-sm text-muted">檔案詳情與分析結果</Text>
          </View>

          {/* 基本資訊 */}
          <View className="bg-surface rounded-lg p-4 gap-3 border border-border">
            <View className="flex-row justify-between items-center">
              <Text className="text-xs uppercase tracking-wider text-muted font-semibold">
                檔案數量
              </Text>
              <Text className="text-lg font-semibold text-foreground">{zip.files.length}</Text>
            </View>
            <View className="flex-row justify-between items-center">
              <Text className="text-xs uppercase tracking-wider text-muted font-semibold">
                技術棧
              </Text>
              <TagPill label={zip.type} />
            </View>
            <View className="flex-row justify-between items-center">
              <Text className="text-xs uppercase tracking-wider text-muted font-semibold">
                分析狀態
              </Text>
              <Text className="text-sm font-medium text-foreground">
                {zip.status === "analyzing" && "分析中..."}
                {zip.status === "done" && "✓ 已完成"}
                {zip.status === "pending" && "待分析"}
                {zip.status === "error" && "❌ 錯誤"}
              </Text>
            </View>
          </View>

          {/* 分析結果 */}
          {zip.analysis && (
            <View className="gap-4">
              <View>
                <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-2">
                  技術標籤
                </Text>
                <View className="flex-row flex-wrap gap-2">
                  {zip.analysis.tags.map((tag, i) => (
                    <TagPill key={i} label={tag} />
                  ))}
                </View>
              </View>

              <View>
                <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-2">
                  專案概覽
                </Text>
                <Text className="text-sm text-foreground leading-relaxed">
                  {zip.analysis.overview}
                </Text>
              </View>

              <View>
                <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-2">
                  架構評估
                </Text>
                <Text className="text-sm text-foreground leading-relaxed">
                  {zip.analysis.architecture}
                </Text>
              </View>

              <View>
                <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-2">
                  核心價值
                </Text>
                <Text className="text-sm text-foreground leading-relaxed">
                  {zip.analysis.value}
                </Text>
              </View>
            </View>
          )}

          {/* 檔案樹狀結構 */}
          <View className="bg-surface rounded-lg p-4 border border-border">
            <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
              檔案結構
            </Text>
            <View className="bg-background rounded p-3">
              {Object.entries(fileTree).map(([k, v]) => (
                <TreeNode key={k} name={k} node={v} depth={0} />
              ))}
            </View>
          </View>

          {/* 錯誤訊息 */}
          {zip.error && (
            <View className="bg-error/10 rounded-lg p-4 border border-error">
              <Text className="text-sm font-semibold text-error mb-1">錯誤</Text>
              <Text className="text-xs text-error/80">{zip.error}</Text>
            </View>
          )}

          {/* 操作按鈕 */}
          <View className="flex-row gap-3">
            {zip.status !== "done" && (
              <TouchableOpacity
                onPress={handleAnalyze}
                disabled={isAnalyzing}
                className="flex-1 bg-primary rounded-lg py-3 items-center justify-center"
              >
                {isAnalyzing ? (
                  <ActivityIndicator size="small" color="white" />
                ) : (
                  <Text className="text-sm font-semibold text-white">分析</Text>
                )}
              </TouchableOpacity>
            )}
            {zip.analysis && (
              <TouchableOpacity
                onPress={handleCopyAnalysis}
                className="flex-1 bg-background border border-border rounded-lg py-3 items-center"
              >
                <Text className="text-sm font-semibold text-foreground">複製</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity
              onPress={() => router.back()}
              className="flex-1 bg-background border border-border rounded-lg py-3 items-center"
            >
              <Text className="text-sm font-semibold text-foreground">返回</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
