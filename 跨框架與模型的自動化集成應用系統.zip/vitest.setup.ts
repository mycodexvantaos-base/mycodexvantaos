import { vi } from "vitest";

// Define __DEV__ global
(global as any).__DEV__ = true;
(global as any).process = { env: { EXPO_OS: "ios" } };

// Mock react-native
vi.mock("react-native", () => ({
  Platform: {
    OS: "ios",
    select: (obj: Record<string, any>) => obj.ios || obj.default,
  },
  View: "View",
  Text: "Text",
  ScrollView: "ScrollView",
  TouchableOpacity: "TouchableOpacity",
  FlatList: "FlatList",
  Alert: { alert: vi.fn() },
  ActivityIndicator: "ActivityIndicator",
  TextInput: "TextInput",
  Switch: "Switch",
  TurboModuleRegistry: {
    getEnforcing: vi.fn(() => ({})),
  },
}));

// Mock expo-haptics
vi.mock("expo-haptics", () => ({
  impactAsync: vi.fn().mockResolvedValue(undefined),
  notificationAsync: vi.fn().mockResolvedValue(undefined),
  selectionAsync: vi.fn().mockResolvedValue(undefined),
  ImpactFeedbackStyle: {
    Light: 0,
    Medium: 1,
    Heavy: 2,
  },
  NotificationFeedbackType: {
    Success: 0,
    Warning: 1,
    Error: 2,
  },
}));

// Mock expo-modules-core
vi.mock("expo-modules-core", () => ({
  EventEmitter: class EventEmitter {},
  NativeModulesProxy: {},
  requireNativeModule: vi.fn(),
}));

// Mock expo-router
vi.mock("expo-router", () => ({
  useRouter: () => ({
    push: vi.fn(),
    back: vi.fn(),
  }),
}));

// Mock AsyncStorage
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
    clear: vi.fn(),
  },
}));


// Mock expo
vi.mock("expo", () => ({
  __ExpoImportMetaRegistry: {},
  requireOptionalNativeModule: vi.fn(() => ({})),
  requireNativeModule: vi.fn(() => ({})),
}));

// Mock expo-file-system
vi.mock("expo-file-system/legacy", () => ({
  readAsStringAsync: vi.fn(),
  writeAsStringAsync: vi.fn(),
  deleteAsync: vi.fn(),
  EncodingType: {
    Base64: "base64",
    UTF8: "utf8",
  },
}));

// Mock expo-clipboard
vi.mock("expo-clipboard", () => ({
  setStringAsync: vi.fn().mockResolvedValue(undefined),
  getStringAsync: vi.fn().mockResolvedValue(""),
}));

// Mock expo-sharing
vi.mock("expo-sharing", () => ({
  shareAsync: vi.fn().mockResolvedValue(undefined),
}));

// Mock expo-document-picker
vi.mock("expo-document-picker", () => ({
  getDocumentAsync: vi.fn().mockResolvedValue({
    canceled: true,
    assets: [],
  }),
}));

// Mock jszip
vi.mock("jszip", () => ({
  default: class JSZip {
    loadAsync = vi.fn().mockResolvedValue(this);
    forEach = vi.fn();
    files = {};
  },
}));
