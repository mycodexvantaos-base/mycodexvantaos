import { describe, it, expect, beforeEach } from "vitest";
import { logger, LogLevel } from "./logger";

describe("Logger", () => {
  beforeEach(() => {
    logger.clear();
  });

  describe("logging methods", () => {
    it("should log debug messages", () => {
      logger.debug("Debug message", { key: "value" });
      const logs = logger.getLogs();

      expect(logs).toHaveLength(1);
      expect(logs[0].level).toBe(LogLevel.DEBUG);
      expect(logs[0].message).toBe("Debug message");
      expect(logs[0].context).toEqual({ key: "value" });
    });

    it("should log info messages", () => {
      logger.info("Info message");
      const logs = logger.getLogs();

      expect(logs).toHaveLength(1);
      expect(logs[0].level).toBe(LogLevel.INFO);
      expect(logs[0].message).toBe("Info message");
    });

    it("should log warn messages", () => {
      logger.warn("Warning message");
      const logs = logger.getLogs();

      expect(logs).toHaveLength(1);
      expect(logs[0].level).toBe(LogLevel.WARN);
    });

    it("should log error messages with error object", () => {
      const error = new Error("Test error");
      logger.error("Error occurred", { code: 500 }, error);
      const logs = logger.getLogs();

      expect(logs).toHaveLength(1);
      expect(logs[0].level).toBe(LogLevel.ERROR);
      expect(logs[0].error).toBe(error);
      expect(logs[0].context).toEqual({ code: 500 });
    });
  });

  describe("getLogsByLevel", () => {
    it("should filter logs by level", () => {
      logger.debug("Debug 1");
      logger.info("Info 1");
      logger.warn("Warn 1");
      logger.error("Error 1", {});
      logger.debug("Debug 2");

      const debugLogs = logger.getLogsByLevel(LogLevel.DEBUG);
      expect(debugLogs).toHaveLength(2);
      expect(debugLogs.every((l) => l.level === LogLevel.DEBUG)).toBe(true);

      const infoLogs = logger.getLogsByLevel(LogLevel.INFO);
      expect(infoLogs).toHaveLength(1);
    });
  });

  describe("clear", () => {
    it("should clear all logs", () => {
      logger.info("Message 1");
      logger.info("Message 2");
      expect(logger.getLogs()).toHaveLength(2);

      logger.clear();
      expect(logger.getLogs()).toHaveLength(0);
    });
  });

  describe("export methods", () => {
    it("should export logs as text", () => {
      logger.info("Test message");
      logger.error("Error message", { code: 500 });

      const text = logger.exportAsText();
      expect(text).toContain("Test message");
      expect(text).toContain("Error message");
      expect(text).toContain("code");
    });

    it("should export logs as JSON", () => {
      logger.info("Test message");
      const json = logger.exportAsJSON();
      const parsed = JSON.parse(json);

      expect(Array.isArray(parsed)).toBe(true);
      expect(parsed[0].message).toBe("Test message");
      expect(parsed[0].level).toBe(LogLevel.INFO);
    });
  });

  describe("log limit", () => {
    it("should maintain max log limit", () => {
      // Create more than 500 logs
      for (let i = 0; i < 600; i++) {
        logger.info(`Message ${i}`);
      }

      const logs = logger.getLogs();
      expect(logs.length).toBeLessThanOrEqual(500);
      // Should keep the latest logs
      expect(logs[logs.length - 1].message).toBe("Message 599");
    });
  });
});
