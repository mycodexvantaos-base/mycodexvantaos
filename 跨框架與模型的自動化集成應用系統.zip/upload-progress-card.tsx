import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { UploadProgress, uploadManager } from "@/lib/upload-manager";
import { useHaptics } from "@/hooks/use-haptics";

interface UploadProgressCardProps {
  upload: UploadProgress;
  onRetry?: () => void;
  onDismiss?: () => void;
}

/**
 * 上傳進度卡片元件
 * 顯示單個檔案的上傳進度和狀態
 */
export function UploadProgressCard({
  upload,
  onRetry,
  onDismiss,
}: UploadProgressCardProps) {
  const haptics = useHaptics();
  const [displayProgress, setDisplayProgress] = useState(upload.progress);

  useEffect(() => {
    // 平滑動畫進度條
    const interval = setInterval(() => {
      setDisplayProgress((prev) => {
        const diff = upload.progress - prev;
        if (Math.abs(diff) < 1) {
          return upload.progress;
        }
        return prev + diff * 0.3;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [upload.progress]);

  const getStatusColor = () => {
    switch (upload.status) {
      case "success":
        return "#22C55E";
      case "error":
        return "#EF4444";
      case "uploading":
        return "#0a7ea4";
      case "processing":
        return "#F59E0B";
      default:
        return "#888780";
    }
  };

  const getStatusText = () => {
    switch (upload.status) {
      case "success":
        return "✓ 完成";
      case "error":
        return "❌ 失敗";
      case "uploading":
        return `上傳中 ${Math.round(displayProgress)}%`;
      case "processing":
        return "處理中...";
      default:
        return "待上傳";
    }
  };

  const handleRetry = async () => {
    await haptics.buttonPress();
    onRetry?.();
  };

  const handleDismiss = async () => {
    await haptics.buttonPress();
    onDismiss?.();
  };

  return (
    <View className="bg-surface rounded-lg p-4 mb-3 border border-border">
      {/* 檔案名稱和狀態 */}
      <View className="flex-row items-center justify-between mb-3">
        <Text className="text-sm font-semibold text-foreground flex-1" numberOfLines={1}>
          {upload.fileName}
        </Text>
        <Text
          className="text-xs font-medium ml-2"
          style={{ color: getStatusColor() }}
        >
          {getStatusText()}
        </Text>
      </View>

      {/* 進度條 */}
      {upload.status !== "success" && upload.status !== "error" && (
        <View className="bg-border rounded-full h-2 mb-2 overflow-hidden">
          <View
            className="h-full rounded-full"
            style={{
              width: `${displayProgress}%`,
              backgroundColor: getStatusColor(),
            }}
          />
        </View>
      )}

      {/* 錯誤訊息 */}
      {upload.status === "error" && upload.error && (
        <Text className="text-xs text-error mb-3">{upload.error}</Text>
      )}

      {/* 操作按鈕 */}
      {upload.status === "error" && onRetry && (
        <TouchableOpacity
          onPress={handleRetry}
          className="bg-primary rounded-lg py-2 items-center justify-center"
        >
          <Text className="text-white text-xs font-semibold">重試</Text>
        </TouchableOpacity>
      )}

      {upload.status === "success" && onDismiss && (
        <TouchableOpacity
          onPress={handleDismiss}
          className="bg-success/10 rounded-lg py-2 items-center justify-center border border-success"
        >
          <Text className="text-success text-xs font-semibold">移除</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

/**
 * 上傳進度列表元件
 * 顯示所有正在進行的上傳
 */
interface UploadProgressListProps {
  onRetry?: (fileId: string) => void;
  onDismiss?: (fileId: string) => void;
}

export function UploadProgressList({
  onRetry,
  onDismiss,
}: UploadProgressListProps) {
  const [uploads, setUploads] = useState<UploadProgress[]>([]);

  useEffect(() => {
    const unsubscribe = uploadManager.subscribe((uploadsMap) => {
      setUploads(Array.from(uploadsMap.values()));
    });

    return unsubscribe;
  }, []);

  if (uploads.length === 0) {
    return null;
  }

  return (
    <View className="mb-4">
      <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-2">
        上傳進度
      </Text>
      {uploads.map((upload) => (
        <UploadProgressCard
          key={upload.fileId}
          upload={upload}
          onRetry={() => onRetry?.(upload.fileId)}
          onDismiss={() => onDismiss?.(upload.fileId)}
        />
      ))}
    </View>
  );
}
