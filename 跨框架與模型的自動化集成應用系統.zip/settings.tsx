import { ScrollView, Text, View, TextInput, TouchableOpacity, Alert, Switch } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useRouter } from "expo-router";
import { useState, useCallback, useEffect } from "react";
import { useHaptics } from "@/hooks/use-haptics";
import { useZipContext } from "@/lib/zip-context";

/**
 * 設定項目元件
 */
function SettingItem({ label, description, children }: { label: string; description?: string; children: React.ReactNode }) {
  return (
    <View className="bg-surface rounded-lg p-4 border border-border mb-3">
      <Text className="text-sm font-semibold text-foreground mb-1">{label}</Text>
      {description && <Text className="text-xs text-muted mb-3">{description}</Text>}
      {children}
    </View>
  );
}

export default function SettingsScreen() {
  const router = useRouter();
  const { apiKey, setApiKey, clearAll } = useZipContext();
  const haptics = useHaptics();
  const [tempApiKey, setTempApiKey] = useState(apiKey || "");
  const [showApiKey, setShowApiKey] = useState(false);

  // 當 apiKey 改變時更新 tempApiKey
  useEffect(() => {
    setTempApiKey(apiKey || "");
  }, [apiKey]);

  const handleSaveApiKey = useCallback(async () => {
    await haptics.buttonPress();
    if (!tempApiKey.trim()) {
      await haptics.warning();
      Alert.alert("錯誤", "請輸入 API 金鑰");
      return;
    }
    if (!tempApiKey.startsWith("sk-")) {
      Alert.alert(
        "警告",
        "API 金鑰通常以 'sk-' 開頭。確定要繼續嗎？",
        [
          { text: "取消", onPress: () => {} },
          {
            text: "繼續",
            onPress: async () => {
              setApiKey(tempApiKey);
              await haptics.success();
              Alert.alert("成功", "API 金鑰已保存");
            },
          },
        ]
      );
      return;
    }
    setApiKey(tempApiKey);
    await haptics.success();
    Alert.alert("成功", "API 金鑰已保存");
  }, [tempApiKey, setApiKey]);

  const handleClearAll = useCallback(async () => {
    await haptics.buttonPress();
    Alert.alert(
      "確認",
      "確定要清除所有資料嗎？此操作無法撤銷。",
      [
        { text: "取消", onPress: () => {} },
        {
          text: "清除",
          onPress: async () => {
            await clearAll();
            await haptics.success();
            Alert.alert("成功", "所有資料已清除");
          },
          style: "destructive",
        },
      ]
    );
  }, [clearAll]);

  return (
    <ScreenContainer className="flex-1">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="gap-6 pb-6">
          {/* 標題 */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">設定</Text>
            <Text className="text-sm text-muted">管理應用程式設定和偏好</Text>
          </View>

          {/* API 設定區域 */}
          <View>
            <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
              API 設定
            </Text>

            <SettingItem
              label="Anthropic API 金鑰"
              description="用於 AI 分析和合成功能。在 console.anthropic.com 取得"
            >
              <View className="flex-row gap-2 items-center">
                <TextInput
                  placeholder="sk-ant-..."
                  placeholderTextColor="#9BA1A6"
                  secureTextEntry={!showApiKey}
                  value={tempApiKey}
                  onChangeText={setTempApiKey}
                  className="flex-1 bg-background rounded px-3 py-2 text-sm text-foreground border border-border"
                />
                <TouchableOpacity
                  onPress={() => setShowApiKey(!showApiKey)}
                  className="px-3 py-2"
                >
                  <Text className="text-xs text-primary font-semibold">
                    {showApiKey ? "隱藏" : "顯示"}
                  </Text>
                </TouchableOpacity>
              </View>
              <TouchableOpacity
                onPress={handleSaveApiKey}
                className="mt-3 bg-primary rounded-lg py-2 items-center"
              >
                <Text className="text-sm font-semibold text-white">保存 API 金鑰</Text>
              </TouchableOpacity>
            </SettingItem>

            <SettingItem label="連線狀態">
              <View className="flex-row items-center gap-2">
                <View className={`w-2 h-2 rounded-full ${apiKey ? "bg-success" : "bg-warning"}`} />
                <Text className="text-sm text-foreground">
                  {apiKey ? "✓ 已設定" : "⚠ 未設定"}
                </Text>
              </View>
              {apiKey && (
                <Text className="text-xs text-muted mt-2">
                  金鑰: {apiKey.slice(0, 10)}...{apiKey.slice(-4)}
                </Text>
              )}
            </SettingItem>
          </View>

          {/* 應用程式設定區域 */}
          <View>
            <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
              應用程式
            </Text>

            <SettingItem label="應用程式版本">
              <Text className="text-sm text-foreground">1.0.0</Text>
            </SettingItem>

            <SettingItem label="關於">
              <Text className="text-xs text-muted leading-relaxed">
                ZIP Synthesis Platform 是一個支援跨框架與跨模型自動化編排整合的應用程式系統。上傳多個 ZIP 檔案，自動解析其內容，進行 AI 分析，最後合成統一的高級版本架構。
              </Text>
            </SettingItem>
          </View>

          {/* 資料管理區域 */}
          <View>
            <Text className="text-xs uppercase tracking-wider text-muted font-semibold mb-3">
              資料管理
            </Text>

            <SettingItem label="清除所有資料" description="刪除所有上傳的 ZIP 檔案和分析結果">
              <TouchableOpacity
                onPress={handleClearAll}
                className="bg-error/10 rounded-lg py-2 items-center border border-error"
              >
                <Text className="text-sm font-semibold text-error">清除所有資料</Text>
              </TouchableOpacity>
            </SettingItem>
          </View>

          {/* 返回按鈕 */}
          <TouchableOpacity
            onPress={() => router.back()}
            className="bg-primary rounded-lg py-3 items-center justify-center"
            activeOpacity={0.8}
          >
            <Text className="text-sm font-semibold text-white">返回</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
