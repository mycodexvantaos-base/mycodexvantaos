/**
 * 日誌記錄系統
 * 提供結構化的日誌記錄，包括不同的日誌級別和持久化存儲
 */

export enum LogLevel {
  DEBUG = "DEBUG",
  INFO = "INFO",
  WARN = "WARN",
  ERROR = "ERROR",
}

export interface LogEntry {
  timestamp: number;
  level: LogLevel;
  message: string;
  context?: Record<string, any>;
  error?: Error;
}

class Logger {
  private logs: LogEntry[] = [];
  private maxLogs = 500; // 最多保存 500 條日誌

  /**
   * 記錄日誌
   */
  private log(level: LogLevel, message: string, context?: Record<string, any>, error?: Error) {
    const entry: LogEntry = {
      timestamp: Date.now(),
      level,
      message,
      context,
      error,
    };

    this.logs.push(entry);

    // 保持日誌數量在限制內
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs);
    }

    // 同時輸出到控制台
    const consoleMethod = {
      [LogLevel.DEBUG]: console.debug,
      [LogLevel.INFO]: console.log,
      [LogLevel.WARN]: console.warn,
      [LogLevel.ERROR]: console.error,
    }[level];

    const logMessage = `[${entry.timestamp}] [${level}] ${message}`;
    if (context) {
      consoleMethod(logMessage, context);
    } else {
      consoleMethod(logMessage);
    }

    if (error) {
      consoleMethod("Error details:", error);
    }
  }

  debug(message: string, context?: Record<string, any>) {
    this.log(LogLevel.DEBUG, message, context);
  }

  info(message: string, context?: Record<string, any>) {
    this.log(LogLevel.INFO, message, context);
  }

  warn(message: string, context?: Record<string, any>) {
    this.log(LogLevel.WARN, message, context);
  }

  error(message: string, context?: Record<string, any>, error?: Error) {
    this.log(LogLevel.ERROR, message, context, error);
  }

  /**
   * 取得所有日誌
   */
  getLogs(): LogEntry[] {
    return [...this.logs];
  }

  /**
   * 取得特定級別的日誌
   */
  getLogsByLevel(level: LogLevel): LogEntry[] {
    return this.logs.filter((log) => log.level === level);
  }

  /**
   * 清除所有日誌
   */
  clear() {
    this.logs = [];
  }

  /**
   * 匯出日誌為文字格式
   */
  exportAsText(): string {
    return this.logs
      .map((log) => {
        const date = new Date(log.timestamp).toISOString();
        let text = `[${date}] [${log.level}] ${log.message}`;
        if (log.context) {
          text += `\n  Context: ${JSON.stringify(log.context, null, 2)}`;
        }
        if (log.error) {
          text += `\n  Error: ${log.error.message}\n  Stack: ${log.error.stack}`;
        }
        return text;
      })
      .join("\n\n");
  }

  /**
   * 匯出日誌為 JSON 格式
   */
  exportAsJSON(): string {
    return JSON.stringify(this.logs, null, 2);
  }
}

// 導出單例
export const logger = new Logger();
