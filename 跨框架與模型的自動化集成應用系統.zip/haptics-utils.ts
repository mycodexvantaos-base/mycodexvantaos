import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

/**
 * 觸覺回饋類型
 */
export enum HapticType {
  // 輕微點擊反饋
  Light = "light",
  // 中等反饋
  Medium = "medium",
  // 重型反饋
  Heavy = "heavy",
  // 成功反饋
  Success = "success",
  // 警告反饋
  Warning = "warning",
  // 錯誤反饋
  Error = "error",
}

/**
 * 執行觸覺回饋（僅在原生平台上）
 */
export async function triggerHaptic(type: HapticType = HapticType.Light): Promise<void> {
  // 跳過 Web 平台
  if (Platform.OS === "web") {
    return;
  }

  try {
    switch (type) {
      case HapticType.Light:
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        break;
      case HapticType.Medium:
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        break;
      case HapticType.Heavy:
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
        break;
      case HapticType.Success:
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        break;
      case HapticType.Warning:
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        break;
      case HapticType.Error:
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        break;
    }
  } catch (error) {
    console.warn("Haptic feedback error:", error);
  }
}

/**
 * 按鈕點擊反饋（輕微）
 */
export async function hapticButtonPress(): Promise<void> {
  await triggerHaptic(HapticType.Light);
}

/**
 * 操作成功反饋
 */
export async function hapticSuccess(): Promise<void> {
  await triggerHaptic(HapticType.Success);
}

/**
 * 操作錯誤反饋
 */
export async function hapticError(): Promise<void> {
  await triggerHaptic(HapticType.Error);
}

/**
 * 操作警告反饋
 */
export async function hapticWarning(): Promise<void> {
  await triggerHaptic(HapticType.Warning);
}

/**
 * 長按反饋（中等）
 */
export async function hapticLongPress(): Promise<void> {
  await triggerHaptic(HapticType.Medium);
}

/**
 * 切換反饋
 */
export async function hapticToggle(): Promise<void> {
  await triggerHaptic(HapticType.Light);
}

/**
 * 選擇反饋
 */
export async function hapticSelection(): Promise<void> {
  if (Platform.OS === "web") {
    return;
  }

  try {
    await Haptics.selectionAsync();
  } catch (error) {
    console.warn("Selection haptic error:", error);
  }
}
