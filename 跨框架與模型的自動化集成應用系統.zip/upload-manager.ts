/**
 * 上傳進度管理系統
 * 追蹤多個檔案的上傳進度和狀態
 */

export interface UploadProgress {
  fileId: string;
  fileName: string;
  progress: number; // 0-100
  status: "pending" | "uploading" | "processing" | "success" | "error";
  error?: string;
  startTime?: number;
  endTime?: number;
}

export interface UploadStats {
  totalFiles: number;
  completedFiles: number;
  failedFiles: number;
  totalProgress: number; // 0-100
  estimatedTimeRemaining?: number; // 毫秒
}

class UploadManager {
  private uploads: Map<string, UploadProgress> = new Map();
  private listeners: Set<(uploads: Map<string, UploadProgress>) => void> = new Set();

  /**
   * 建立新的上傳任務
   */
  createUpload(fileId: string, fileName: string): void {
    this.uploads.set(fileId, {
      fileId,
      fileName,
      progress: 0,
      status: "pending",
      startTime: Date.now(),
    });
    this.notifyListeners();
  }

  /**
   * 更新上傳進度
   */
  updateProgress(fileId: string, progress: number): void {
    const upload = this.uploads.get(fileId);
    if (upload) {
      upload.progress = Math.min(100, Math.max(0, progress));
      upload.status = progress < 100 ? "uploading" : "processing";
      this.notifyListeners();
    }
  }

  /**
   * 標記上傳成功
   */
  markSuccess(fileId: string): void {
    const upload = this.uploads.get(fileId);
    if (upload) {
      upload.progress = 100;
      upload.status = "success";
      upload.endTime = Date.now();
      this.notifyListeners();
    }
  }

  /**
   * 標記上傳失敗
   */
  markError(fileId: string, error: string): void {
    const upload = this.uploads.get(fileId);
    if (upload) {
      upload.status = "error";
      upload.error = error;
      upload.endTime = Date.now();
      this.notifyListeners();
    }
  }

  /**
   * 取得單個上傳的進度
   */
  getUpload(fileId: string): UploadProgress | undefined {
    return this.uploads.get(fileId);
  }

  /**
   * 取得所有上傳的進度
   */
  getAllUploads(): UploadProgress[] {
    return Array.from(this.uploads.values());
  }

  /**
   * 取得上傳統計資訊
   */
  getStats(): UploadStats {
    const uploads = Array.from(this.uploads.values());
    const totalFiles = uploads.length;
    const completedFiles = uploads.filter((u) => u.status === "success").length;
    const failedFiles = uploads.filter((u) => u.status === "error").length;
    const totalProgress = totalFiles > 0 
      ? Math.round(uploads.reduce((sum, u) => sum + u.progress, 0) / totalFiles)
      : 0;

    // 計算預估剩餘時間
    const uploadingFiles = uploads.filter((u) => u.status === "uploading");
    let estimatedTimeRemaining: number | undefined;

    if (uploadingFiles.length > 0) {
      const avgTimePerFile = uploadingFiles.reduce((sum, u) => {
        if (u.startTime && u.progress > 0) {
          const elapsed = Date.now() - u.startTime;
          return sum + (elapsed / u.progress) * (100 - u.progress);
        }
        return sum;
      }, 0) / uploadingFiles.length;

      estimatedTimeRemaining = Math.round(avgTimePerFile);
    }

    return {
      totalFiles,
      completedFiles,
      failedFiles,
      totalProgress,
      estimatedTimeRemaining,
    };
  }

  /**
   * 清除所有上傳記錄
   */
  clear(): void {
    this.uploads.clear();
    this.notifyListeners();
  }

  /**
   * 移除特定的上傳記錄
   */
  remove(fileId: string): void {
    this.uploads.delete(fileId);
    this.notifyListeners();
  }

  /**
   * 訂閱進度更新
   */
  subscribe(listener: (uploads: Map<string, UploadProgress>) => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  /**
   * 通知所有監聽器
   */
  private notifyListeners(): void {
    this.listeners.forEach((listener) => {
      listener(new Map(this.uploads));
    });
  }

  /**
   * 格式化時間
   */
  formatTime(ms: number): string {
    if (ms < 1000) return `${Math.round(ms)}ms`;
    if (ms < 60000) return `${Math.round(ms / 1000)}s`;
    return `${Math.round(ms / 60000)}m`;
  }
}

// 導出單例
export const uploadManager = new UploadManager();
