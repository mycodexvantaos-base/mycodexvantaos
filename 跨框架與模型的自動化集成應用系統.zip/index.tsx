import { ScrollView, Text, View, TouchableOpacity, FlatList, Alert, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useZipContext, useZipStats as useZipStatsHook } from "@/lib/zip-context";
import { useRouter } from "expo-router";
import { useState, useCallback } from "react";
import { useHaptics } from "@/hooks/use-haptics";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import JSZip from "jszip";
import type { ZipItem } from "@/lib/zip-synthesis";
import { detectFrameworkType, buildFileTree } from "@/lib/zip-synthesis";
import { callClaudeAPI, validateApiKey } from "@/lib/api-client";
import { buildAnalysisPrompt, buildSynthesisPrompt, parseAnalysisResult } from "@/lib/zip-synthesis";
import { uploadManager } from "@/lib/upload-manager";
import { UploadProgressList } from "@/components/upload-progress-card";
import { logger } from "@/lib/logger";

/**
 * 狀態指示點元件
 */
function StatusDot({ status }: { status: ZipItem["status"] }) {
  const colors = {
    pending: "#888780",
    analyzing: "#EF9F27",
    done: "#1D9E75",
    error: "#E24B4A",
  };

  return (
    <View
      className="w-1.5 h-1.5 rounded-full flex-shrink-0"
      style={{ backgroundColor: colors[status] || "#888" }}
    />
  );
}

/**
 * 技術棧標籤元件
 */
function TagPill({ label }: { label: string }) {
  const map: Record<string, string> = {
    "TypeScript": "#E6F1FB",
    "TypeScript/Node": "#E6F1FB",
    "JavaScript/Node": "#FAEEDA",
    "Python": "#EAF3DE",
    "Go": "#E1F5EE",
    "Rust": "#FAECE7",
  };

  const textColorMap: Record<string, string> = {
    "TypeScript": "#185FA5",
    "TypeScript/Node": "#185FA5",
    "JavaScript/Node": "#854F0B",
    "Python": "#3B6D11",
    "Go": "#0F6E56",
    "Rust": "#993C1D",
  };

  const bg = map[label] || "#F1EFE8";
  const fg = textColorMap[label] || "#5F5E5A";

  return (
    <View
      className="px-2 py-1 rounded-full"
      style={{ backgroundColor: bg }}
    >
      <Text className="text-xs font-medium" style={{ color: fg }}>
        {label}
      </Text>
    </View>
  );
}

/**
 * 統計卡片元件
 */
function StatCard({ label, value, sub }: { label: string; value: string | number; sub: string }) {
  return (
    <View className="bg-surface rounded-lg p-3 flex-1">
      <Text className="text-xs uppercase tracking-wider text-muted font-medium">{label}</Text>
      <Text className="text-2xl font-semibold text-foreground mt-1">{value}</Text>
      <Text className="text-xs text-muted mt-1">{sub}</Text>
    </View>
  );
}

/**
 * ZIP 列表項目元件
 */
function ZipListItem({ item, index }: { item: ZipItem; index: number }) {
  const router = useRouter();
  const { selectZip } = useZipContext();

  const handlePress = useCallback(() => {
    selectZip(index);
    router.push("/zip-detail");
  }, [selectZip, index, router]);

  return (
    <TouchableOpacity
      onPress={handlePress}
      activeOpacity={0.7}
    >
      <View className="bg-surface rounded-lg p-4 mb-3 border border-border">
        <View className="flex-row items-center justify-between mb-2">
          <View className="flex-row items-center gap-2 flex-1">
            <StatusDot status={item.status} />
            <Text className="text-sm font-semibold text-foreground flex-1" numberOfLines={1}>
              {item.name}
            </Text>
          </View>
          <Text className="text-xs text-muted">{item.files.length} 檔案</Text>
        </View>

        <View className="flex-row items-center gap-2">
          <TagPill label={item.type} />
          <Text className="text-xs text-muted flex-1">
            {item.status === "analyzing" && "分析中..."}
            {item.status === "done" && "✓ 已完成"}
            {item.status === "pending" && "待分析"}
            {item.status === "error" && "❌ 錯誤"}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

export default function HomeScreen() {
  const router = useRouter();
  const { zips, addZips, selectZip, updateZipStatus, updateZipAnalysis, updateZipError, setSynthResult } = useZipContext();
  const stats = useZipStatsHook();
  const haptics = useHaptics();
  const [isPickingFile, setIsPickingFile] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSynthesizing, setIsSynthesizing] = useState(false);

  /**
   * 從 ZIP 檔案提取代碼片段
   */
  const extractSampleCode = useCallback(async (zip: JSZip): Promise<string> => {
    const codeExts = [".ts", ".tsx", ".py", ".go", ".rs", ".js", ".vue"];
    
    for (const [path, entry] of Object.entries(zip.files)) {
      if (!entry.dir && codeExts.some(e => path.endsWith(e)) && !path.includes("node_modules") && !path.includes(".min.")) {
        try {
          const text = await entry.async("string");
          if (text.length > 50) {
            return `\n\n=== 代碼片段 (${path}) ===\n${text.slice(0, 600)}`;
          }
        } catch (e) {
          logger.warn("Error extracting code", { path });
        }
      }
    }
    return "";
  }, []);

  /**
   * 處理檔案選擇（支援批量上傳）
   */
  const handlePickFile = useCallback(async () => {
    await haptics.buttonPress();
    setIsPickingFile(true);
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "application/zip",
        multiple: true,
      });

      if (!result.canceled && result.assets.length > 0) {
        const newZips: ZipItem[] = [];
        let successCount = 0;
        let errorCount = 0;

        for (const asset of result.assets) {
          const fileId = `${Date.now()}_${Math.random()}`;
          uploadManager.createUpload(fileId, asset.name);

          try {
            logger.info("Starting file upload", { fileName: asset.name, fileId });
            uploadManager.updateProgress(fileId, 10);

            const base64 = await FileSystem.readAsStringAsync(asset.uri, {
              encoding: FileSystem.EncodingType.Base64,
            });
            uploadManager.updateProgress(fileId, 50);

            const jszip = new JSZip();
            const zip = await jszip.loadAsync(base64, { base64: true });
            uploadManager.updateProgress(fileId, 75);

            const fileList: Array<{ name: string }> = [];
            zip.forEach((relativePath, entry) => {
              if (!entry.dir) {
                fileList.push({ name: relativePath });
              }
            });

            const type = detectFrameworkType(fileList);

            const newZip: ZipItem = {
              id: Date.now() + Math.random(),
              name: asset.name,
              files: fileList,
              type,
              status: "pending",
              analysis: null,
              error: null,
            };

            newZips.push(newZip);
            uploadManager.markSuccess(fileId);
            logger.info("File upload successful", { fileName: asset.name, type });
            successCount++;
          } catch (error) {
            const errorMsg = error instanceof Error ? error.message : "未知錯誤";
            uploadManager.markError(fileId, errorMsg);
            logger.error("File upload failed", { fileName: asset.name }, error as Error);
            errorCount++;
          }
        }

        if (newZips.length > 0) {
          addZips(newZips);
          await haptics.success();
        }

        if (successCount > 0 && errorCount === 0) {
          Alert.alert("成功", `已上傳 ${successCount} 個檔案`);
        } else if (successCount > 0 && errorCount > 0) {
          Alert.alert("部分成功", `成功上傳 ${successCount} 個檔案，${errorCount} 個失敗`);
        } else if (errorCount > 0) {
          await haptics.error();
          Alert.alert("失敗", `${errorCount} 個檔案上傳失敗`);
        }
      }
    } catch (error) {
      logger.error("File picker error", {}, error as Error);
      await haptics.error();
    } finally {
      setIsPickingFile(false);
    }
  }, [addZips, haptics]);

  /**
   * 分析單個 ZIP
   */
  const analyzeZip = useCallback(async (index: number) => {
    const zip = zips[index];
    if (!zip || zip.status === "analyzing" || zip.status === "done") return;

    const apiKey = "sk-ant-api03-test";
    if (!validateApiKey(apiKey)) {
      Alert.alert("錯誤", "請先設定 Anthropic API 金鑰");
      return;
    }

    updateZipStatus(index, "analyzing");

    try {
      const fileList = zip.files.slice(0, 80).map(f => f.name).join("\n");
      const sampleCode = "";
      
      const prompt = buildAnalysisPrompt(zip.name, zip.files.length, zip.type, fileList, sampleCode);

      const response = await callClaudeAPI(apiKey, prompt);
      const analysis = parseAnalysisResult(response);

      updateZipAnalysis(index, analysis);
      logger.info("ZIP analysis completed", { fileName: zip.name });
    } catch (error) {
      logger.error("Analysis error", { fileName: zip.name }, error as Error);
      updateZipError(index, error instanceof Error ? error.message : "分析失敗");
    }
  }, [zips, updateZipStatus, updateZipAnalysis, updateZipError]);

  /**
   * 全部分析
   */
  const analyzeAll = useCallback(async () => {
    await haptics.buttonPress();
    setIsAnalyzing(true);
    try {
      const pendingZips = zips
        .map((z, i) => ({ zip: z, index: i }))
        .filter(({ zip }) => zip.status === "pending");

      for (const { index } of pendingZips) {
        await analyzeZip(index);
      }
      await haptics.success();
    } catch (error) {
      logger.error("Batch analysis error", {}, error as Error);
      await haptics.error();
    } finally {
      setIsAnalyzing(false);
    }
  }, [zips, analyzeZip, haptics]);

  /**
   * 合成架構
   */
  const synthesize = useCallback(async () => {
    await haptics.buttonPress();
    setIsSynthesizing(true);
    try {
      const done = zips.filter(z => z.status === "done");
      if (done.length < 2) {
        Alert.alert("錯誤", "需要至少 2 個已完成分析的 ZIP 檔案");
        return;
      }

      const apiKey = "sk-ant-api03-test";
      const prompt = buildSynthesisPrompt(done);

      const response = await callClaudeAPI(apiKey, prompt);

      const synthResult = {
        timestamp: Date.now(),
        architecture: response.slice(200, 600),
        contributions: done.map((z, i) => ({
          version: z.name,
          contribution: z.analysis?.value || "核心邏輯",
        })),
        actionPlan: [
          "統一目錄結構和命名規範",
          "整合核心業務邏輯模組",
          "建立統一的測試和部署流程",
        ],
        strategy: "統一架構",
        conflicts: [],
      };

      setSynthResult(synthResult);
      logger.info("Architecture synthesis completed", { fileCount: done.length });
      router.push("/synthesis-result");
    } catch (error) {
      logger.error("Synthesis error", {}, error as Error);
      Alert.alert("錯誤", "合成失敗，請重試");
    } finally {
      setIsSynthesizing(false);
    }
  }, [zips, setSynthResult, router, haptics]);

  /**
   * Header 元件
   */
  const renderHeader = () => (
    <View className="gap-6 pb-4">
      <View className="gap-2">
        <Text className="text-2xl font-bold text-foreground">ZIP Synthesis</Text>
        <Text className="text-sm text-muted">上傳 → 解析 → 對齐 → 合成</Text>
      </View>

      <View className="flex-row gap-3">
        <StatCard label="已分析" value={stats.doneCount} sub="個版本" />
        <StatCard label="技術棧" value={stats.typeCount} sub="種類" />
        <StatCard label="衝突" value={stats.conflictCount} sub="個檔案" />
      </View>

      {/* 上傳進度列表 */}
      <UploadProgressList
        onRetry={() => handlePickFile()}
        onDismiss={(fileId) => uploadManager.remove(fileId)}
      />

      <TouchableOpacity
        onPress={handlePickFile}
        disabled={isPickingFile}
        activeOpacity={0.7}
      >
        <View className="border-2 border-dashed border-border rounded-lg p-8 items-center justify-center bg-surface/50">
          {isPickingFile ? (
            <>
              <ActivityIndicator size="large" color="#0a7ea4" />
              <Text className="text-sm text-muted mt-2">上傳中...</Text>
            </>
          ) : (
            <>
              <Text className="text-3xl mb-2">📁</Text>
              <Text className="text-sm font-semibold text-foreground">點擊上傳 ZIP 檔案</Text>
              <Text className="text-xs text-muted mt-1">支援多檔案批量上傳</Text>
            </>
          )}
        </View>
      </TouchableOpacity>

      {zips.length > 0 && (
        <View className="flex-row gap-3">
          <TouchableOpacity
            onPress={analyzeAll}
            disabled={isAnalyzing}
            className="flex-1 bg-primary rounded-lg py-3 items-center justify-center"
            activeOpacity={0.8}
          >
            {isAnalyzing ? (
              <ActivityIndicator size="small" color="white" />
            ) : (
              <Text className="text-sm font-semibold text-white">全部分析</Text>
            )}
          </TouchableOpacity>

          {stats.doneCount >= 2 && (
            <TouchableOpacity
              onPress={synthesize}
              disabled={isSynthesizing}
              className="flex-1 bg-success rounded-lg py-3 items-center justify-center"
              activeOpacity={0.8}
            >
              {isSynthesizing ? (
                <ActivityIndicator size="small" color="white" />
              ) : (
                <Text className="text-sm font-semibold text-white">合成架構</Text>
              )}
            </TouchableOpacity>
          )}
        </View>
      )}

      {zips.length > 0 && (
        <Text className="text-xs uppercase tracking-wider text-muted font-semibold">
          已上傳的檔案
        </Text>
      )}
    </View>
  );

  /**
   * Empty 元件
   */
  const renderEmpty = () => (
    <View className="items-center justify-center py-12">
      <Text className="text-lg font-semibold text-foreground mb-2">還沒有上傳任何檔案</Text>
      <Text className="text-sm text-muted text-center">
        上傳 ZIP 檔案開始使用 ZIP Synthesis Platform
      </Text>
    </View>
  );

  return (
    <ScreenContainer className="flex-1">
      <FlatList
        data={zips}
        renderItem={({ item, index }) => <ZipListItem item={item} index={index} />}
        keyExtractor={(item) => item.id.toString()}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={renderEmpty}
        contentContainerStyle={{ flexGrow: 1, paddingHorizontal: 16, paddingTop: 16, paddingBottom: 16 }}
        scrollEnabled={zips.length > 0}
      />
    </ScreenContainer>
  );
}
