import { describe, it, expect, beforeEach, vi } from "vitest";
import { uploadManager, UploadProgress } from "./upload-manager";

describe("UploadManager", () => {
  beforeEach(() => {
    uploadManager.clear();
  });

  describe("createUpload", () => {
    it("should create a new upload with pending status", () => {
      uploadManager.createUpload("file1", "test.zip");
      const upload = uploadManager.getUpload("file1");

      expect(upload).toBeDefined();
      expect(upload?.fileId).toBe("file1");
      expect(upload?.fileName).toBe("test.zip");
      expect(upload?.progress).toBe(0);
      expect(upload?.status).toBe("pending");
    });
  });

  describe("updateProgress", () => {
    it("should update progress and status", () => {
      uploadManager.createUpload("file1", "test.zip");
      uploadManager.updateProgress("file1", 50);

      const upload = uploadManager.getUpload("file1");
      expect(upload?.progress).toBe(50);
      expect(upload?.status).toBe("uploading");
    });

    it("should clamp progress between 0 and 100", () => {
      uploadManager.createUpload("file1", "test.zip");
      uploadManager.updateProgress("file1", 150);

      const upload = uploadManager.getUpload("file1");
      expect(upload?.progress).toBe(100);
    });
  });

  describe("markSuccess", () => {
    it("should mark upload as success", () => {
      uploadManager.createUpload("file1", "test.zip");
      uploadManager.markSuccess("file1");

      const upload = uploadManager.getUpload("file1");
      expect(upload?.status).toBe("success");
      expect(upload?.progress).toBe(100);
      expect(upload?.endTime).toBeDefined();
    });
  });

  describe("markError", () => {
    it("should mark upload as error with message", () => {
      uploadManager.createUpload("file1", "test.zip");
      uploadManager.markError("file1", "Network error");

      const upload = uploadManager.getUpload("file1");
      expect(upload?.status).toBe("error");
      expect(upload?.error).toBe("Network error");
      expect(upload?.endTime).toBeDefined();
    });
  });

  describe("getStats", () => {
    it("should calculate correct statistics", () => {
      uploadManager.createUpload("file1", "test1.zip");
      uploadManager.createUpload("file2", "test2.zip");
      uploadManager.createUpload("file3", "test3.zip");

      uploadManager.updateProgress("file1", 50);
      uploadManager.markSuccess("file2");
      uploadManager.markError("file3", "Failed");

      const stats = uploadManager.getStats();
      expect(stats.totalFiles).toBe(3);
      expect(stats.completedFiles).toBe(1);
      expect(stats.failedFiles).toBe(1);
      expect(stats.totalProgress).toBeGreaterThan(0);
    });

    it("should return 0 progress when no uploads", () => {
      const stats = uploadManager.getStats();
      expect(stats.totalFiles).toBe(0);
      expect(stats.totalProgress).toBe(0);
    });
  });

  describe("subscribe", () => {
    it("should notify listeners on changes", () => {
      const listener = vi.fn();
      uploadManager.subscribe(listener);

      uploadManager.createUpload("file1", "test.zip");
      expect(listener).toHaveBeenCalled();

      uploadManager.updateProgress("file1", 50);
      expect(listener).toHaveBeenCalledTimes(2);
    });

    it("should unsubscribe listener", () => {
      const listener = vi.fn();
      const unsubscribe = uploadManager.subscribe(listener);

      uploadManager.createUpload("file1", "test.zip");
      expect(listener).toHaveBeenCalledTimes(1);

      unsubscribe();
      uploadManager.updateProgress("file1", 50);
      expect(listener).toHaveBeenCalledTimes(1);
    });
  });

  describe("formatTime", () => {
    it("should format time correctly", () => {
      expect(uploadManager.formatTime(500)).toBe("500ms");
      expect(uploadManager.formatTime(1500)).toBe("2s");
      expect(uploadManager.formatTime(90000)).toBe("2m");
    });
  });
});
