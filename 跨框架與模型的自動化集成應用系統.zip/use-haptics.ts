import { useCallback } from "react";
import {
  triggerHaptic,
  hapticButtonPress,
  hapticSuccess,
  hapticError,
  hapticWarning,
  hapticLongPress,
  hapticToggle,
  hapticSelection,
  HapticType,
} from "@/lib/haptics-utils";

/**
 * 觸覺回饋 Hook
 */
export function useHaptics() {
  const trigger = useCallback((type: HapticType) => triggerHaptic(type), []);
  const buttonPress = useCallback(() => hapticButtonPress(), []);
  const success = useCallback(() => hapticSuccess(), []);
  const error = useCallback(() => hapticError(), []);
  const warning = useCallback(() => hapticWarning(), []);
  const longPress = useCallback(() => hapticLongPress(), []);
  const toggle = useCallback(() => hapticToggle(), []);
  const selection = useCallback(() => hapticSelection(), []);

  return {
    trigger,
    buttonPress,
    success,
    error,
    warning,
    longPress,
    toggle,
    selection,
  };
}
