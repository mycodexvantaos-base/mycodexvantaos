/**
 * ZIP Synthesis Platform - State Management Context
 */

import React, { createContext, useContext, useReducer, useCallback, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { ZipItem, AnalysisResult, SynthesisResult } from "./zip-synthesis";
import { detectFrameworkType, calculateStats } from "./zip-synthesis";
import { clearAllCache } from "./cache-manager";

export interface ZipContextType {
  zips: ZipItem[];
  selectedIndex: number | null;
  synthResult: SynthesisResult | null;
  apiKey: string;
  
  addZips: (newZips: ZipItem[]) => void;
  selectZip: (index: number | null) => void;
  updateZipStatus: (index: number, status: ZipItem["status"]) => void;
  updateZipAnalysis: (index: number, analysis: AnalysisResult) => void;
  updateZipError: (index: number, error: string) => void;
  setSynthResult: (result: SynthesisResult | null) => void;
  setApiKey: (key: string) => void;
  clearAll: () => void;
}

const ZipContext = createContext<ZipContextType | undefined>(undefined);

type Action =
  | { type: "ADD_ZIPS"; payload: ZipItem[] }
  | { type: "SELECT_ZIP"; payload: number | null }
  | { type: "UPDATE_STATUS"; payload: { index: number; status: ZipItem["status"] } }
  | { type: "UPDATE_ANALYSIS"; payload: { index: number; analysis: AnalysisResult } }
  | { type: "UPDATE_ERROR"; payload: { index: number; error: string } }
  | { type: "SET_SYNTH_RESULT"; payload: SynthesisResult | null }
  | { type: "SET_API_KEY"; payload: string }
  | { type: "CLEAR_ALL" };

interface State {
  zips: ZipItem[];
  selectedIndex: number | null;
  synthResult: SynthesisResult | null;
  apiKey: string;
}

const initialState: State = {
  zips: [],
  selectedIndex: null,
  synthResult: null,
  apiKey: "",
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "ADD_ZIPS": {
      const updated = [...state.zips, ...action.payload];
      return {
        ...state,
        zips: updated,
        selectedIndex: state.selectedIndex === null && updated.length > 0 ? 0 : state.selectedIndex,
      };
    }
    case "SELECT_ZIP":
      return { ...state, selectedIndex: action.payload };
    case "UPDATE_STATUS":
      return {
        ...state,
        zips: state.zips.map((z, i) =>
          i === action.payload.index ? { ...z, status: action.payload.status } : z
        ),
      };
    case "UPDATE_ANALYSIS":
      return {
        ...state,
        zips: state.zips.map((z, i) =>
          i === action.payload.index ? { ...z, analysis: action.payload.analysis, status: "done" } : z
        ),
      };
    case "UPDATE_ERROR":
      return {
        ...state,
        zips: state.zips.map((z, i) =>
          i === action.payload.index ? { ...z, error: action.payload.error, status: "error" } : z
        ),
      };
    case "SET_SYNTH_RESULT":
      return { ...state, synthResult: action.payload };
    case "SET_API_KEY":
      return { ...state, apiKey: action.payload };
    case "CLEAR_ALL":
      return initialState;
    default:
      return state;
  }
}

export function ZipProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  // 載入 API 金鑰
  useEffect(() => {
    const loadApiKey = async () => {
      try {
        const saved = await AsyncStorage.getItem("zip_synthesis_api_key");
        if (saved) {
          dispatch({ type: "SET_API_KEY", payload: saved });
        }
      } catch (error) {
        console.error("Error loading API key:", error);
      }
    };
    loadApiKey();
  }, []);

  const addZips = useCallback((newZips: ZipItem[]) => {
    dispatch({ type: "ADD_ZIPS", payload: newZips });
  }, []);

  const selectZip = useCallback((index: number | null) => {
    dispatch({ type: "SELECT_ZIP", payload: index });
  }, []);

  const updateZipStatus = useCallback((index: number, status: ZipItem["status"]) => {
    dispatch({ type: "UPDATE_STATUS", payload: { index, status } });
  }, []);

  const updateZipAnalysis = useCallback((index: number, analysis: AnalysisResult) => {
    dispatch({ type: "UPDATE_ANALYSIS", payload: { index, analysis } });
  }, []);

  const updateZipError = useCallback((index: number, error: string) => {
    dispatch({ type: "UPDATE_ERROR", payload: { index, error } });
  }, []);

  const setSynthResult = useCallback((result: SynthesisResult | null) => {
    dispatch({ type: "SET_SYNTH_RESULT", payload: result });
  }, []);

  const setApiKey = useCallback((key: string) => {
    dispatch({ type: "SET_API_KEY", payload: key });
    // 異步保存到 AsyncStorage
    AsyncStorage.setItem("zip_synthesis_api_key", key).catch((error) => {
      console.error("Error saving API key:", error);
    });
  }, []);

  const clearAll = useCallback(async () => {
    dispatch({ type: "CLEAR_ALL" });
    await clearAllCache();
  }, []);

  const value: ZipContextType = {
    zips: state.zips,
    selectedIndex: state.selectedIndex,
    synthResult: state.synthResult,
    apiKey: state.apiKey,
    addZips,
    selectZip,
    updateZipStatus,
    updateZipAnalysis,
    updateZipError,
    setSynthResult,
    setApiKey,
    clearAll,
  };

  return <ZipContext.Provider value={value}>{children}</ZipContext.Provider>;
}

export function useZipContext(): ZipContextType {
  const context = useContext(ZipContext);
  if (!context) {
    throw new Error("useZipContext must be used within ZipProvider");
  }
  return context;
}

/**
 * 取得統計資訊的 Hook
 */
export function useZipStats() {
  const { zips } = useZipContext();
  return calculateStats(zips);
}
