/**
 * File Utilities for ZIP Processing
 */

import * as FileSystem from "expo-file-system/legacy";

/**
 * 從檔案 URI 讀取檔案內容為 Base64
 */
export async function readFileAsBase64(uri: string): Promise<string> {
  try {
    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    return base64;
  } catch (error) {
    console.error("Error reading file:", error);
    throw error;
  }
}

/**
 * 檢查檔案是否為 ZIP 檔案
 */
export function isZipFile(filename: string): boolean {
  return filename.toLowerCase().endsWith(".zip");
}

/**
 * 提取檔案名稱（不含路徑）
 */
export function getFileName(uri: string): string {
  return uri.split("/").pop() || "unknown";
}

/**
 * 驗證檔案大小（限制在 100MB）
 */
export function validateFileSize(size: number, maxSizeMB: number = 100): boolean {
  const maxBytes = maxSizeMB * 1024 * 1024;
  return size <= maxBytes;
}

/**
 * 格式化檔案大小為可讀格式
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
}

/**
 * 延遲函式（用於模擬非同步操作）
 */
export function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}
