 * ZIP Synthesis Platform - Core Logic
 * Handles ZIP parsing, framework detection, and AI analysis
 */

export type FrameworkType = "TypeScript" | "TypeScript/Node" | "JavaScript/Node" | "Python" | "Go" | "Rust" | "Mixed" | "error";

export type AnalysisStatus = "pending" | "analyzing" | "done" | "error";

export interface FileEntry {
  name: string;
}

export interface AnalysisResult {
  tags: string[];
  overview: string;
  architecture: string;
  value: string;
}

export interface ZipItem {
  id: number;
  name: string;
  files: FileEntry[];
  type: FrameworkType;
  status: AnalysisStatus;
  analysis: AnalysisResult | null;
  error: string | null;
}

export interface SynthesisResult {
  strategy: string;
  conflicts: Array<{ issue: string; solution: string }>;
  architecture: string;
  contributions: Array<{ version: string; contribution: string }>;
  actionPlan: string[];
}

/**
 * 偵測 ZIP 檔案中的技術棧類型
 */
export function detectFrameworkType(files: FileEntry[]): FrameworkType {
  const names = files.map(f => f.name.toLowerCase());
  const exts = names.map(n => n.split(".").pop());
  
  const tsCount = exts.filter(e => e === "ts" || e === "tsx").length;
  const pyCount = exts.filter(e => e === "py").length;
  const goCount = exts.filter(e => e === "go").length;
  const rsCount = exts.filter(e => e === "rs").length;
  