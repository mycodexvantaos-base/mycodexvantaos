/**
 * API Client for Anthropic Claude Integration
 */

export interface MessageResponse {
  content: Array<{
    type: string;
    text: string;
  }>;
}

/**
 * 呼叫 Anthropic Claude API 進行分析
 */
export async function callClaudeAPI(
  apiKey: string,
  prompt: string,
  maxTokens: number = 1000
): Promise<string> {
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: maxTokens,
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`API Error: ${response.status} - ${error}`);
    }

    const data = (await response.json()) as MessageResponse;
    return data.content?.[0]?.text || "{}";
  } catch (error) {
    console.error("Claude API Error:", error);
    throw error;
  }
}

/**
 * 驗證 API 金鑰格式
 */
export function validateApiKey(apiKey: string): boolean {
  return apiKey.length > 0 && apiKey.startsWith("sk-");
}

/**
 * 安全地儲存 API 金鑰（使用 SecureStore）
 */
export async function saveApiKeySecurely(apiKey: string): Promise<void> {
  try {
    const SecureStore = await import("expo-secure-store");
    await SecureStore.setItemAsync("claude_api_key", apiKey);
  } catch (error) {
    console.error("Error saving API key:", error);
    throw error;
  }
}

/**
 * 從 SecureStore 取得 API 金鑰
 */
export async function getApiKeySecurely(): Promise<string | null> {
  try {
    const SecureStore = await import("expo-secure-store");
    return await SecureStore.getItemAsync("claude_api_key");
  } catch (error) {
    console.error("Error retrieving API key:", error);
    return null;
  }
}

/**
 * 刪除儲存的 API 金鑰
 */
export async function deleteApiKeySecurely(): Promise<void> {
  try {
    const SecureStore = await import("expo-secure-store");
    await SecureStore.deleteItemAsync("claude_api_key");
  } catch (error) {
    console.error("Error deleting API key:", error);
    throw error;
  }
}


/**
 * 構建分析提示詞
 */
export function buildAnalysisPrompt(
  zipName: string,
  fileCount: number,
  frameworkType: string,
  fileList: string,
  additionalContext: string
): string {
  return `
Analyze this ZIP file and provide insights:

ZIP Name: ${zipName}
Total Files: ${fileCount}
Framework Type: ${frameworkType}

File List (first 50):
${fileList}

Additional Context:
${additionalContext}

Provide analysis in JSON format with these fields:
{
  "tags": ["tag1", "tag2"],
  "overview": "Brief overview",
  "architecture": "Architecture description",
  "value": "Value proposition"
}
  `.trim();
}

/**
 * 解析 API 分析結果
 */
export function parseAnalysisResult(response: string): {
  tags: string[];
  overview: string;
  architecture: string;
  value: string;
} {
  try {
    // 嘗試從回應中提取 JSON
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return {
        tags: Array.isArray(parsed.tags) ? parsed.tags : [],
        overview: parsed.overview || "No overview available",
        architecture: parsed.architecture || "No architecture description",
        value: parsed.value || "No value description",
      };
    }
  } catch (error) {
    console.error("Error parsing analysis result:", error);
  }

  // 回退到預設值
  return {
    tags: ["analyzed"],
    overview: response.slice(0, 200),
    architecture: "Architecture analysis pending",
    value: "Value analysis pending",
  };
}
