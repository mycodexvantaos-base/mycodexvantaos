import React, { ReactNode } from "react";
import { View, Text, TouchableOpacity, ScrollView } from "react-native";
import { logger } from "@/lib/logger";

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: (error: Error, retry: () => void) => ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

/**
 * 錯誤邊界元件
 * 捕獲子元件中的錯誤並顯示友好的錯誤訊息
 */
export class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // 記錄錯誤到日誌系統
    logger.error("React Error Boundary caught an error", {
      componentStack: errorInfo.componentStack,
    }, error);
  }

  handleRetry = () => {
    this.setState({
      hasError: false,
      error: null,
    });
  };

  render() {
    if (this.state.hasError && this.state.error) {
      if (this.props.fallback) {
        return this.props.fallback(this.state.error, this.handleRetry);
      }

      return (
        <View className="flex-1 bg-background">
          <ScrollView className="flex-1 p-4">
            <View className="bg-error/10 border border-error rounded-lg p-4 mb-4">
              <Text className="text-lg font-bold text-error mb-2">發生錯誤</Text>
              <Text className="text-sm text-foreground mb-2">{this.state.error.message}</Text>
              <Text className="text-xs text-muted font-mono">
                {this.state.error.stack}
              </Text>
            </View>

            <TouchableOpacity
              onPress={this.handleRetry}
              className="bg-primary rounded-lg py-3 items-center justify-center"
            >
              <Text className="text-white font-semibold">重試</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      );
    }

    return this.props.children;
  }
}
